-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 21, 2018 at 09:23 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ca_dept`
--
CREATE DATABASE IF NOT EXISTS `ca_dept` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `ca_dept`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` varchar(150) NOT NULL,
  `admin_email` varchar(250) NOT NULL,
  `admin_pass` varchar(250) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_email`, `admin_pass`) VALUES
('ca01', '', 'bjj');

-- --------------------------------------------------------

--
-- Table structure for table `db_com`
--

CREATE TABLE IF NOT EXISTS `db_com` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `c_desc` varchar(2500) NOT NULL,
  `c_dat` date NOT NULL,
  `s_re` varchar(250) NOT NULL,
  `com_active` varchar(250) NOT NULL DEFAULT '0',
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `db_com`
--

INSERT INTO `db_com` (`c_id`, `c_desc`, `c_dat`, `s_re`, `com_active`) VALUES
(1, 'Respected HOD, \r\nWe are the students from bca s1.\r\nwe have a suggestion for changing our classes because of dirty smell from bathroom.Kindly accept our suggestion.\r\n\r\n', '2018-01-29', '1345', '1');

-- --------------------------------------------------------

--
-- Table structure for table `db_event`
--

CREATE TABLE IF NOT EXISTS `db_event` (
  `e_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL,
  `desc` varchar(5000) NOT NULL,
  `dat` date NOT NULL,
  `year` varchar(250) NOT NULL,
  PRIMARY KEY (`e_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `db_event`
--

INSERT INTO `db_event` (`e_id`, `title`, `desc`, `dat`, `year`) VALUES
(5, 'Tour 2019', '	\r\nWe have conducted an International  Seminar  in St Thomas Collage Thrissur on 23 November 2016\r\n', '2018-02-20', '2018'),
(8, 'Seminar', 'We have conducted a International  Seminar  in St Thomas Collage Thrissur on 23 November 2016.\r\n\r\n', '2018-02-20', '2018'),
(11, 'exb', '	\nWe have conducted an International  Seminar  in St Thomas Collage Thrissur on 23 November 2016', '2018-02-21', '2018'),
(12, 'onam', '	\nWe have conducted an International  Seminar  in St Thomas Collage Thrissur on 23 November 2016', '2017-02-21', '2017');

-- --------------------------------------------------------

--
-- Table structure for table `db_fac`
--

CREATE TABLE IF NOT EXISTS `db_fac` (
  `t_id` varchar(250) NOT NULL,
  `img` varchar(250) NOT NULL,
  `name` varchar(250) NOT NULL,
  `add` varchar(300) NOT NULL,
  `dob` date NOT NULL,
  `gender` char(10) NOT NULL,
  `ph_no` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `qualif` varchar(250) NOT NULL,
  `exprnc` varchar(250) NOT NULL,
  `position` varchar(250) NOT NULL,
  `paswd` varchar(250) NOT NULL,
  PRIMARY KEY (`t_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_fac`
--

INSERT INTO `db_fac` (`t_id`, `img`, `name`, `add`, `dob`, `gender`, `ph_no`, `email`, `qualif`, `exprnc`, `position`, `paswd`) VALUES
('a002', 'teena.jpg', 'Teena Sebi', 'Kareparamben house. Shanthi avenue. Laloor road.Thrissur-4 ??? ???\r\n\r\n\r\n', '2018-02-28', 'Female', '9947140186', 'Teena_seb@yahoo.com', 'Msc.Computer Science', '6', 'Assistant Proffesor', '1234'),
('A003', 'bindya.jpg', ' Bindhia Francis', 'Parappilly apartement \r\nBlock D -102, Puthenvettozhy\r\nChembookavu, Thrissur-20		', '1987-01-22', 'Female', '9249449977', 'dhiyajoji23@gmail.com', 'M.C.A.', '10', 'Head Of the Department', '2356'),
('A004', 'jeswin.jpg', 'Jeswin Saju', '	Vattekkattukara house\r\nNettissery p.o\r\nMukkattukara\r\nThrissur,		', '1991-04-12', 'Male', '9747729143', 'jeswinsaju@gmail.com', 'M.C.A.', '6', 'Assistant Proffesor', '2541'),
('A005', 'prinson.jpg', 'Prinson P. T.', '		Puthukkara house\r\nAmbady nagar\r\nPeramangalam\r\nThrissur	', '1989-05-26', 'Male', '8547508645', 'prinzonpt@gmail.com', 'M.Sc., PGDCA', '6', 'Assistant Proffesor', '5698');

-- --------------------------------------------------------

--
-- Table structure for table `db_fdbck`
--

CREATE TABLE IF NOT EXISTS `db_fdbck` (
  `f_id` int(11) NOT NULL AUTO_INCREMENT,
  `f_desc` varchar(2500) NOT NULL,
  `s_re` varchar(250) NOT NULL,
  `fd_active` varchar(250) NOT NULL DEFAULT '0',
  PRIMARY KEY (`f_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `db_fdbck`
--

INSERT INTO `db_fdbck` (`f_id`, `f_desc`, `s_re`, `fd_active`) VALUES
(1, 'In this sem five teachers are taking classes and all of them are very interesting.They teaches advanced things about various topics.', '1345', '0'),
(2, 'Hi_tech labs are providings.', '1345', '0'),
(3, 'Our Passout seniors was really helpfull,Friendly. They will available at anytime for clearing doubts. Especially their coordinations, was awsome. ', '1348', '0'),
(8, 'cgtruyiujyhgf', '1348', '0'),
(9, 'jnalla c\r\nschool aaah ttta enthu resaaa kanaan', '1348', '0'),
(10, 'hello', 'hai', '0'),
(11, 'grt', 'xc', '0'),
(12, 'dsf', '', '0');

-- --------------------------------------------------------

--
-- Table structure for table `db_gal`
--

CREATE TABLE IF NOT EXISTS `db_gal` (
  `g_id` int(11) NOT NULL AUTO_INCREMENT,
  `g_photo` varchar(250) NOT NULL,
  `e_id` varchar(250) NOT NULL,
  PRIMARY KEY (`g_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `db_gal`
--

INSERT INTO `db_gal` (`g_id`, `g_photo`, `e_id`) VALUES
(8, 'exo.jpg', '5'),
(21, 'exo.jpg', '5'),
(22, 'Fudfest.jpeg', '11'),
(23, 'close.png', '12'),
(24, 'banner1.jpg', '8'),
(25, 'banner2.jpg', '8');

-- --------------------------------------------------------

--
-- Table structure for table `db_not`
--

CREATE TABLE IF NOT EXISTS `db_not` (
  `n_id` int(11) NOT NULL AUTO_INCREMENT,
  `n_desc` varchar(2500) NOT NULL,
  `n_date` varchar(250) NOT NULL,
  `course` varchar(250) NOT NULL,
  `batch` varchar(250) NOT NULL,
  `active` varchar(250) NOT NULL DEFAULT '0',
  `st_active` varchar(250) NOT NULL DEFAULT '0',
  PRIMARY KEY (`n_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `db_not`
--

INSERT INTO `db_not` (`n_id`, `n_desc`, `n_date`, `course`, `batch`, `active`, `st_active`) VALUES
(7, 'Exam \r\n', '18-03-21', 'BCA', 'S5', '1', '1'),
(8, 'Meeting\r\n', '18-03-21', 'BCA', 'S1', '1', '1'),
(9, '\r\nMeeting', '18-03-21', 'BCA', 'S5', '1', '1'),
(10, '\r\nSeminar', '18-03-21', 'All', 'All', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `db_stud`
--

CREATE TABLE IF NOT EXISTS `db_stud` (
  `s_re` varchar(250) NOT NULL,
  `s_photo` varchar(250) NOT NULL,
  `s_name` varchar(250) NOT NULL,
  `s_add` varchar(250) NOT NULL,
  `s_dob` date NOT NULL,
  `s_gender` char(10) NOT NULL,
  `s_ph` varchar(1500) NOT NULL,
  `s_email` varchar(250) NOT NULL,
  `s_blood` varchar(250) NOT NULL,
  `s_sl` char(20) NOT NULL,
  `s_fa` varchar(250) NOT NULL,
  `s_ma` varchar(250) NOT NULL,
  `s_password` varchar(250) NOT NULL,
  `s_reli` char(25) NOT NULL,
  `s_pre_in` varchar(250) NOT NULL,
  `course` varchar(250) NOT NULL,
  `status` varchar(250) NOT NULL,
  `batch` varchar(250) NOT NULL,
  `t_id` varchar(1000) NOT NULL,
  PRIMARY KEY (`s_re`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_stud`
--

INSERT INTO `db_stud` (`s_re`, `s_photo`, `s_name`, `s_add`, `s_dob`, `s_gender`, `s_ph`, `s_email`, `s_blood`, `s_sl`, `s_fa`, `s_ma`, `s_password`, `s_reli`, `s_pre_in`, `course`, `status`, `batch`, `t_id`) VALUES
('1236', 'exo.jpg', 'Arjun', 'fdgf\r\nsdgrg\r\n', '2018-02-03', 'Female', '9747850111', 'g@gmail.com', 'AB+', 'malayalam', 'thomas', 'dinaaa', '1236', 'hindu', 'Sree Krishna school guruvayoor', 'MSC', 'Ongoing', 'S1', 'A004'),
('1345', 'bavi.jpg', 'Bavitha', 'NEELAMKAVILl(H)ANUGAS (R)P.O. CHAVAKKAD        ', '1997-04-30', 'Female', '9747850111', 'bavibavithaa@gmail.com', 'AB+', 'Malayalam', 'Tomy', 'Brighty', '1345', 'Christian', 'LFCGHSS', 'BCA', 'Ongoing', 'S1', 'A003'),
('1348', 'jayuz.jpg', 'Jayasree M.C', '   MANIYANTHRA(H)        KANIYAMPAL KUNNAMKULAM', '1998-02-12', 'Female', '9446937322', 'jayasree.csn@gmail.com', 'o+', 'Malayalam', 'Chandran M', 'Lalitha', '1348', 'hindu', 'St.Francis Mattam', 'BCA', 'Ongoing', 'S6', 'A003'),
('1352', 'Varha.jpg', 'Varsha K', '	THANIKKATTU HOUSE, \r\nTHAIKKATTUSSERY \r\nP O,THRISSUR, 680306, 	\r\n	', '1997-08-12', 'Female', '9745815014', 'varshak9999@gmail.com', 'O+', 'hindi', 'Ramachandran', 'Anjana', '1352', 'Nair', 'ST PAULS CEHSS KURYACHIRA', 'BCA', 'Ongoing', 'S4', 'A003'),
('1502', 'kp.jpg', 'Krishnapriya K.S', 'KADUKKAPULLY HOUSE, EAST POLICE QUARTERS, NO 14A P, THRISSUR,    ', '1997-06-11', 'Female', '9562826420', 'krishnapriya1106@gmail.com', 'A+', 'hindi', 'K A SURENDRAN', 'VIJAYALAKSHMI K V', '1502', 'hindu', 'ST RAPHEALS C G H S S OLLUR ', 'BCA', 'Ongoing', 'S3', 'A003'),
('1708', 'exo.jpg', 'Dilna P.S', 'PAYYAPATTU(H),P.O ADATU, THRISSUR', '2018-02-06', 'Female', '8848159620', 'dipnaps2016@gmail.com', 'B+', 'Hindi', 'Suresh P.K', 'Pushpitha T.V', '1708', 'hindu', 'Sree Krishna school guruvayoor', 'BCA', 'Ongoing', 'S1', 'A004');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
