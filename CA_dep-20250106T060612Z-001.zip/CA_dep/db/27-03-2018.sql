-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 28, 2018 at 08:17 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ca_dept`
--
CREATE DATABASE IF NOT EXISTS `ca_dept` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `ca_dept`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` varchar(150) NOT NULL,
  `admin_email` varchar(250) NOT NULL,
  `admin_pass` varchar(250) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_email`, `admin_pass`) VALUES
('ca01', '', 'bjj');

-- --------------------------------------------------------

--
-- Table structure for table `db_com`
--

CREATE TABLE IF NOT EXISTS `db_com` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `c_desc` varchar(2500) NOT NULL,
  `c_dat` date NOT NULL,
  `s_re` varchar(250) NOT NULL,
  `com_active` varchar(250) NOT NULL DEFAULT '0',
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `db_com`
--

INSERT INTO `db_com` (`c_id`, `c_desc`, `c_dat`, `s_re`, `com_active`) VALUES
(1, ' We are the students from bca s1.we have a suggestion for changing our classes because of dirty smell from bathroom.Kindly accept our suggestion.', '2018-01-29', '1345', '1'),
(8, ' We are students from BCA S1. We have a suggection for changing the lab model exam on 26/03/2018', '2018-03-21', '1352', '1'),
(9, 'We need to have more praticals  than theory class.', '2018-03-23', '1236', '1'),
(10, 'Faculties are not taking class according to syllabus.\r\n', '2018-03-25', '1345', '1');

-- --------------------------------------------------------

--
-- Table structure for table `db_event`
--

CREATE TABLE IF NOT EXISTS `db_event` (
  `e_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL,
  `desc` varchar(5000) NOT NULL,
  `dat` date NOT NULL,
  `year` varchar(250) NOT NULL,
  PRIMARY KEY (`e_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `db_event`
--

INSERT INTO `db_event` (`e_id`, `title`, `desc`, `dat`, `year`) VALUES
(5, 'Tour 2018', '    We have conducted tour for our final years on 14-17 November 2017.It was from Chickmangloor,Coorg,Wayyanad.', '2018-02-20', '2018'),
(8, 'Seminar', 'We have conducted a International  Seminar  in St Thomas Collage Thrissur on 23 November 2016.\r\n\r\n', '2018-02-20', '2018'),
(11, 'Exodous', '    We have organised  and conducted a Techo-It fest named Exodous  on Januarry 11 & 12 2018', '2018-02-21', '2018'),
(12, 'onam', '	\nWe have conducted an International  Seminar  in St Thomas Collage Thrissur on 23 November 2016', '2017-02-21', '2017'),
(13, 'xmas', '\r\nchristmas was held on 24/12/2017.', '2018-03-26', '2018'),
(15, 'Christmas ', 'Christmas celebration was held on Decembe 23.\r\n', '2018-03-27', '2015');

-- --------------------------------------------------------

--
-- Table structure for table `db_fac`
--

CREATE TABLE IF NOT EXISTS `db_fac` (
  `t_id` varchar(250) NOT NULL,
  `img` varchar(250) NOT NULL,
  `name` varchar(250) NOT NULL,
  `add` varchar(300) NOT NULL,
  `dob` date NOT NULL,
  `gender` char(10) NOT NULL,
  `ph_no` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `qualif` varchar(250) NOT NULL,
  `exprnc` varchar(250) NOT NULL,
  `position` varchar(250) NOT NULL,
  `paswd` varchar(250) NOT NULL,
  PRIMARY KEY (`t_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_fac`
--

INSERT INTO `db_fac` (`t_id`, `img`, `name`, `add`, `dob`, `gender`, `ph_no`, `email`, `qualif`, `exprnc`, `position`, `paswd`) VALUES
('A003', 'bindya.jpg', ' Bindhia Francis', 'Parappilly apartement \r\nBlock D -102, Puthenvettozhy\r\nChembookavu, Thrissur-20		', '1987-01-22', 'Female', '9249449977', 'dhiyajoji23@gmail.com', 'M.C.A.', '10', 'Head Of the Department', '6532'),
('A004', 'jeswin.jpg', 'Jeswin Saju', '	Vattekkattukara house\r\nNettissery p.o\r\nMukkattukara\r\nThrissur,		', '1991-04-12', 'Male', '9747729143', 'jeswinsaju@gmail.com', 'M.C.A.', '6', 'Assistant Proffesor', '2541'),
('A005', 'prinson.jpg', 'Prinson P. T.', '		Puthukkara house\r\nAmbady nagar\r\nPeramangalam\r\nThrissur	', '1989-05-26', 'Male', '8547508645', 'prinzonpt@gmail.com', 'M.Sc., PGDCA', '6', 'Assistant Proffesor', '5698'),
('A008', 'denni.jpg', 'Denni', 'neelamkavil(H_)\r\n', '2018-03-02', 'male', '9847802721', 'denni@gmail.com', 'MCA', '5', 'Lab Assistant', '7896');

-- --------------------------------------------------------

--
-- Table structure for table `db_fdbck`
--

CREATE TABLE IF NOT EXISTS `db_fdbck` (
  `f_id` int(11) NOT NULL AUTO_INCREMENT,
  `f_desc` varchar(2500) NOT NULL,
  `s_re` varchar(250) NOT NULL,
  `fd_active` varchar(250) NOT NULL DEFAULT '0',
  PRIMARY KEY (`f_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `db_fdbck`
--

INSERT INTO `db_fdbck` (`f_id`, `f_desc`, `s_re`, `fd_active`) VALUES
(1, 'In this sem five teachers are taking classes and all of them are very interesting.They teaches advanced things about various topics.', '1345', '0'),
(2, 'Hi_tech labs are providings.', '1345', '0'),
(3, 'Our Passout seniors was really helpfull,Friendly. They will available at anytime for clearing doubts. Especially their coordinations, was awsome. ', '1348', '0'),
(16, 'Some faculties are not taking classes accoding to syllabus.', '1345', '0');

-- --------------------------------------------------------

--
-- Table structure for table `db_gal`
--

CREATE TABLE IF NOT EXISTS `db_gal` (
  `g_id` int(11) NOT NULL AUTO_INCREMENT,
  `g_photo` varchar(250) NOT NULL,
  `e_id` varchar(250) NOT NULL,
  PRIMARY KEY (`g_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `db_gal`
--

INSERT INTO `db_gal` (`g_id`, `g_photo`, `e_id`) VALUES
(8, 'DSC09367.jpg', '5'),
(21, 'DSC00035.jpg', '5'),
(23, 'close.png', '12'),
(24, 'seminar.jpg', '8'),
(26, 'mm.jpg', '13'),
(27, 'oo.jpg', '5'),
(28, '2017-12-22-11-58-23-006.jpg', '13'),
(29, 'exo.jpg', '11'),
(30, 'kji.jpg', '11'),
(31, 'IMG-20151220-WA0005.jpg', '15');

-- --------------------------------------------------------

--
-- Table structure for table `db_not`
--

CREATE TABLE IF NOT EXISTS `db_not` (
  `n_id` int(11) NOT NULL AUTO_INCREMENT,
  `n_desc` varchar(2500) NOT NULL,
  `n_date` varchar(250) NOT NULL,
  `course` varchar(250) NOT NULL,
  `batch` varchar(250) NOT NULL,
  `active` varchar(250) NOT NULL DEFAULT '0',
  `st_active` varchar(250) NOT NULL DEFAULT '0',
  `t_id` varchar(250) NOT NULL,
  PRIMARY KEY (`n_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `db_not`
--

INSERT INTO `db_not` (`n_id`, `n_desc`, `n_date`, `course`, `batch`, `active`, `st_active`, `t_id`) VALUES
(7, 'model Lab Exam on 26/02/2018 ', '18-03-21', 'BCA', 'S4', '1', '1', 'a002'),
(8, 'PTA Meeting on 13/02/2018', '18-03-21', 'BCA', 'S2', '1', '1', 'a002'),
(10, 'PHP & JAVA Lab exam on 4/4/2018', '18-03-21', 'BCA', 'S6', '1', '1', 'a002'),
(13, 'Final External of project is on 6/4/2018', '18-03-26', 'BCA', 'S6', '1', '1', 'A003');

-- --------------------------------------------------------

--
-- Table structure for table `db_stud`
--

CREATE TABLE IF NOT EXISTS `db_stud` (
  `s_re` varchar(250) NOT NULL,
  `s_photo` varchar(250) NOT NULL,
  `s_name` varchar(250) NOT NULL,
  `s_add` varchar(250) NOT NULL,
  `s_dob` date NOT NULL,
  `s_gender` char(10) NOT NULL,
  `s_ph` varchar(1500) NOT NULL,
  `s_email` varchar(250) NOT NULL,
  `s_blood` varchar(250) NOT NULL,
  `s_sl` char(20) NOT NULL,
  `s_fa` varchar(250) NOT NULL,
  `s_ma` varchar(250) NOT NULL,
  `s_password` varchar(250) NOT NULL,
  `s_reli` char(25) NOT NULL,
  `s_pre_in` varchar(250) NOT NULL,
  `course` varchar(250) NOT NULL,
  `status` varchar(250) NOT NULL,
  `batch` varchar(250) NOT NULL,
  `t_id` varchar(1000) NOT NULL,
  PRIMARY KEY (`s_re`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `db_stud`
--

INSERT INTO `db_stud` (`s_re`, `s_photo`, `s_name`, `s_add`, `s_dob`, `s_gender`, `s_ph`, `s_email`, `s_blood`, `s_sl`, `s_fa`, `s_ma`, `s_password`, `s_reli`, `s_pre_in`, `course`, `status`, `batch`, `t_id`) VALUES
('1215', 'aishu.jpg', 'Aishwarya P M', '250/Velloore,Kurup,Trikkur,Thrissure', '1999-04-12', 'Female', '8547056112', 'aiswaryanair1215@gmail.com', 'AB+', 'Malayalam', 'Ranjith', 'Rajitha A', '1215', 'Nair', 'St JOsephCGHSS,Thrissur', 'BCA', 'Ongoing', 'S2', 'A003'),
('1345', 'bavi.jpg', 'Bavitha', 'Neelamkil(H),P.O.Chavakad', '1997-04-30', 'Female', '9747850111', 'bavibavithaa@gmail.com', 'AB+', 'Malayalam', 'Tomy', 'Brighty Tomy', '1345', 'Christyan', 'LFCGHSS,Mammiyoor', 'BCA', 'Ongoing', 'S6', 'A003'),
('1348', 'jayuz.jpg', 'Jayasree M.C', 'MANIYANTHRA(H)KANIYMPAL KUNNAMKULAM', '1998-02-12', 'Female', '9446937322', 'jayasree.csn@gmail.com', 'o+', 'Malayalam', 'Chandran M', 'Lalitha', '1348', 'hindu', 'St.Francis Mattam', 'BCA', 'Ongoing', 'S6', 'A003'),
('1352', 'thammana.jpg', 'Thamanna Praveen', 'Ambhalath(H),Kizhakkepuram(R),Poothole,P.O.Thrissur', '1997-04-15', 'Female', '9447834943', 'thamannapraveen1997@gmail.com', 'O+', 'hindi', 'Praveen Aboobacker', 'Rabiya Aboobacker', '1352', 'Muslim', 'MESColage', 'BCA', 'Ongoing', 'S4', 'A003'),
('1687', 'fg5gz5sb8u.jpg', 'Jasmin K.S', 'Kidengasery,Katoor,Thrissur\r\n', '1998-05-07', 'Female', '8589933642', 'ksjasmin59@gmail.com', 'O+', 'Hindi', 'K.m.Shareef', 'Ayishabee Shareef', '1687', 'Muslim', 'GHSS katoor,Thrissur', 'BCA', 'Ongoing', 'S4', 'A003'),
('1708', 'exo.jpg', 'Dilna P.S', 'PAYYAPATTU(H),P.O ADATU,THRISSUR', '2018-02-06', 'Female', '8848159620', 'dipnaps2016@gmail.com', 'B+', 'Hindi', 'Suresh P.K', 'Pushpitha T.V', '1708', 'hindu', 'Sree Krishna school guruvayoor', 'BCA', 'Ongoing', 'S4', 'A004'),
('1716', '9benrq3jz8.jpg', 'Aishwarya  ', 'Vennkani Parambil,Palayoor,,Chavakkad,Thrissur\r\n', '1998-03-29', 'Female', '7356083524', 'ayshmbob6@gmail.com', 'A+', 'Malayalam', 'V.K.Sudharshanan', 'Laxmi Sudharshanan', '1716', 'Hindhu', 'Devasom Engilsh medium school,Guruvayoor', 'BCA', 'On going student', 'S4', 'A003'),
('2138', 'devadhathn.jpg', 'Devadhathan P.Sanil', 'Perumbali(H),Pallimoola,Thrissur\r\n', '1999-09-06', 'Male', '9539388926', 'devadhathanps000@gmail.com', 'A+', 'Malayalam', 'Sanil', 'Swapna Sanil', '2138', 'Hindhu', 'Government HSS,Thrissur', 'BCA', 'On going student', 'S2', 'A003'),
('2140', 'jeevan.jpg', 'Jeevan Thomas', 'Mapranni(H),Karimpattathope,Chiyyaram,Thrissur\r\n', '1997-07-29', 'Male', '8281823608', 'jeevanthom97@gmail.com', 'A+', 'Malayalam', 'Thomas', 'Lilly Thomas', '2140', 'Christian', 'St.Augustin HSS,Kuttanallor', 'BCA', 'On going student', 'S2', 'A003'),
('2142', 'asha.jpg', 'Asha Antony', 'Puthoor(H),Poonor,Thrissur\r\n', '1999-09-24', 'Null', '9744635627', 'ashaantonyputhoor@gmail.com', 'AB+', 'Malayalam', 'P.R.Antony', 'Biji Antony', '2142', 'Christian', 'Scred hearts,Thrissur', 'BCA', 'On going student', 'S2', 'A003'),
('2263', 'rajswri.jpg', 'Rjeshwary N', 'Pathmalaya(H),Kuttenkulengara,Poonkunam,Thrissur\r\n', '1999-03-15', 'Female', '9467495935', 'rajeswary99@gmail.com', 'O+', 'Hindi', 'Nadarajan K', 'Minitha ', '2263', 'Hindhu', 'Vivekodhayam Boys,Thrissur', 'BCA', 'On going student', 'S2', 'A003');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
