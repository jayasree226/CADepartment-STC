<?php 
session_start();
unset($_SESSION['admin_id']);
unset($_SESSION['t_id']);
unset($_SESSION['s_re']);
session_destroy();

header("Location:index.php");
 
?>