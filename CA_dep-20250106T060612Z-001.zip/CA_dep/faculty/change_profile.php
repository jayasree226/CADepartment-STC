<?php
include('facultyheader.php');
include('../connection.php');
$f=0;
if(isset($_POST['view']))
{
	header('Location:viewfaculty.php');
}
if(isset($_POST['add']))
	{
      
      $img=$_FILES['img']['name'];
	 
	
	   
	  $name=$_POST['name'];

	  if(empty($name))
	  {
		  $f=1;
		  $name_err="Fill  name";
	  }
	  $address=$_POST['Address'];
	
	  if(empty($address))
	  {
		  $f=1;
		  $address_err="Fill  address";
	  }

	    $dob=$_POST['dob'];
		
	   if(empty($dob))
	  {
		  $f=1;
		  $dob_err="Choose Date of birth";
	  }
	  	  $gen=$_POST['gen'];
	 
	   if(empty($gen))
	  {
		  $f=1;
		  $gen_err="Choose Gender";
	  }
	  $ph=$_POST['Phone'];
	
		if(empty($ph))
	  {
		  $f=1;
		  $ph_err="Fill  Phone number";
	  }  
	  $email=$_POST['Email'];
	  
	  if(empty($email))
	  {
		  $f=1;
		  $email_err="Fill  Email";
	  }  
	  $quali=$_POST['qua'];
	  //var_dump($quali);
	   if(empty($quali))
	  {
		  $f=1;
		  $quali_err="Fill Qualification";
	  }  
	   $exp=$_POST['Experience'];
	   if(empty($exp))
	  {
		  $f=1;
		  $exp_err="Fill Experience";
	  } 
	  
      $posi=$_POST['pos'];
	  //var_dump($posi);
      if(empty($posi))
	  {
		  $f=1;
		  $posi_err="Fill Position ";  
	  }
 
	if($f==0)
	{			
if($img==NULL)
{
   $up="UPDATE `db_fac` SET `name`='$name',`add`='$address',`dob`='$dob',`gender`='$gen',`ph_no`='$ph',`email`='$email',`qualif`='$quali',`exprnc`='$exp',`position`='$posi' WHERE t_id='$m' ";

	        $result = $conn->query($up);
		        if($result==True)
		        {
		         echo ("<SCRIPT LANGUAGE='JavaScript'>
                    window.alert(' Sucessfully Changed!..')
                      window.location.href='facultyprofile.php';
                     </SCRIPT>");
	            }
	
}
				else
				{
					 $u="UPDATE `db_fac` SET img='$img',`name`='$name',`add`='$address',`dob`='$dob',`gender`='$gen',`ph_no`='$ph',`email`='$email',`qualif`='$quali',`exprnc`='$exp',`position`='$posi' WHERE t_id='$m'";
					 
	        $resul = $conn->query($u);
		        if($resul==True)
		        {
					echo ("<SCRIPT LANGUAGE='JavaScript'>
                    window.alert(' Sucessfully Changed!..')
                      window.location.href='facultyprofile.php';
                     </SCRIPT>");
				}
				
				else
				{
					echo ("<SCRIPT LANGUAGE='JavaScript'>
                    window.alert('Changing Failed!..')
                      window.location.href='change_profile.php';
                     </SCRIPT>");
				}
				}
	}
			
}	
?>
<!--//banner -->
	<!-- short-->
	
<!-- //short-->
	<!-- //short-->
	<html>
<head>

<link href="../css/form.css" rel="stylesheet" type="text/css" media="all" />


<link href="//fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
</head>
<body>
	<div class="main">
	
		
		<div class="w3_agile_main_grids">
			<section class="slider">
				<div class="flexslider">
					<ul class="slides">
						<li>
							<div class="agileits_w3layouts_main_grid">
								<span style="color:red;font-size:285%;margin-left:85px">P</span><span style="color:black;font-size:285%">rofile</span>		<span style="color:red;font-size:285%;margin-left:5px">F</span><span style="color:black;font-size:285%">orm</span>
								<br>
								<br>
								<br>
								<form action="#" method="POST" enctype="multipart/form-data">
								<?php
											$query = "SELECT * FROM db_fac where t_id='$m'"; //You don't need a ; like you do in SQL
    $result = $conn->query($query);

    while($row =$result->fetch_assoc())
	{
		$eid=$row['t_id'];
		$img=$row['img'];
		$nam=$row['name'];
		$add=$row['add'];
		$dob=$row['dob'];
		$gen=$row['gender'];
		$ph=$row['ph_no'];
		$email=$row['email'];
		$qua=$row['qualif'];
		$exp=$row['exprnc'];
		$pas=$row['position'];
		$name=$row['paswd'];
	}
?>
	<span>
										<span style="color:red">FACULTY ID&nbsp;&nbsp;&nbsp:<?php echo $eid;?><span>
										<br>
									
										<img src="../images/<?php echo $img;?>">
										<input type="FILE"  name="img" >
							  
										
									</span>
								<br><br>
									
									<span>
										<label>Name</label>
										<input type="text"  name="name"  value="<?php echo $nam;?>" style="color:black">
										<br>
										<br>
							 <span style="color:red ;margin-left:180px"><?php echo (isset($name_err))?$name_err:""?></span> 
									</span>
									<span>
										<label style="width: 22%;
    font-size: .85em;
    color: #212121;
    background: #e9e9e9;
    display: inline-block;
    padding: 13px;
    text-transform: uppercase;
    float: left;
    letter-spacing: 2px;
    text-align: center;
    border: 1px solid #e9e9e9;
	height:60px">Address</label>
										<textarea name="Address"   style="padding: 13px 15px;
    color: black;
    outline: none;
    width: 67.4%;
    font-size: .85em;
    background: none;
    border: 1px solid #e9e9e9;
}
form.css:41
h1, h2, h3, h4, h5, h6, input, p, a, select, button, textarea {
    font-family: 'Montserrat', sans-serif;
    margin: 0;"><?php echo $add;?>

</textarea>
			 <span style="color:red; margin-left:180px"><?php echo (isset($address_err))?$address_err:""?></span> 
									</span>
									<br>
									<span>
										<label>Date Of Birth</label>
										<input   type="date"  name="dob" value="<?php echo $dob;?>"  style="padding: 13px 15px;
    color: black;
    outline: none;
    width: 67.4%;
    font-size: .85em;
    background: none;
    border: 1px solid #e9e9e9;
	height:55px;
form.css:41
h1, h2, h3, h4, h5, h6, input, p, a, select, button, textarea {
    font-family: 'Montserrat', sans-serif;
    margin: 0;">
	 <span style="color:red;margin-left:180px"><?php echo (isset($dob_err))?$dob_err:""?></span> 
									</span>
									<br>
									<span>
										<label>Gender</label>
										<select   style="width: 68% !important;
    padding: 12px 15px !important;color:black" name="gen" >
	                                        <option value="<?php echo $gen;?>"><?php echo $gen;?></option>
											<option value="female" style="color:red">Female</option>         
											<option value="male" style="color:red">Male</option>
											<option value="other" style="color:red">Other</option>
											
										</select>
										 <span style="color:red;margin-left:180px"><?php echo (isset($gen_err))?$gen_err:""?></span> 
									</span>
									<br>
									<span>
										<label style="width: 22%;
    font-size: .85em;
    color: #212121;
    background: #e9e9e9;
    display: inline-block;
    padding: 13px;
    text-transform: uppercase;
    float: left;
    letter-spacing: 2px;
    text-align: center;
    border: 1px solid #e9e9e9;
	height:56px">Ph. Number</label>
										<input type="text"  name="Phone"  value="<?php echo $ph;?>" style="padding: 13px 15px;
    color: black;
    outline: none;
    width: 67.4%;
    font-size: .85em;
    background: none;
    border: 1px solid #e9e9e9;
	height:55px;
form.css:41
h1, h2, h3, h4, h5, h6, input, p, a, select, button, textarea {
    font-family: 'Montserrat', sans-serif;
    margin: 0;" pattern="[0-9]{10}" >
							 <span style="color:red;margin-left:180px"><?php echo (isset($ph_err))?$ph_err:""?></span> 
						
									</span>
									<br>
									<span>
										<label>Email</label>
										<input type="email"  name="Email"  value="<?php echo $email;?>" style="color:black">
							 <span style="color:red;margin-left:180px"><?php echo (isset($email_err))?$email_err:""?></span> 
									</span><br>
									<span>
										<label style="width: 25%;
    font-size: .85em;
    color: #212121;
    background: #e9e9e9;
    display: inline-block;
    padding: 13px;
    text-transform: uppercase;
    float: left;
    letter-spacing: 2px;
    text-align: center;
    border: 1px solid #e9e9e9;
	height:45px">Qualification</label>
										<select    name="qua" style="width: 64% !important;
    padding: 12px 15px !important;color:black" >
											<option value="<?php echo $qua;?>" style="color:black"><?php echo $qua;?></option>
											<option value="MCA" style="color:red">MCA</option>         
											<option value="Msc.Computer Science" style="color:red">Msc.Computer Science</option>
											<option value="PGDCA" style="color:red">PGDCA</option>
											<!--<option value="">China</option>
											<option value="">More</option>-->
										</select>
							 <span style="color:red;margin-left:180px"><?php echo (isset($quali_err))?$quali_err:""?></span> 
									</span><br>
									<span>
										<label>Experiance</label>
										<input type="text"  name="Experience"  value="<?php echo $exp;?>" style="color:black">
							 <span style="color:red;margin-left:180px"><?php echo (isset($exp_err))?$exp_err:""?></span> 
									</span><br>
									<span>
										<label>Position</label>
										<select name="pos"  style="width: 68% !important;
    padding: 12px 15px !important; color:black">
											<option value="<?php echo $pas;?>"><?php echo $pas;?></option>
											<option value="HOD" style="color:red">HOD</option>         
											<option value="Assistant Professor" style="color:red">Assistant Professor</option>
											<option value="Lab Assistant" style="color:red">Lab Assistant</option>
											<!--<option value="">China</option>
											<option value="">More</option>-->
										</select>
							 <span style="color:red;margin-left:180px"><?php echo (isset($posi_err))?$posi_err:""?></span> 
									</span><br>
									
									<!--<span>
										<label>Address</label>
										<input name="Address" type="text" placeholder="Your Address" required="">
									</span>
									<span>
										<label>Address</label>
										<input name="Address" type="text" placeholder="Your Address" required="">
									</span>-->
									<div class="w3_agileits_submit">
										<input type="submit" value="CHANGE" name="add"> 
										<!--<input type="reset" value="reset">-->
									</div>
								</form>
							</div>
						</li>
						
						
					</ul>
				</div>
			</section>
		</div>
		
	</div>
<!-- password -->
<?php
include('facultyfooter.php');
?>