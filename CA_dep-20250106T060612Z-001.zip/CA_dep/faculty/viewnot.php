<?php
include('facultyheader.php');

if(isset($_POST['add'])=='Change Notification')
{
	header('Location:editnot.php?admi_no='.$adm);
}

$up="update db_not set active='1' ";
  
	$result = $conn->query($up);
	
		if($result==True)
	{
	//header('Location:notification.php');
		}
		else
		{
			
	//header('Location:notification.php');
		}
    	

?>	
				
	<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.alert {
    padding: 20px;
    background-color: gray;
    color: white;
	width:550px;
	margin-left:455px;
}

.closebtn {
    margin-left: 15px;
    color: white;
    font-weight: bold;
    float: right;
    font-size: 22px;
    line-height: 20px;
    cursor: pointer;
    transition: 0.3s;
}

.closebtn:hover {
    color: black;
}
</style>
</head>
<body>
<span style="color:red;font-size:285%;margin-left:585px">N</span><span style="color:black;font-size:285%">otification</span>
<br>
<br>
<script type="text/javascript">
    function ShowHideDiv(chkPassport) {
        var dvPassport = document.getElementById("dvPassport");
        dvPassport.style.display = chkPassport.checked ? "block" : "none";
    }
</script>
<form method="GET"  action="not_delete.php">
<div id="dvPassport" style="display: none">
<input type="submit"  value="DELETE"  id="txtPassportNumber" style="margin-left:1100px; background-color: red; /* Green */; border: none;
    color: white;
    padding: 16px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;">
	</div>
<tr>

<br>
<br>





<?php
	  include('../connection.php');
	
		$query = "SELECT * FROM db_not"; //You don't need a ; like you do in SQL
    $result = $conn->query($query);
	
    while($row =$result->fetch_assoc())
	{
		$nid=$row['n_id'];
		//$date=$row['n_date'];
		$nd=$row['n_desc'];
		
		
		?>
<div class="w3_agileits_submit" style="margin-left:1050px">
										
										<!--<input type="reset" value="reset">-->
									</div>
<div class="alert" style="background:wheat;">
 <label for="chkPassport">
   <input type="checkbox"  name="check[]" id="chkPassport" onclick="ShowHideDiv(this)"  value="<?php echo $nid;?>" style="margin-left:2px">
   </label>
&nbsp;&nbsp;&nbsp; <span style="color:black;">  <?php echo $nd;?>
<a href="editnot.php?id=<?php echo $nid;?>"><span style="margin-left:350px;color:red;font-size:large"> EDIT</span></a>  
</div>
</form>
<?php
	}
	?>
<?php
include('facultyfooter.php');
?>					