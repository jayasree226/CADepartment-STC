<?php
include('../connection.php');
include('Facultyheader.php');

$up="update db_not set active='1' ";
  
	$result = $conn->query($up);
	
		if($result==True)
		{
	//header('Location:notification.php');
		}
		else
		{
			
	//header('Location:notification.php');
		}
    	

?>

<h4 class="tittle">
				
<span style="color:red;font-size:285%;margin-left:485px">N</span><span style="color:black;font-size:285%">otification</span><span style="color:red;font-size:285%;margin-left:15px">D</span><span style="color:black;font-size:285%">etails</span>
					<!--<span>F</span>orm-->
				</h4>
				
				<br>
				<br>
				<br>
				
				
				
				
				
				
	<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.alert {
    padding: 20px;
    background-color: gray;
    color: white;
	width:550px;
	margin-left:455px;
}

.closebtn {
    margin-left: 15px;
    color: white;
    font-weight: bold;
    float: right;
    font-size: 22px;
    line-height: 20px;
    cursor: pointer;
    transition: 0.3s;
}

.closebtn:hover {
    color: black;
}
</style>
</head>
<body>

<form method="GET"  action="noti_delete.php">
<input type="submit"  value="DELETE" style="margin-left:1100px; background-color: red; /* Green */; border: none;
    color: white;
    padding: 16px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;">
<?php
//session_start();

	  include('../connection.php');
	//$st=$_SESSION['t_id'];
		$query = "SELECT * FROM db_not "; //You don't need a ; like you do in SQL
    $result = $conn->query($query);
	
    while($row =$result->fetch_assoc())
	{
		$nid=$row['n_id'];
		//$date=$row['n_date'];
		$nd=$row['n_desc'];
		
			
		
	

	
	
		?>

<div class="alert">
   
  <strong><input type="checkbox"  name="check[]" id="check[]" value="<?php echo $nid;?>" style="margin-left:2px"></strong>&nbsp;&nbsp;&nbsp; <?php echo $nd;?>
<br>
  <a href="edit_not.php?n_id=<?php echo $nid;?>" style="color:red;float:right;font-size:large"> Reset </a>
  </div>

<?php
	}
	?>
	</form>
<?php
include('facultyfooter.php');
?>					