<?php
include('facultyheader.php');
?>
<html>
<head>
<meta rel="author" href="https://crunchify.com" content="">
 
<script type="text/javascript"
	src="http://code.jquery.com/jquery-1.10.1.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
		$(".flip").click(function() {
			$(".panel").slideToggle("slow");
		});
	});
</script>
 
<style type="text/css">
div.panel,p.flip {
	margin: 0px;
	padding: 5px;
	text-align: center;
	
	border: solid 1px #fff;
}
 
div.panel {
	widht: 50%;
	height: 100px;
	display: none;
}
</style>
</head>
 
<body>
<div class="services">
		<span style="color:red;font-size:285%;margin-left:585px">C</span><span style="color:black;font-size:285%">HANGE</span><span style="color:red;font-size:285%;">E</span><span style="color:black;font-size:285%">VENTS</span>
		<br>
		<br>
 	<input type="submit"class="flip"> 
	<div class="panel">
	
	<span>
									
								
										<br>
										<br>
									
							
<!--<span style="color:red"><</span> -->
						</span>
						<span>
						<label> Title</label>
										<input type="text" name="Ename" style="color:white" >
										<br>
										<br>
						
							 <span style="color:red"><?php echo (isset($name_err))?$name_err:""?></span> 
					
						
						</span>
						<span>
										<label style="width: 22%;
    font-size: .85em;
    color: #212121;
    background: #e9e9e9;
    display: inline-block;
    padding: 13px;
    text-transform: uppercase;
    float: left;
    letter-spacing: 2px;
    text-align: center;
    border: 1px solid #e9e9e9;
	height:60px"> Description</label>
										<textarea name="EventDesc"  style="padding: 13px 15px;
    color: white;
    outline: none;
    width: 67.4%;
    font-size: .85em;
    background: none;
    border: 1px solid #e9e9e9;
}
form.css:41
h1, h2, h3, h4, h5, h6, input, p, a, select, button, textarea {
    font-family: 'Montserrat', sans-serif;
    margin: 0;">

</textarea><br>
							
	  <span style="color:red"><?php echo (isset($ed_err))?$ed_err:""?></span> 
							    
						</span>
						
						<div class="w3_agileits_submit" >
										<input type="submit" value="ADD" name="add">	<input type="submit" value="EVENTS" name="eve" id="eve">
										
										<!--<input type="reset" value="reset">-->
									</div>
								</form>
				
			
		

 


	</div>
 </div>
	<br>

 
	<br>
	<br>
<br>

 
	<br>
	<br><br>

 
	<br>
	<br><br>

 
	<br>
	<br>
 
</body>
</html>
<?php
include('facultyfooter.php');
?>