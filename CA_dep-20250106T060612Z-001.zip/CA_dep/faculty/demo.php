<!DOCTYPE html>
<html>
<body>

 <input type="checkbox" id="myCheck"  onclick="myFunction()">

<input type="submit" id="text" style="display:none">

<script>
function myFunction() {
    var checkBox = document.getElementById("myCheck");
    var text = document.getElementById("text");
    if (checkBox.checked == true){
        text.style.display = "block";
    } else {
       text.style.display = "none";
    }
}
</script>

</body>
</html>