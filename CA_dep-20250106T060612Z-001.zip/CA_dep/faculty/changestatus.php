<?php
include('facultyheader.php');

include('../connection.php');
$sre=$_GET['s_re'];
$cou=$_GET['course'];
$batch=$_GET['batch'];

$f=0;
if(isset($_POST['add']))
	{
		$s2=(isset($_POST['s2']))?$_POST['s2']:"";
			
		$stat=$_POST['st'];
  // var_dump($stat);
    if(empty($stat))
	  {
		  $f=1;
		  $stat_err="Fill Status";  
	  }
if($f==0)
		{			


   $sql="UPDATE db_stud SET status='$stat' , batch='$s2' WHERE s_re='$sre'"; 
//var_dump($sql);
	 if (mysqli_query($conn, $sql)) {
		  
  echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Succesfully Updateds')
   //window.location.href='faculty.php';
    </SCRIPT>");

	 }
		}
		else {
   echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('upadtion Failed!..')
   window.location.href='changestatus.php';
    </SCRIPT>");
}


	}
?>

<html>
<head>

<link href="../css/form.css" rel="stylesheet" type="text/css" media="all" />


<link href="//fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
</head>
<body>
<div class="w3_agile_main_grids">
			<section class="slider">
				<div class="flexslider">
					<ul class="slides">
						<li><div class="agileits_w3layouts_main_grid">
								<span style="color:red;font-size:285%;margin-left:85px">S</span><span style="color:black;font-size:285%">tatus</span>		<span style="color:red;font-size:285%;margin-left:5px">F</span><span style="color:black;font-size:285%">orm</span>
					<br>
								<br>
								<form action="#" method="POST">
<?php

include('../connection.php');


$query = "SELECT * FROM db_stud  where s_re='$sre' and course='BCA'";
 $result = $conn->query($query);
    while($row =$result->fetch_assoc())
	{
		$i=$row['s_re'];
		$crs=$row['course'];
		$stat=$row['status'];
		$btch=$row['batch'];
	
		if($batch=='S1')
		{
			?>
				<input type="text"  name="s2" value="S2" style="width:475px;color:black">
				<br>
						<br>
			<?php
		}
		else if($batch=='S2')
		{
			?>
			<input type="text"   name="s2" value="S3" style="width:475px;color:black">
				<br>
						<br>
			<?php
		}
		else if($batch=='S3')
		{
			
			?>
				<input type="text"  name="s2" value="S4" style="width:475px;color:black">
				<br>
						<br>
			<?php
		}
		else if($batch=='S4')
		{
			
			?>
				<input type="text"  name="s2" value="S5" style="width:475px;color:black">
					<br>
						<br>
				<?php
		}
		else if($batch=='S5')
		{
			
			?>
			<input type="text"  name="s2" value="S6" style="width:475px;color:black">
					<br>
						<br>
				<?php
		}
		else if($batch=='S6')
		{
			
			?>
			<input type="text"  name="s2" value="S6" style="width:475px;color:black">
					<br>
						<br>
				<?php
		}
	}
	$query = "SELECT * FROM db_stud  where s_re='$sre' and course='MSC'";
 $result = $conn->query($query);
    while($row =$result->fetch_assoc())
	{
		$i=$row['s_re'];
		$crs=$row['course'];
		$stat=$row['status'];
		$btch=$row['batch'];
	
		if($batch=='S1')
		{
			?>
				<input type="text" name="s2" value="S2" style="width:475px;color:black">
				<br>
						<br>
			<?php
		}
	}
?>
<span>
									
									<input type="radio" name="st" value="Ongoing" checked>Ongoing&nbsp;&nbsp;&nbsp;<input type="radio" name="st" value="Paassout">Passout
										
							<span style="color:red;margin-left:150px"><?php echo (isset($stat_err))?$stat_err:""?></span>
								</span><br>
								
								<div class="w3_agileits_submit">
										<input type="Submit" value="UPDATE" name="add">	
										<!--<input type="reset" value="reset">-->
									</div>
								</form>
							</div>
						</li>
						
						
					</ul>
				</div>
			</section>
		</div>
		
	</div>
<!-- password -->











						
<?php
include('facultyfooter.php');
?>	