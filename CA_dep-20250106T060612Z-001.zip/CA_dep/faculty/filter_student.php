<!DOCTYPE html>
<html lang="en">
<head>

	<link href="../csss/style.css" rel='stylesheet' type='text/css'/>
	<link href="//fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Roboto+Condensed:300,400" rel="stylesheet">
	<link href="../csss/popuo-box.css" rel="stylesheet" type="text/css" media="all" />

		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="Accessible Profile Widget Responsive Widget,Login form widgets, Sign up Web forms , Login signup Responsive web form,Flat Pricing table,Flat Drop downs,Registration Forms,News letter Forms,Elements" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
			<script src="js/jquery.min.js"></script>
			<script>$(document).ready(function(c) {
			$('.alert-close').on('click', function(c){
				$('.main-agile').fadeOut('slow', function(c){
					$('.main-agile').remove();
				});
			});	  
		});
		</script>
</head>

<?php
include('facultyheader.php');
include('../connection.php');
$sre=$_GET['search'];
$cou=$_GET['course'];
$batch=$_GET['batch'];
$query = "SELECT * FROM db_stud  where s_re='$sre' and course='$cou' and batch='$batch'";
$eqr=mysqli_query($conn, $query);
 $r=$eqr->fetch_assoc();
$c= $eqr->num_rows;
//var_dump($r);
if($c==0)
{
	echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('No Data Found')
    window.location.href='faculty.php';
    </SCRIPT>");
}
$query = "SELECT * FROM db_stud  where s_re='$sre'";
 $result = $conn->query($query);
    while($row =$result->fetch_assoc())
	{
		$i=$row['s_re'];
		$img=$row['s_photo'];
		$name=$row['s_name'];
		$addr=$row['s_add'];
		$dob=$row['s_dob'];
		$gen=$row['s_gender'];
		$ph=$row['s_ph'];
		$email=$row['s_email'];
		$blood=$row['s_blood'];
		$sl=$row['s_sl'];
		$fn=$row['s_fa'];
		$mn=$row['s_ma'];
		$reli=$row['s_reli'];
		$pi=$row['s_pre_in'];
		$crs=$row['course'];
		$stat=$row['status'];
		$btch=$row['batch'];
		$tid=$row['t_id'];
	}
?>

<body>
<div >
		<span style="color:red;font-size:285%;margin-left:545px">S</span><span style="color:black;font-size:285%">tudent</span><span style="color:red;font-size:285%">P</span><span style="color:black;font-size:285%">rofile</span>
		</div>
		<div style="background-color:red;width:340px;margin-left:1150px">
<a href="changestatus.php?course=<?php echo $cou;?>&batch=<?php echo $batch;?>&s_re=<?php echo $sre;?>"style="margin-left:150px;color:white">Change Status</a>
</div>
<br>
<Br>
		<div class="main-agileits" style="height:950px">
		<div class="right-wthree">
		
		<span style="color:red">ADMISSION NUMBER:<?php echo $i;?></span>
				<img src="../images/<?php echo $img;?>" alt="image" />
				<h2><?php echo $name;?></h2>
				<br>
				
				<p style="color:white">COURSE&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<?php echo $crs;?></p>
				<br>
			<p style="color:white">SEM&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<?php echo $btch;?></p>
			<Br>
				<p style="color:white;width:150px">Second language:<?php echo $btch;?></p>
				<br>
						<p style="color:white;width:170px">Previous Instituion :<?php echo $btch;?></p>
						<br>
						<p style="color:red;width:170px">Status :<?php echo $stat;?></p>
						<br>
			</div>
			<div class="left-w3ls">
			<ul class="address">
													<li>
														<ul class="address-text">
															<li><b>ADDRES </b></li>
															<li>:&nbsp;&nbsp <?PHP echo  $addr;?></li>
														</ul>
													</li>
													<li>
														<ul class="address-text">
															<li><b>DOB </b></li>
															<li>: <?php echo $dob;?></li>
														</ul>
													</li>
													<li>
														<ul class="address-text">
															<li><b>GENDER </b></li>
															<li>:<?php echo $gen;?></li>
														</ul>
													</li>
													<li>
														<ul class="address-text">
															<li><b>GENDER </b></li>
															<li>:<?php echo $gen;?></li>
														</ul>
													</li>
													<li>
														<ul class="address-text">
															<li><b>RELIGION </b></li>
															<li>&nbsp;&nbsp:<?php echo $reli;?></li>
														</ul>
													</li>
													<li>
														<ul class="address-text">
															<li><b>PHONE NUMBER </b></li>
															<li>&nbsp;&nbsp	:<?php echo $ph;?></li>
														</ul>
													</li><li>
														<ul class="address-text">
															<li><b>EMAIL </b></li>
															<li>:<?php echo $email;?></li>
														</ul>
													</li>
												<li>
														<ul class="address-text">
															<li><b>FATHER NAME </b></li>
															<li>&nbsp;&nbsp	:<?php echo $fn;?></li>
														</ul>
													</li>
													<li>
														<ul class="address-text">
															<li><b>MOTHER NAME</b></li>
															<li>&nbsp;&nbsp	:<?php echo $mn;?></li>
														</ul>
													</li>
													
												</ul>
				
			
	<!-- //pop-up-box -->
					

			</div>
			
			<div class="clear"></div>
		</div>
		<br>
		<br>
		<?php
		include('facultyfooter.php');
		?>