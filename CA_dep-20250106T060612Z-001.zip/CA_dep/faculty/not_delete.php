<?php
	include("../connection.php");
$i=0;
  if (count($_GET['check']) > 0 )
	  {
	    $all = implode(",", $_GET['check']);
		//var_dump($all);
	 $query="DELETE FROM db_not WHERE n_id IN ($all)";
	//var_dump($query);
	
	 $result = $conn->query($query);

		
	//echo"<script>location.reload();window.location.href='viw_sub(admin).php';</script>";     
	
	//header("location:view_user.php");
	//}
	 if ($result==TRUE) {
//echo "successful";
 echo("<SCRIPT LANGUAGE='JavaScript'>
	window.alert('Succesfully Deleted')
	window.location.href='viewnot.php';
	</SCRIPT>");

} 
else
{
//echo "failed";
 echo("<SCRIPT LANGUAGE='JavaScript'>
	window.alert('Failed')
	window.location.href='viewnot.php';
	</SCRIPT>");
header("location:view_noti.php");
}  
}
?>