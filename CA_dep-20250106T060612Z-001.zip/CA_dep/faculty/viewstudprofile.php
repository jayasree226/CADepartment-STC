<?php
include('facultyheader.php');
 $sre=$_GET['admission_no'];
if(isset($_POST['add'])=='Change Status')
{
	header('Location:changestatus.php?admission_no='.$sre);
}
if(isset($_POST['view'])=='Change Sem')
{
	header('Location:changesem.php?admission_no='.$sre);
}
?>
<br>
<br>
<form method="POST">
<div class="w3_agileits_submit" style="margin-left:950px">
										<input type="Submit" value="Change Status" name="add">	<input type="Submit" value="Change Sem" name="view">
				<!--<input type="reset" value="reset">-->
									</div>

<?php
include('../connection.php');

	 
	 
		$i=1;
		$query = "SELECT * FROM db_stud WHERE s_re=$sre";



 //You don't need a ; like you do in SQL
    $result = $conn->query($query);
	echo "<table><tr>";
    while($row =$result->fetch_assoc())
	{
		$i=$row['s_re'];
		$img=$row['s_photo'];
		$name=$row['s_name'];
		$addr=$row['s_add'];
		$dob=$row['s_dob'];
		$gen=$row['s_gender'];
		$ph=$row['s_ph'];
		$email=$row['s_email'];
		$blood=$row['s_blood'];
		$sl=$row['s_sl'];
		$fn=$row['s_fa'];
		$mn=$row['s_ma'];
		$reli=$row['s_reli'];
		$pi=$row['s_pre_in'];
		$crs=$row['course'];
		$stat=$row['status'];
		$btch=$row['batch'];
		$tid=$row['t_id'];
	
		
		if($i%2==0)
	{
	echo "</tr><tr>";

	}
	
		?>
	
	


<br>
		<br>
		<br>
<span style="color:red;font-size:285%;margin-left:485px"> PROFILE</span>		
<br>
				
	<table  border="1" style="margin-left:1550px">

<tr>
<br> 
<br>
<br>

		<div class="container" >
		<div class="services-top-grids">
			<div class="col-md-4">
			<br>
				<div class="grid1" style="margin-left:280px;width:580px">
				  <span style="color:red;margin-right:280px">ADMISSION NUMBER :<?php echo $i;?></span>
				  <br>
				  <br>
				  	<img src="../images/<?php echo $img;?>" width="150px" height="100px" style="margin-right:350px">
				
				   <span style="color:red">Name  :<?php echo $name;?></span><br>
			
			
					
				   <span>Address :<?php echo $addr;?></span>

				  <p style="color:red;margin-right:325px">DOB:<?php echo $dob;?></h5>
				 <h5>Gender :<?php echo $gen;?></h5>
				  <br><h5>Phone Number :<?php echo $ph;?></h5>
				  <br><h5>Email :<?php echo $email;?></h5>
				  <br><h5>Blood Group  :<?php echo $blood;?></h5>
				  <br><h5>Second Language  :<?php echo $sl;?></h5>
				  <br><h5>Father Name  :<?php echo $fn;?></h5>
				  <br><h5>Mother Name :<?php echo $mn;?></h5>
				  <br><h5>Religion :<?php echo $reli;?></h5>
				  <br><h5>Previous Institution:<?php echo $pi;?></h5>
				  <br><h5>Course:<?php echo $crs;?></h5>
				  <br>
				  <br><h5>Status :<?php echo $stat;?></h5>
				  <br><h5>Batch:<?php echo $btch;?></h5>
				  <br><h5>Faculty Id :<?php echo $tid;?></h5>
				
				  
				  
				  
				  
				
					
				</div>
			</div>

			
<?php
	 $i++;
	} echo "</table>";
	
	?>			
			
		</form>

 


						<br>
						</tr>
						</table>
						<br>
						<br>
<?php
include('facultyfooter.php');

?>