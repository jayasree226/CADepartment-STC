<?php
include('facultyheader.php');
?>
<script type="text/javascript">
    function ShowHideDiv(chkPassport) {
        var dvPassport = document.getElementById("dvPassport");
        dvPassport.style.display = chkPassport.checked ? "block" : "none";
    }
</script>
<div class="services">
		<span style="color:red;font-size:285%;margin-left:585px">E</span><span style="color:black;font-size:285%">vents</span>
				
	<table  border="1" style="margin-left:350px">
<form method="GET"  action="event_delete.php">
<div id="dvPassport" style="display: none">
<input type="submit"  value="DELETE"   id="txtPassportNumber"  style="margin-left:1100px; background-color: red; /* Green */; border: none;
    color: white;
    padding: 16px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;">
	</div>
<tr>

<br>
<br>
<tr>
<tr>
 
<?php
	  include('../connection.php');
		$i=0;
		$query = "SELECT * FROM db_event"; //You don't need a ; like you do in SQL
    $result = $conn->query($query);
	 echo "<table><tr>";
    while($row =$result->fetch_assoc())
	{
		$eid=$row['e_id'];
		$name=$row['title'];
		$ed=$row['desc'];
		
		
			
		if($i%3==0)
	{
	echo "</tr><tr>";

	}
	
		?>
		

		<div class="container">
		<div class="services-top-grids">
			<div class="col-md-4">
				<div class="grid1">
				<label for="chkPassport">
	<input type="checkbox"  name="check[]" id="chkPassport" onclick="ShowHideDiv(this)"  onclick="myFunction()" value="<?php echo $eid;?>" style="margin-left:2px">
</label>				
				<h4><a href="gallery.php?event_id=<?php echo $eid;?>"><?php echo $name;?></a></h4>
		<a href="change_event.php?eid=<?php echo $eid;?>" style="margin-left:160px">Change Event</a>
				</div>
			</div>

			
				
			
		

 

<?php
	 $i++;
	} echo "</table>";
	
	?>

			</div>
</div>
</div>		
				</form>
					
						</tr>
						</table>
						<br>
						<br>
						
						




					




<?php
include('facultyfooter.php');
?>