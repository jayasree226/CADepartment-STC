<?php
include('facultyheader.php');
include('../connection.php');
$f=0;
		if(isset($_POST['add']))
		{
		$old=$_POST['old'];
        if(empty($old))
        {
	     $f=1;
		 $old_err="Fill Old Password";
	
        }
       $new=$_POST['pass'];
        if(empty($new))
        {
	     $f=1;
		 $new_err="Fill New Password";
	
        }
       $con=$_POST['con'];
        if(empty($con))
        {
	     $f=1;
		 $con_err="Fill Confirm Password";
	
        }		
		$query = "SELECT * FROM db_fac where t_id='$m'"; //You don't need a ; like you do in SQL
    $result = $conn->query($query);

    while($row =$result->fetch_assoc())
	{
		$eid=$row['t_id'];
		$name=$row['paswd'];
	}
	if($old==$name)
	{
		if($new==$con)
		{
		    if($f==0)
		   {
			$up="update db_fac set paswd='$new' where t_id='$m' ";
	        $result = $conn->query($up);
		        if($result==True)
		        {
					echo ("<SCRIPT LANGUAGE='JavaScript'>
                    window.alert(' Sucessfully Changed!..')
                      window.location.href='facultyprofile.php';
                     </SCRIPT>");
		        }
	       }
		   else{
			echo ("<SCRIPT LANGUAGE='JavaScript'>
                    window.alert(' Changing Failed !..')
                      window.location.href='change_password.php';
                     </SCRIPT>");
		}
	    }
		else{
			echo ("<SCRIPT LANGUAGE='JavaScript'>
                    window.alert(' New password and confirm password does not  match !..')
                      window.location.href='change_password.php';
                     </SCRIPT>");
		}

	}
	else
	{
		echo ("<SCRIPT LANGUAGE='JavaScript'>
                    window.alert(' Pls try again !..')
                      window.location.href='change_password.php';
                     </SCRIPT>");
	}
	
}	
?>
<html>
<head>

<link href="../css/form.css" rel="stylesheet" type="text/css" media="all" />


<link href="//fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
</head>
<body>
	<div class="main">
	
		
		<div class="w3_agile_main_grids">
			<section class="slider">
				<div class="flexslider">
					<ul class="slides">
						<li>
							<div class="agileits_w3layouts_main_grid">
								<h3>Change Password Form</h3>
								<form action="#" method="POST">
								
		
									<span>
										<label style="height:45px">Old Password</label>
										<input name="old" type="password" placeholder="Old password" style="color:black" >
										<br>
										<br>
										 <span style="color:red;margin-left:180px"><?php echo (isset($old_err))?$old_err:""?></span> 
										
									</span>
									<span>
										<label>New Password</label>
										<input name="pass" type="password" placeholder="Your new Password" style="color:black;height:58px" pattern="[A-Za-z-0-8]{8}" >
										<br>
										<br>
										 <span style="color:red;margin-left:180px"><?php echo (isset($new_err))?$new_err:""?></span> 
									</span>
									<span>
										<label >Confirm Password</label>
										<input name="con" type="password" placeholder="Your Password" style="color:black;height:58px" pattern="[A-Za-z-0-8]{8}" >
										<br>
										<br>
										 <span style="color:red;margin-left:180px"><?php echo (isset($con_err))?$con_err:""?></span> 
									</span>
									
									<div class="w3_agileits_submit">
										<input type="submit" value="CHANGE" name="add">
										<!--<input type="reset" value="reset">-->
									</div>
								</form>
							</div>
						</li>
						
						
					</ul>
				</div>
			</section>
		</div>
		
	</div>
<!-- password -->
	<?php
	include('facultyfooter.php');
	?>