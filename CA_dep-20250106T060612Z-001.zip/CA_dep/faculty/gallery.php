<?php
include('facultyheader.php');
?>
<?php

include('../connection.php');
if(isset($_POST['view'])=='View Gallery')
{
	header('Location:view_gallery.php');
}
$f=0;

if(isset($_POST['add']))
	{
     
	  
	 
   $eid=$_POST['Ename'];
     if(empty($eid))
	  {
		  $f=1;
		  $eid_err="Choose event name";
	  }
	
	  $img=$_FILES['img']['name'];
	
	  if(empty($img))
	  {
		  $f=1;
		  $img_err="Fill Event image";
	  }

	 
		
	
	if($f==0)
		{			


   $sql="INSERT INTO `db_gal`(`g_photo`, `e_id`) values('$img','$eid')";
//var_dump($sql);
	 if (mysqli_query($conn, $sql)) {
		  
  echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Succesfully Added')
   window.location.href='faculty.php';
    </SCRIPT>");

	 }
		}
		else {
   echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Insertion Failed!..')
   window.location.href='gallery.php';
    </SCRIPT>");
}
	}	  
?>



	<!-- //short-->
		<html>
<head>

<link href="../css/form.css" rel="stylesheet" type="text/css" media="all" />


<link href="//fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
</head>
<body>
	<div class="main">
	
		
		<div class="w3_agile_main_grids">
			<section class="slider">
				<div class="flexslider">
					<ul class="slides">
						<li>
							<div class="agileits_w3layouts_main_grid">
								<span style="color:red;font-size:285%;margin-left:125px">E</span><span style="color:black;font-size:285%">VENT</span>		<span style="color:red;font-size:285%;margin-left:5px">G</span><span style="color:black;font-size:285%">ALLERY</span>
								<br>
								<br>
								<br>
								<form action="#" method="POST" enctype="multipart/form-data">
									<span>
									
								
										<br>
										<br>
									
							

						</span>
						<span>
						<label style="height:45px">Event Title</label>
						<select name="Ename" style="color:black" >
						<?php
	  include('../connection.php');
	
		$query = "SELECT Distinct e_id,title  FROM db_event "; //You don't need a ; like you do in SQL
    $result = $conn->query($query);
	
    while($row =$result->fetch_assoc())
	{
		echo "<option value='".$row['e_id']."'>".$row['title']."</option>";
		
	}
		
		?>
		</select>
									
										<br>
										<br>
						
							 <span style="color:red"><?php echo (isset($eid_err))?$eid_err:""?></span> 
					
						
						</span>
						<span>
										<label style="width: 22%;
    font-size: .85em;
    color: #212121;
    background: #e9e9e9;
    display: inline-block;
    padding: 13px;
    text-transform: uppercase;
    float: left;
    letter-spacing: 2px;
    text-align: center;
    border: 1px solid #e9e9e9;
	height:33px"> Image</label>
										<input type="file" name="img" >
							
	  <span style="color:red"><?php echo (isset($img_err))?$img_err:""?></span> 
							    
						</span>
						<br>
						<div class="w3_agileits_submit" >
										<input type="submit" value="ADD" name="add">	<input type="submit" value="View Gallery" name="view">
										
										<!--<input type="reset" value="reset">-->
									</div>
								</form>
							</div>
						</li>
						
						
					</ul>
				</div>
			</section>
		</div>
		
	</div>
<?php
include('facultyfooter.php');
?>