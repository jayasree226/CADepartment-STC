<?php
include('facultyheader.php');
include('../connection.php');
$f=0;
if(isset($_POST['ad']))
	{
     
	   
	  $nd=(isset($_POST['desc']))?$_POST['desc']:"";

	  if(empty($nd))
	  {
		 
		  $f=1;
		  var_dump($f);
		  $nd_err="Fill  Description";
	  }
	  $course=$_POST['course'];
	  
	  if(empty($course))
	  {
		 
		  $f=1;
	
		  $course_err="  Choose Course";
	  }
	  $batch=$_POST['batch'];
	  
	 
	  $date=date ('y-m-d');
	  
	if($f==0)
		{
			


   $sql="INSERT INTO `db_not`(`n_desc`,`n_date`,`course`,`batch`,`t_id`) values('$nd','$date','$course','$batch','$m')";
//var_dump($sql);
	 if (mysqli_query($conn, $sql))
		 {
		  
  echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Succesfully Added')
   //window.location.href='faculty.php';
    </SCRIPT>");

	 }
		}
		else {
   echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Insertion Failed!..')
  // window.location.href='notification.php';
    </SCRIPT>");
}
	}	  
?>
	<!--//banner -->
	<!-- short-->
	
	<!-- //short-->
		<html>
<head>

<link href="../css/form.css" rel="stylesheet" type="text/css" media="all" />


<link href="//fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
</head>
<body>
	<div class="main">
	
		
		<div class="w3_agile_main_grids">
			<section class="slider">
				<div class="flexslider">
					<ul class="slides">
						<li>
							<div class="agileits_w3layouts_main_grid">
								<span style="color:red;font-size:285%;margin-left:85px">N</span><span style="color:black;font-size:285%">otification</span>		
								
								<span style="color:red;font-size:285%;margin-left:5px">F</span><span style="color:black;font-size:285%">orm</span>
								<br>
								<br>
								<br>
								<form action="#" method="POST">
									<!--<span>
									<label>Events  ID</label>
										<input type="text"  name="Eid" maxlength="6">
								
										<br>
										<br>
									
							
							 <span style="color:red"><?php echo (isset($eid_err))?$eid_err:""?></span> 
						</span>-->
						
						<span>
										<label style="width: 25%;
    font-size: .85em;
    color: #212121;
    background: #e9e9e9;
    display: inline-block;
    padding: 13px;
    text-transform: uppercase;
    float: left;
    letter-spacing: 2px;
    text-align: center;
    border: 1px solid #e9e9e9;
	height:62px">Description</label>
										<textarea name="desc"  required style="padding: 13px 15px;
    color: black;
    outline: none;
    width: 73.4%;
    font-size: .85em;
    background: none;
    border: 1px solid #e9e9e9;
}
form.css:41
h1, h2, h3, h4, h5, h6, input, p, a, select, button, textarea {
    font-family: 'Montserrat', sans-serif;
    margin: 0;" >

</textarea>
							
	 <span style="color:red"><?php echo (isset($nd_err))?$nd_err:""?></span> 
							    
						</span>
						<label style="width: 25%;
    font-size: .85em;
    color: #212121;
    background: #e9e9e9;
    display: inline-block;
    padding: 13px;
    text-transform: uppercase;
    float: left;
    letter-spacing: 2px;
    text-align: center;
    border: 1px solid #e9e9e9;
	height:44px">COURSE</label>
<select id="job" name="course"  style="
    color: black;
    outline: none;
   width:150px;
    font-size: .85em;
    background: none;
    border: 1px solid #e9e9e9;
    margin: 0;" >
			<option value="" style="color:red"> Choose Course</option>
			<?php	include("../connection.php");
             // $b=$_POST['id'];

            $sql = "SELECT  DISTINCT course FROM db_stud ";
            $result = $conn->query($sql);
       
	while($row =$result->fetch_assoc())
{
	


 echo "<option style='color:red' value='".$row['course']."'>".$row['course']."</option>";

}
?>
<option value="All" style="color:red">ALL STUDENTS</option>


	</select>
	<br>
	<br>

	<label style="width: 25%;
    font-size: .85em;
    color: #212121;
    background: #e9e9e9;
    display: inline-block;
    padding: 13px;
    text-transform: uppercase;
    float: left;
    letter-spacing: 2px;
    text-align: center;
    border: 1px solid #e9e9e9;
	height:44px">BATCH</label>
						<select name="batch"  id="led"  style="
    color: red;
    outline: none;
   width:150px;
    font-size: .85em;
    background: none;
    border: 1px solid #e9e9e9;
    margin: 0;" >
		
		</select>
						
						<div class="w3_agileits_submit">
										<input type="submit" value="ADD" name="ad">
										<!--<input type="reset" value="reset">-->
									</div>
								</form>
							</div>
						</li>
						
						
					</ul>
				</div>
			</section>
		</div>
		
	</div>
	
	
	 <script type="text/javascript" src="js/"></script>
<script type="text/javascript" src="../js/jquery-1.12.4.min.js"></script>
<script type="text/javascript" src="../js/jquery.min.js"></script>
<script>
                            $('#job').change(function(){
                                //alert ("vvnn");
                                 var course = {
                            //alert("inside country3");
                            //country:$('#country').val()
                            course:$('#job option:selected').val()  
                            //alert("inside country4");
                    };  // here we are taking country id of the selected one.

                  

    $.ajax({
        type: "POST",
        url: "ajaxData.php", 
        data:course,

       //  dataType:"json",
        //return type expected as json
        success: function(states){
              
             // alert(states);
                      /*  $.each(states,function(key,val){
                   var opt = $('<option />'); 
                    opt.val(key);
                    opt.text(val);
                    $('#sub_cat').append(opt);
                   
                   
               });*/
			 $('#led').html(states);
		
	
		
        },
     error: function(xhr,err){
    alert("readyState: "+xhr.readyState+"\nstatus: "+xhr.status);
    alert("responseText: "+xhr.responseText);
},
    });
});
                            </script>
							
	

<?php
include('facultyfooter.php');

?>