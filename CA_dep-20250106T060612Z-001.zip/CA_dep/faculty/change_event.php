<?php
include('facultyheader.php');
include('../connection.php');
$eid=$_GET['eid'];
$f=0;

if(isset($_POST['add']))
	{
     
	  
	  $name=$_POST['Ename'];

	  if(empty($name))
	  {
		  $f=1;
		  $name_err="Fill  Title";
	  }
	  $ed=$_POST['EventDesc'];
	
	  if(empty($ed))
	  {
		  $f=1;
		  $ed_err="Fill Event Description";
	  }

	  $date=date ('y-m-d');
		
	
	if($f==0)
		{			


   $sql="UPDATE `db_event` set `title`='$name', `desc`='$ed'  where e_id='$eid'";
//var_dump($sql);
	 if (mysqli_query($conn, $sql)) {
		  
  echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Succesfully changed')
   window.location.href='more_events.php';
    </SCRIPT>");

	 }
		}
		else {
   echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Changing  Failed!..')
  window.location.href='change_event.php';
    </SCRIPT>");
}
	}	  
?>



	<!-- //short-->
		<html>
<head>

<link href="../css/form.css" rel="stylesheet" type="text/css" media="all" />


<link href="//fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
</head>
<body>
	<div class="main">
	
		
		<div class="w3_agile_main_grids">
			<section class="slider">
				<div class="flexslider">
					<ul class="slides">
						<li>
							<div class="agileits_w3layouts_main_grid">
								<span style="color:red;font-size:285%;margin-left:125px">E</span><span style="color:black;font-size:285%">VENT</span>		<span style="color:red;font-size:285%;margin-left:5px">F</span><span style="color:black;font-size:285%">ORM</span>
								<br>
								<br>
								<br>
								<form action="#" method="POST">
									<span>
									<?php
include('../connection.php');

	 
	 
	
		$query = "SELECT * FROM db_event WHERE e_id='$eid'";
    $result = $conn->query($query);
    while($row =$result->fetch_assoc())
	{
		$i=$row['e_id'];
		$t=$row['title'];
		$d=$row['desc'];
	}
	?>
								
										<br>
										<br>
									
							
<!--<span style="color:red"><</span> -->
						</span>
						<span>
						<label style="width: 25%;"> Title</label>
										<input type="text" name="Ename" style="color:white" value="<?php echo $t;?>" >
										<br>
										<br>
						
							 <span style="color:red"><?php echo (isset($name_err))?$name_err:""?></span> 
					
						
						</span>
						<span>
										<label style="width: 25%;
    font-size: .85em;
    color: #212121;
    background: #e9e9e9;
    display: inline-block;
    padding: 13px;
    text-transform: uppercase;
    float: left;
    letter-spacing: 2px;
    text-align: center;
    border: 1px solid #e9e9e9;
	height:60px"> Description</label>
										<textarea name="EventDesc"  style="padding: 13px 15px;
    color: white;
    outline: none;
    width: 67.4%;
    font-size: .85em;
    background: none;
    border: 1px solid #e9e9e9;
}
form.css:41
h1, h2, h3, h4, h5, h6, input, p, a, select, button, textarea {
    font-family: 'Montserrat', sans-serif;
    margin: 0;"><?php echo $d;?>

</textarea> <br>
							
	  <span style="color:red"><?php echo (isset($ed_err))?$ed_err:""?></span> 
							    
						</span>
						
						<div class="w3_agileits_submit" >
										<input type="submit" value="Change" name="add">	
										
										<!--<input type="reset" value="reset">-->
									</div>
								</form>
							</div>
						</li>
						
						
					</ul>
				</div>
			</section>
		</div>
		
	</div>
<?php
include('facultyfooter.php');

?>