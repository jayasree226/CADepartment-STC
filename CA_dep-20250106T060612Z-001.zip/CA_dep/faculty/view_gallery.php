<?php
include('facultyheader.php');
?>
<div class="services">
		<span style="color:red;font-size:285%;margin-left:585px">E</span><span style="color:black;font-size:285%">vents</span>
				
	<table  border="1" style="margin-left:350px">
<form method="GET"  action="event_delete.php">

<tr>

<br>
<br>
<tr>
<tr>
 
<?php
	  include('../connection.php');
		$i=0;
		$query = "SELECT * FROM db_event"; //You don't need a ; like you do in SQL
    $result = $conn->query($query);
	 echo "<table><tr>";
    while($row =$result->fetch_assoc())
	{
		$eid=$row['e_id'];
		$name=$row['title'];
		$ed=$row['desc'];
		
		
			
		if($i%3==0)
	{
	echo "</tr><tr>";

	}
	
		?>
		

		<div class="container">
		<div class="services-top-grids">
			<div class="col-md-4">
				<div class="grid1">

					<h4><a href="view_eventgallery.php?event_id=<?php echo $eid;?>"><?php echo $name;?></a></h4>

				</div>
			</div>

			
				
			
		

 

<?php
	 $i++;
	} echo "</table>";
	
	?>

			</div>
</div>
</div>		
				</form>
					
						</tr>
						</table>
						<br>
						<br>
						
						




					




<?php
include('facultyfooter.php');
?>