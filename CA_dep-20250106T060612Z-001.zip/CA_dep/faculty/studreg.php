<?php
include('facultyheader.php');
include('../connection.php');
if(isset($_POST['view'])=='View Students')
{
	header('Location:viewstudent.php');
}
$f=0;
if(isset($_POST['add']))
	{
      
      $img=$_FILES['img']['name'];
	// var_dump($img);
	  if(empty($img))
	  {
		  $f=1;
		  $img_err="Choose student image";
	  }
	   $id=$_POST['Rno'];
	
	// var_dump($id);
	  if(empty($id))
	  {
		  $f=1;
		  $id_err="Fill register number";
	  }
	  $name=$_POST['Name'];
//var_dump($name);
	  if(empty($name))
	  {
		  $f=1;
		  $name_err="Fill student name";
	  }
	  $addr=$_POST['Address'];
	//var_dump($addr);
	  if(empty($addr))
	  {
		  $f=1;
		  $addr_err="Fill student address";
	  }
	   $dob=$_POST['dob'];
		//	var_dump($dob);
	   if(empty($dob))
	  {
		  $f=1;
		  $dob_err="Choose Date of birth";
	  }
	  $gen=$_POST['gen'];
	//var_dump($gen);
	   if(empty($gen))
	  {
		  $f=1;
		  $gen_err="Choose student Gender";
	  }
	   
	  $ph=$_POST['Phone'];
	//var_dump($ph);
		if(empty($ph))
	  {
		  $f=1;
		  $ph_err="Fill student Phone number";
	  }  
	  $email=$_POST['Email'];
	 // var_dump($email);
	  if(empty($email))
	  {
		  $f=1;
		  $email_err="Fill student Email";
	  }  
	
	  $sl=$_POST['SLang'];
	 //  var_dump($sl);
	  
	   if(empty($sl))
	  {
		  $f=1;
		  $sl_err="Fill Second Language";
	  }  
	   $fn=$_POST['Fname'];
	   // var_dump($fn);
	   if(empty($fn))
	  {
		  $f=1;
		  $fn_err="Fill Father name";
	  } 
	  
      $mn=$_POST['Mname'];
	   //var_dump($mn);
      if(empty($mn))
	  {
		  $f=1;
		  $mn_err="Fill Mother name ";  
	  }
  $pswd=$_POST['Password'];
  // var_dump($pswd);
    if(empty($pswd))
	  {
		  $f=1;
		  $pswd_err="Fill password ";  
	  }
	  $reli=$_POST['Religion'];
	   //var_dump($reli);
	  if(empty($reli))
	  {
		  $f=1;
		  $reli_err="Fill Religion ";  
	  }
	 	  $pi=$_POST['PreInst'];
		  // var_dump($pi);
	  if(empty($pi))
	  {
		  $f=1;
		  $pi_err="Fill Previous Institution ";  
	  }
	  $crs=$_POST['course'];
	 //  var_dump($crs);
      if(empty($crs))
	  {
		  $f=1;
		  $crs_err="Fill Course ";  
	  }
  $stat=$_POST['Status'];
  // var_dump($stat);
    if(empty($stat))
	  {
		  $f=1;
		  $stat_err="Fill Status";  
	  }
	  $btch=$_POST['Batch'];
	   //var_dump($btch);
	  if(empty($btch))
	  {
		  $f=1;
		  $btch_err="Fill Batch";  
	  }
	 	  $blood=$_POST['Bgroup'];
		   // var_dump($tid);
	  if(empty($blood))
	  {
		  $f=1;
		  $blood_err="Fill Blood  Group";  
	  }
	  // var_dump($f);
	if($f==0)
		{			


   $sql="INSERT INTO `db_stud`(`s_re`, `s_photo`, `s_name`, `s_add`, `s_dob`, `s_gender`, `s_ph`, `s_email`, `s_blood`, `s_sl`, `s_fa`, `s_ma`, `s_password`, `s_reli`, `s_pre_in`, `course`, `status`, `batch`, `t_id`) values('$id','$img','$name','$addr','$dob','$gen','$ph','$email','$blood','$sl','$fn','$mn','$pswd','$reli','$pi','$crs','$stat','$btch','$m')";
//var_dump($sql);
	 if (mysqli_query($conn, $sql)) {
		  
  echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Succesfully Added')
   //window.location.href='faculty.php';
    </SCRIPT>");

	 }
		}
		else {
   echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Insertion Failed!..')
  // window.location.href='studreg.php';
    </SCRIPT>");
}
	}	  
?>
<!--//banner -->
	<!-- short-->
	
<!-- //short-->
<html>
<head>

<link href="../css/form.css" rel="stylesheet" type="text/css" media="all" />


<link href="//fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
</head>
<body>
	<div class="main">
	
		
		<div class="w3_agile_main_grids"> 
			<section class="slider"> 
				<div class="flexslider">
					<ul class="slides" > 
						<li>
							<div class="agileits_w3layouts_main_grid" >
								<span style="color:red;font-size:285%;margin-left:85px">R</span><span style="color:black;font-size:285%">egistration</span>		<span style="color:red;font-size:285%;margin-left:5px">F</span><span style="color:black;font-size:285%">orm</span>
								<br>
								<br>
								<form action="#" method="POST" enctype="multipart/form-data">
									<span>
									<label>Image</label>
										<input type="FILE"  name="img" >
							 <span style="color:red"><?php echo (isset($img_err))?$img_err:""?></span>  <br><br>
										<label style="height:49px;color:black">Reg. Number</label>
										<input type="text"  style="color:black" name="Rno" maxlength="5" style="height:50px" >
							<span style="color:red;margin-left:150px"><?php echo (isset($id_err))?$id_err:""?></span>
										
									</span><br>
									<span>
										<label>Name</label>
										<input type="text" style="color:black"  name="Name" >
							<span style="color:red;margin-left:150px"><?php echo (isset($name_err))?$name_err:""?></span> 
									</span><br>
									<span>
										<label style="width: 22%; 
    font-size: .85em;
    color: #212121;
    background: #e9e9e9;
    display: inline-block;
    padding: 13px;
    text-transform: uppercase;
    float: left;
    letter-spacing: 2px;
    text-align: center;
    border: 1px solid #e9e9e9;
	height:60px">Address</label>
										<textarea name="Address"  style="padding: 13px 15px;color:black;
    color: black;
    outline: none;
    width: 67.4%;
    font-size: .85em;
    background: none;
    border: 1px solid #e9e9e9;
}
form.css:41
h1, h2, h3, h4, h5, h6, input, p, a, select, button, textarea {
    font-family: 'Montserrat', sans-serif;
    margin: 0;">

</textarea>
	<span style="color:red;margin-left:150px"><?php echo (isset($addr_err))?$addr_err:""?></span> 
									</span><br>
									<span>
										<label>DOB</label>
										<input   type="date"  name="dob" type="date"   style="padding: 13px 15px;
    color: black;
    outline: none;
    width: 67.4%;
    font-size: .85em;
    background: none;
    border: 1px solid #e9e9e9;
	height:44px;
form.css:41
h1, h2, h3, h4, h5, h6, input, p, a, select, button, textarea {
    font-family: 'Montserrat', sans-serif;
    margin: 0;">
	<span style="color:red;margin-left:150px"><?php echo (isset($dob_err))?$dob_err:""?></span> 
									</span><br>
									
									<span>
										<label>Gender</label>
										<select  style="width: 67% !important;
    padding: 12px 15px !important;"  style="color:black" name="gen">
								<span style="color:black"><option value="Null">Gender</option>
								<option value="Female">Female</option>
								<option value="Male">Male</option>
								<option value="Other">Other</option>
							</select>
							
							<span style="color:red;margin-left:150px"><?php echo (isset($gen_err))?$gen_err:""?></span>
									</span><br>
										<span>
										<label style="height:45px">Religion</label>
									<select  style="width: 67% !important;
    padding: 12px 15px !important;"  style="color:black" name="Religion">
		<option value="Null">Choose Religion</option>
								<option value="Christian">Christian</option>
								<option value="Hindhu">Hindhu</option>
								<option value="Muslim">Muslim</option>
								
							</select>
							<span style="color:red;margin-left:150px"><?php echo (isset($reli_err))?$reli_err:""?></span> 
									</span><br>
									<span>
										<label style="height:45px">Blood Group</label>
										<input type="text"  style="color:black" name="Bgroup" placeholder="Blood Group" >
							<span style="color:red"><?php echo (isset($blood_err))?$blood_err:""?></span> 
									</span><BR>
									<span>
										<label>Ph.Number</label>
										<input type="text"  style="color:black"  name="Phone"  pattern="[0-9]{10}">
							<span style="color:red;margin-left:150px"><?php echo (isset($ph_err))?$ph_err:""?></span> 
						
									</span><br>
									<span>
										<label>Email</label>
										<input type="email"   style="color:black" name="Email" >
							<span style="color:red;margin-left:150px"><?php echo (isset($email_err))?$email_err:""?></span>
									</span><br>
										<span>
										<label style="height:50px">Father Name</label>
										<input type="text"  style="color:black" name="Fname"style="height:50px">
							<span style="color:red;margin-left:150px"><?php echo (isset($fn_err))?$fn_err:""?></span> 
									</span><br>
									<span>
										<label>Mother Name</label>
										<input type="text"  style="color:black" name="Mname" >
							<span style="color:red;margin-left:150px"><?php echo (isset($mn_err))?$mn_err:""?></span> 
									</span><br>
									
								<span>
										<label style="height:50px">Previous Institution</label>
										<input type="text"  style="color:black" name="PreInst" style="height:50px">
							<span style="color:red;margin-left:150px"><?php echo (isset($pi_err))?$pi_err:""?></span>
									</span><br>
									
	<span>
										<label style="width: 22%;
    font-size: .85em;
    color: #212121;
    background: #e9e9e9;
    display: inline-block;
    padding: 13px;
    text-transform: uppercase;
    float: left;
    letter-spacing: 2px;
    text-align: center;
    border: 1px solid #e9e9e9;
	height:50px">Second Language</label>
	<select  style="width: 67% !important;
    padding: 12px 15px !important;"   style="color:black" name="SLang">
		<option value="Null">Choose Second Language</option>
								<option value="Malayalam">Malayalam</option>
								<option value="Hindi">Hindi</option>
								
								
							</select>
									
							<span style="color:red;margin-left:150px"><?php echo (isset($sl_err))?$sl_err:""?></span> 
									</span><br>

									
									<span>
										<label>Course</label>
										<select style="width: 67% !important;
    padding: 12px 15px !important;"  style="color:black" name="course">
								<option value="">Selected Course</option>
								<option value="BCA">BCA</option>
								<option value="MSC">MSC</option>
								
							</select>
							<span style="color:red;margin-left:150px"><?php echo (isset($crs_err))?$crs_err:""?></span> 
									</span><br>
									</span>
									
									<span>
										<label> Batch</label>
											<input type="text"  style="color:black" name="Batch" value="S1" READONLY >
							<span style="color:red;margin-left:150px"><?php echo (isset($btch_err))?$btch_err:""?></span>
									</span><br>
									<span>
										<label style="height:50px">Status</label>
										
										<input type="text" name="Status"  style="height:50px;color:black" placeholder="Status" value="On going student" readonly >
							<span style="color:red;margin-left:150px"><?php echo (isset($stat_err))?$stat_err:""?></span>
									</span><br>
									<span>
										
										<input type="hidden"  style="color:black" name="TID" value="<?php echo $m;?>" >
							<span style="color:red"><?php echo (isset($tid_err))?$tid_err:""?></span>
									</span>
									<span>
										<label>Password</label>
										<input type="password"  style="color:black" name="Password" maxlength="8" style="padding: 13px 15px;
    color: #999;
    outline: none;
    width: 67.4%;
    font-size: .85em;
    background: none;
    border: 1px solid #e9e9e9;
	height:42px;
form.css:41
h1, h2, h3, h4, h5, h6, input, p, a, select, button, textarea {
    font-family: 'Montserrat', sans-serif;
    margin: 0;" >
	<span style="color:red;margin-left:150px"><?php echo (isset($pswd_err))?$pswd_err:""?></span><br> </span>
									<!--<span>
										<label>Address</label>
										<input name="Address" type="text" placeholder="Your Address" required="">
									</span>
									<span>
										<label>Address</label>
										<input name="Address" type="text" placeholder="Your Address" required="">
									</span>-->
									<div class="w3_agileits_submit">
										<input type="Submit" value="REGISTER" name="add">	<input type="Submit" value="View Students" name="view">
										<!--<input type="reset" value="reset">-->
									</div>
								</form>
							</div>
						</li>
						
						
					</ul>
				</div>
			</section>
		</div>
		
	</div>
<!-- password -->














	
<?php
include('facultyfooter.php');

?>