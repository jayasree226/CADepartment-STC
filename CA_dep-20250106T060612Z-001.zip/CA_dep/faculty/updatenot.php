<?php
include('facultyheader.php');
?>




<?php
include('facultyfooter.php');
?>