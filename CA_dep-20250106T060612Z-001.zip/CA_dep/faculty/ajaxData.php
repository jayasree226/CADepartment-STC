<?php
include('../connection.php');
if(!isset($_POST['course']))

{
}

$name=$_POST['course'];
$query = "SELECT * FROM `db_stud` WHERE course='$name'   ";
//var_dump($query);
$result= $conn->query($query);

while($row =$result->fetch_assoc())
{
 
  
	$id=$row['course'];
	$nam=$row['batch'];
	
	
	//$data['email']=$img;
	//$data['member']=$type;
	//json_encode($data); 
//	echo $nam;
	 echo '<option value="'.$row['batch'].'">'.$row['batch'].'</option>';
	 
}
?>
<option value="All" style="color:red">ALL STUDENTS</option>
