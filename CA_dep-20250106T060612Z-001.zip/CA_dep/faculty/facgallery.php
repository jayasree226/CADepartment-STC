<?php
include('facultyheader.php');
?>

<div class="services-breadcrumb">
		<div class="inner_breadcrumb">
			<ul class="short_ls">
				<li>
					<a href="index.php">Faculty Home</a>
					<span>| |</span>
				</li>
				<li>Gallery</li>
			</ul>
		</div>
	</div>
	<!-- //short-->
	<!-- Gallery -->
	<div class="gallery">
		<div class="container">
			<div class="title-div">
				<h3 class="tittle">
					<span>O</span>ur <span>G</span>allery
				</h3>
				<div class="tittle-style">

				</div>
			</div>
			<div class="agileinfo-gallery-row">
				<div class="col-xs-4 w3gallery-grids">
					<a href="../images/kji.jpg" class="imghvr-hinge-right figure">
						<img src="../images/kji.jpg" alt="" title="Our Library" />
						<div class="agile-figcaption">
							<h4>EXODUS</h4>
						</div>
					</a>
				</div>
				<div class="col-xs-4 w3gallery-grids">
					<a href="../images/xmas.jpg" class="imghvr-hinge-right figure">
						<img src="../images/xmas.jpg" alt="" title="Volleyball Sports" />
						<div class="agile-figcaption">
							<h4>CHRISTMAS CELEBRATION</h4>
						</div>
					</a>
				</div>
				<div class="col-xs-4 w3gallery-grids">
					<a href="../images/Farewell.jpg" class="imghvr-hinge-right figure">
						<img src="../images/Farewell.jpg" alt="" title="Our Computer Lab" />
						<div class="agile-figcaption">
							<h4>FAREWELL DAY</h4>
						</div>
					</a>
				</div>
				<div class="col-xs-4 w3gallery-grids">
					<a href="../images/onam.jpg" class="imghvr-hinge-right figure">
						<img src="../images/onam.jpg" alt="" title="Meditation" />
						<div class="agile-figcaption">
							<h4>ONAM CELEBRATION</h4>
						</div>
					</a>
				</div>
				<div class="col-xs-4 w3gallery-grids">
					<a href="../images/seminar.jpg" class="imghvr-hinge-right figure">
						<img src="../images/seminar.jpg" alt="" title="Science" />
						<div class="agile-figcaption">
							<h4>SEMINAR</h4>
						</div>
					</a>
				</div>
				<div class="col-xs-4 w3gallery-grids">
					<a href="../images/tour.jpg" class="imghvr-hinge-right figure">
						<img src="../images/tour.jpg" alt="" title="Group Discussion" />
						<div class="agile-figcaption">
							<h4>TRIP</h4>
						</div>
					</a>
				<!--</div>
				<div class="col-xs-4 w3gallery-grids">
					<a href="images/iv.jpg" class="imghvr-hinge-right figure">
						<img src="images/iv.jpg" alt="" title="Chemical Lab" />
						<div class="agile-figcaption">
							<h4>INDUSTRIAL VISIT</h4>
						</div>
					</a>
				</div>
				<div class="col-xs-4 w3gallery-grids">
					<a href="images/g5.jpg" class="imghvr-hinge-right figure">
						<img src="images/g5.jpg" alt="" title="Our Sports" />
						<div class="agile-figcaption">
							<h4>FRESHERS DAY</h4>
						</div>
					</a>
				</div>
				<div class="col-xs-4 w3gallery-grids">
					<a href="images/g8.jpg" class="imghvr-hinge-right figure">
						<img src="images/g8.jpg" alt="" title="Our Excellent Seminar" />
						<div class="agile-figcaption">
							<h4>SEMINAR</h4>
						</div>
					</a>
				</div>-->
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>





<?php
include('facultyfooter.php');
?>