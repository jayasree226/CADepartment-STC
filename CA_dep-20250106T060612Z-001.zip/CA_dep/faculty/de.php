<html>
<head>
<h4>Job Search</h4>	
  <script type="text/javascript"></script>
  <script src="../js/jquery-1.9.1.js"></script>
<script>
  jQuery(document).ready(function() 
  {
    jQuery.ajax(
    {
      type: 'GET',
      url: 'sample.php',
      dataType: 'JSON',
      success:function(data)
      {
        for(i=0;i<jquery(data).length;i++)>
        {
          jQuery('#jobcategory').append('<option value = '+ data[i].jobcategory+'>' + data[i].jobcategory + '</option>');
        }
      }
    });
  });
</script>

<script>
  jQuery(document).ready(function() 
  {
    jQuery.ajax(
    {
      type: 'GET',
      url: 'sample.php',
      dataType: 'JSON',
      success:function(data)
      {
        for(i=0;i<jquery(data).length;i++)>
        {
          jQuery('#jobtype').append('<option value = '+ data[i].jobtype+'>' + data[i].jobtype + '</option>');
        }
      }
    });
  });
</script>

<script>
  jQuery(document).ready(function() 
  {
    jQuery.ajax(
    {
      type: 'GET',
      url: 'sample.php',
      dataType: 'JSON',
      success:function(data)
      {
        for(i=0;i<jquery(data).length;i++)>
        {
          jQuery('#company').append('<option value = '+ data[i].company+'>' + data[i].company + '</option>');
        }
      }
    });
  });
</script>
</head>
<body>
  <form>
  <div>
   Job Categories:<select id="jobcategory">
    <option>Select Job Category</option>
    </select><br><br>

    Job Type:<select id="jobtype">
    <option>Select Job Type</option>
    </select><br><br>

    Company:<select id="company">
    <option>Select Company</option>
    </select><br><br>

    Start Date:<input type="date" class="startdate"><br><br>

    End Date:<input type="date" class="enddate"><br><br>

    No. Of Jobs:<select class="jobcount">
    <option>Select</option>
    <option>5</option>
    <option>10</option>
    <option>15</option>
    <option>20</option>
    </select><br><br>

    <input type="button" id="search" value="search">

    </br></br></br></br></br></br></br></br></br></br></br></br></div>

//1.Once i select the values in drop down i need to send the selected values to PHP. Based on the values i need to filter the jobs present in the DB.

//2.Then i need to display the job in a div using jQuery template.


    <div id="job_listing" style="" class="jobs_list">
      texttexttexttexttexttexttexttexttexttexttext
    </div>
  </form>
</body>
</html>