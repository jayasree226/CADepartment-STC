<?php
include('facultyheader.php');
 $sre=$_GET['admission_no'];
include('../connection.php');

if(isset($_POST['view'])=='View Students')
{
	header('Location:viewstudprofile.php');
}

$f=0;
if(isset($_POST['add']))
	{
		$btch=$_POST['Batch'];
	   //var_dump($btch);
	  if(empty($btch))
	  {
		  $f=1;
		  $btch_err="Fill Batch";  
	  }
if($f==0)
		{			


     $sql="UPDATE db_stud SET batch='$btch' WHERE s_re='$sre'";
//var_dump($sql);
	 if (mysqli_query($conn, $sql)) {
		  
  echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Succesfully Added')
   //window.location.href='faculty.php';
    </SCRIPT>");

	 }
		}
		else {
   echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Insertion Failed!..')
  // window.location.href='studreg.php';
    </SCRIPT>");
}

	}

?>

<html>
<head>

<link href="../css/form.css" rel="stylesheet" type="text/css" media="all" />


<link href="//fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
</head>
<body>
<div class="w3_agile_main_grids">
			<section class="slider">
				<div class="flexslider">
					<ul class="slides">
						<li><div class="agileits_w3layouts_main_grid">
								<span style="color:red;font-size:285%;margin-left:85px">S</span><span style="color:black;font-size:285%">tatus</span>		<span style="color:red;font-size:285%;margin-left:5px">F</span><span style="color:black;font-size:285%">orm</span>
					<br>
								<br>
								<form action="#" method="POST">

<span>
										<label>Batch</label>
										<select  style="width: 67% !important;
    padding: 12px 15px !important;"  name="Batch">
								<option value="S1">S1</option>
								<option value="S2">S2</option>
								<option value="S3">S3</option>
								<option value="S4">S4</option>
								<option value="S5">S5</option>
								<option value="S6">S6</option>
								
							</select>
							<span style="color:red;margin-left:150px"><?php echo (isset($btch_err))?$btch_err:""?></span>
								</span><br>
								
								<div class="w3_agileits_submit">
										<input type="Submit" value="UPDATE" name="add">	
										<!--<input type="reset" value="reset">-->
									</div>
								</form>
							</div>
						</li>
						
						
					</ul>
				</div>
			</section>
		</div>
		
	</div>
<!-- password -->











						
<?php
include('facultyfooter.php');
?>	