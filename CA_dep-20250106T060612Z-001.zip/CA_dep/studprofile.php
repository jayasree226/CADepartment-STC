<?php
include('adminheader.php');
?>

	<?php
include('../connection.php');
$id=$_GET['id'];

$query = "SELECT * FROM db_stud where s_re='$id'";

 //You don't need a ; like you do in SQL
    $result = $conn->query($query);
    while($row =$result->fetch_assoc())
	{
		$id=$row['s_re'];
		$logo=$row['s_photo'];
		$name=$row['s_name'];
		$add=$row['s_add'];
		$dob=$row['s_dob'];
		$gen=$row['s_gender'];
		$ph=$row['s_ph'];
		$email=$row['s_email'];
		$bg=$row['s_blood'];
		$sl=$row['s_sl'];
		$fn=$row['s_fa'];
		$mn=$row['s_ma'];
		$reli=$row['s_reli'];
		$pi=$row['s_pre_in'];
		$crs=$row['course'];
		$stat=$row['status'];
		$btch=$row['batch'];
		$tid=$row['t_id'];
	}
?>
<br>
	<h3 class="tittle">
					<span><?php echo $name;?></span>
					
				</h3>
	<br>


	<div style="background-color:gray;width:550px;height:850px;margin-left:390px">
		  <img src="../images/<?php echo $logo;?>" width="190px" align="right" height="190px" >
		  <br>
		  <br>
	<span style="color:red">Register Number  </span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <span style="color:black"><?php echo $id;?></span>
	<br>
	<br>
	<span style="color:red">Name  </span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span style="color:black"><?php echo $name;?> </span>  
	<br>
	<br>
	<span style="color:red">Address  </span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span style="color:black"><?php echo $add;?> </span>  
	<br>
	<br>
	<span style="color:red">DOB </span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span style="color:black"><?php echo $dob;?> </span>  
	<br>
	<br>
	<span style="color:red">Gender  </span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span style="color:black"><?php echo $gen;?> </span>  
	<br>
	<br>
	<span style="color:red">Phone Number  </span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span style="color:black"><?php echo $ph;?> </span>  
	<br>
	<br>
	<span style="color:red">Email </span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span style="color:black"><?php echo $email;?> </span>  
	<br>
	<br>
	<span style="color:red">Blood Group  </span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span style="color:black"><?php echo $bg;?> </span>  
	<br>
	<br>
	<span style="color:red">Second Language   </span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span style="color:black"><?php echo $sl;?> </span> 
<br>
	<br>
	<span style="color:red">Father Name </span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span style="color:black"><?php echo $fn;?> </span>  
<br>
	<br>
	<span style="color:red">Mother Name  </span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span style="color:black"><?php echo $mn;?> </span>  
<br>
	<br>
	<span style="color:red">Religion </span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span style="color:black"><?php echo $reli;?> </span>  
<br>
	<br>
	<span style="color:red">Previous Institution &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span> :<span style="color:black"><?php echo $pi;?> </span>  
<br>
	<br>
	<span style="color:red">Course  </span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span style="color:black"><?php echo $crs;?> </span>
<br>
	<br>
	<span style="color:red">Status  </span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span style="color:black"><?php echo $stat;?> </span>  
<br>
	<br>
	<span style="color:red">Batch  </span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span style="color:black"><?php echo $btch;?> </span>  
<br>
	<br>
	<span style="color:red">Faculty Id  </span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:<span style="color:black"><?php echo $tid;?> </span>    	
	<div style="background-color:gray;width:50px;float:right">
 
	
	</div>
	</div>
		