
<?php
session_start();
include('header.php');
include('connection.php');
$f=0;
if(isset($_POST['add']))
	{
     
	   $un=$_POST['username'];
	
	  //var_dump($id);
	  if(empty($un))
	  {
		  $f=1;
		  $un_err="Fill User Name ";
	  }
	  $pd=$_POST['Password'];

	  if(empty($pd))
	  {
		  $f=1;
		  $pd_err="Fill  Password";
	  }
	 
	  if($f==0)
		{			

	

$sql=" SELECT  `admin_id`,`admin_pass` FROM `admin` WHERE `admin_id`='$un' and `admin_pass`='$pd'";
//var_dump($sql);
$eqr=mysqli_query($conn, $sql);
 $r=$eqr->fetch_assoc();
$c= $eqr->num_rows;
//var_dump($r);
if($c==1)
{
  //$r=mysql_fetch_row($eqr);
  $id=$r['admin_id'];
  $de=$r['admin_pass'];

  //
  //var_dump("$de");
  
   //var_dump($id);

 $_SESSION['admin_id']=$id;
 
  $_SESSION['admin_pass']=$de;
 
 echo ("<SCRIPT LANGUAGE='JavaScript'>
   // window.alert('Succesfully Logined')
    window.location.href='admin/admin.php';
    </SCRIPT>");
	}
	
else
{
$sql="SELECT `t_id`, `paswd` FROM `db_fac` WHERE  `t_id` = '$un' and `paswd`='$pd'";
//var_dump($sql);
$eqr=mysqli_query($conn, $sql);
 $r=$eqr->fetch_assoc();
$c= $eqr->num_rows;
//var_dump($r);



if($c==1)
{
  //$r=mysql_fetch_row($eqr);
  $id=$r['t_id'];
  //echo $un;
 // echo $id;
  if($un==$id)
  {
	   //var_dump($id);
  $email=$r['paswd'];
$_SESSION['t_id']=$id;
 $_SESSION['paswd']=$email;
  //var_dump($_SESSION['t_id']);
  //var_dump($_SESSION['email']);
 echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Succesfully Logined')
    window.location.href='faculty/faculty.php';
    </SCRIPT>");
  }
  else{
  	echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Logined Failed')
    window.location.href='login.php';
    </SCRIPT>");
}
}
else{
 $sql="SELECT  `s_re`,`s_password` FROM `db_stud` WHERE `s_re`='$un' and `s_password`='$pd'";
 //echo $sql;
//var_dump($sql);
 $eqr=mysqli_query($conn, $sql);
 //var_dump($eqr);
 $r=$eqr->fetch_assoc();
$c= $eqr->num_rows;
//var_dump($c);
if($c==1)
{
  //$r=mysql_fetch_row($eqr);
  $admin_id=$r['s_re'];
  // var_dump($s_id);
  $email=$r['s_password'];
 
 $_SESSION['s_re']=$admin_id;
 //var_dump($_SESSION['adm_id']);
  $_SESSION['s_password']=$email;
  
  //var_dump($_SESSION['email']);
  echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Succesfully Logined')
    window.location.href='student/student.php';
    </SCRIPT>");
}
else{
	 echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Invalid Email ID & Password')
    //window.location.href='index.php';
    </SCRIPT>");
	
}
}
}
}

   
}
		  
?>

<html>
<head>

<link href="css/form.css" rel="stylesheet" type="text/css" media="all" />


<link href="//fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
</head>
<body>
	<div class="main">
	
		
		<div class="w3_agile_main_grids">
			<section class="slider">
				<div class="flexslider">
					<ul class="slides">
						<li>
							<div class="agileits_w3layouts_main_grid">
								<h3>Login Form</h3>
								<form action="#" method="POST">
									<span>
										<label style="height:45px">User Name</label>
										<input name="username" type="text" placeholder="Your User Name" style="color:black" >
										<br>
										<br>
										 <span style="color:red;margin-left:180px"><?php echo (isset($un_err))?$un_err:""?></span> 
										
									</span>
									<span>
										<label>Password</label>
										<input name="Password" type="password" placeholder="Your Password" style="color:black" >
										<br>
										<br>
										 <span style="color:red;margin-left:180px"><?php echo (isset($pd_err))?$pd_err:""?></span> 
									</span>
									<!--<span>
										<label>Mobile</label>
										<input name="Mobile" type="text" placeholder="Mobile Number" required="">
									</span>
									<span>
										<label>Fax</label>
										<input name="Fax" type="text" placeholder="Fax Number" required="">
									</span>
									<span>
										<label>Country</label>
										<select onchange="change_country(this.value)" required="">
											<option value="">Australia</option>
											<option value="">Africa</option>         
											<option value="">Belgium</option>
											<option value="">Brazil</option>
											<option value="">China</option>
											<option value="">More</option>
										</select>
									</span>
									<span>
										<label>Address</label>
										<input name="Address" type="text" placeholder="Your Address" required="">
									</span>
									<span>
										<label>Enquiry</label>
										<input name="Enquiry" type="text" placeholder="Sales Enquiry" required="">
									</span>
									<span>
										<label>ZIP / Pin</label>
										<input name="ZIP / Pin" type="text" placeholder="ZIP / Pin Code" required="">
									</span>-->
									<div class="w3_agileits_submit">
										<input type="submit" value="Login" name="add">
										<!--<input type="reset" value="reset">-->
									</div>
								</form>
							</div>
						</li>
						
						
					</ul>
				</div>
			</section>
		</div>
		
	</div>
<!-- password -->
	

	<?php
	include('footer.php');
	?>