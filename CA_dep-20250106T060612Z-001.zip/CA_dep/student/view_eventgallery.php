	<?php
	include('studentheader.php');
	?>
		<div id="lab" class="w3ls-section gallery">
		<div class="container">
			<h3 class="heading-agileinfo">Gallery<span></span></h3>
			<table  border="1" style="margin-left:350px">
			<tr>
	<?php
	include('../connection.php');
	$id=$_GET['event_id'];
	$i=0;
	
		$query = "SELECT db_gal.g_id,db_gal.g_photo,db_gal.e_id,db_event.e_id,db_event.title FROM db_gal INNER JOIN db_event on db_event.e_id=db_gal.e_id where db_gal.e_id='$id'"; //You don't need a ; like you do in SQL
    $result = $conn->query($query);
	 echo "<table><tr>";
    while($row =$result->fetch_assoc())
	{
		$eid=$row['g_id'];
		$name=$row['g_photo'];
		$na=$row['e_id'];
		$n=$row['title'];
		if($i%3==0)
	{
	echo "</tr><tr>";

	}
	
	
	?>
	
	<!-- gallery -->

			<div class="gallery-grids">
				<div class="col-sm-4 col-xs-6 gallery-grid">
					<div class="grid effect-apollo"> 
						
							<a href="change_gallery.php"><img src="../images/<?php echo $name;?>" alt="" height="150px"/></a>
							<div class="figcaption">
								<p><?php echo $n;?></p>
							</div>	
						</a> 
					</div>
				</div>
			<?php
	 $i++;
	} 
	echo "</table>";
	
	?>
	
				
				<div class="clearfix"> </div> 
			</div>
			<script src="../js/lightbox-plus-jquery.min.js"> </script>
		</div>
	</div>
	<!-- //gallery -->
<?php
include('studentfooter.php');
?>