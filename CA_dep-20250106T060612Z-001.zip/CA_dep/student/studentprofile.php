
<?php
include('studentheader.php');
include('../connection.php');
if(isset($_POST['change'])=='Change Password')
{
	header('Location:change_password.php');
}
if(isset($_POST['add'])=='Edit Profile')
{
	header('Location:edit_profile.php');
}
$query = "SELECT * FROM db_stud  where s_re='$st'";
$eqr=mysqli_query($conn, $query);
 $r=$eqr->fetch_assoc();
$c= $eqr->num_rows;
//var_dump($r);
if($c==0)
{
	echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('No Data Found')
    window.location.href='faculty.php';
    </SCRIPT>");
}
$query = "SELECT * FROM db_stud  where s_re='$st'";
 $result = $conn->query($query);
    while($row =$result->fetch_assoc())
	{
		$i=$row['s_re'];
		$img=$row['s_photo'];
		$name=$row['s_name'];
		$addr=$row['s_add'];
		$dob=$row['s_dob'];
		$gen=$row['s_gender'];
		$ph=$row['s_ph'];
		$email=$row['s_email'];
		$blood=$row['s_blood'];
		$sl=$row['s_sl'];
		$fn=$row['s_fa'];
		$mn=$row['s_ma'];
		$reli=$row['s_reli'];
		$pi=$row['s_pre_in'];
		$crs=$row['course'];
		$stat=$row['status'];
		$btch=$row['batch'];
		$tid=$row['t_id'];
	}
?>

<!DOCTYPE html>
<html lang="en" >
<head>

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Consultancy Profile Widget Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- js -->
<script src="js/jquery-2.1.3.min.js" type="text/javascript"></script>
<script type="text/javascript" src="js/sliding.form.js"></script>
<!-- //js -->
<link href="profile/css/style.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="profile/css/font-awesome.min.css" />
<link rel="stylesheet" href="profile/css/smoothbox.css" type='text/css' media="all" />
<link href="//fonts.googleapis.com/css?family=Pathway+Gothic+One" rel="stylesheet">
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
</head>
<body style="background-image:url('../images/wh.png');">
	<div class="main">
		<h1 style="color:red"> <?php echo $name;?></h1>
		<div id="navigation" style="display:none;" class="w3_agile">
			<ul>
				<li class="selected">
					<a href="#"><i class="fa fa-home" aria-hidden="true"></i><span>Home</span></a>
				</li>
				<!--<li>
					<a href="#"><i class="fa fa-folder" aria-hidden="true"></i><span>Work</span></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-envelope" aria-hidden="true"></i><span>Contact</span></a>
				</li>-->
			</ul>
		</div>
		<div id="wrapper" class="w3ls_wrapper w3layouts_wrapper">
			<div id="steps" style="margin:0 auto;" class="agileits w3_steps">
				<form id="formElem" name="formElem" action="#" method="post" class="w3_form w3l_form_fancy">
					<fieldset class="step agileinfo w3ls_fancy_step">

						<legend></legend>
						<div class="abt-agile">
							<div class="abt-agile-left">
							<img src="../images/<?php echo $img;?>"; style="background-size: cover;
    min-height: 276px;
    width: 100%;
    float: left;">
							</div>
								
							<div class="abt-agile-right">
							 <h5><span style="color:white">POSITION</span>:<?php echo $crs?></h5>
							<br>
							<br>
								<h3>ADDRES:&nbsp;&nbsp;<?php echo $addr;?></h3>
								
								<ul class="address">
									<li>
										<ul class="address-text">
											<li><b>D.O.B </b></li>
											<li>: <?php echo $dob;?></li>
										</ul>
									</li>
									<li>
										<ul class="address-text">
											<li><b>GENDER </b></li>
											<li>: <?php echo $gen;?></li>
										</ul>
									</li>
									<li>
										<ul class="address-text">
											<li><b>PHONE </b></li>
											<li>: <?php echo $ph;?></li>
										</ul>
									</li>
									
									<li>
										<ul class="address-text">
											<li><b>E-MAIL </b></li>
											<li>: <?php echo $email;?></a></li>
										</ul>
									</li>
									<li>
										<ul class="address-text">
											<li><b>BLOOD GROUP </b></li>
											<li>&nbsp;&nbsp;: <?php echo $blood;?></a></li>
										</ul>
									</li>
									<li>
										<ul class="address-text">
											<li><b>SECOND LANGUAGE </b></li>
											<li>&nbsp;&nbsp;: <?php echo $sl;?></a></li>
										</ul>
									</li>
									<li>
										<ul class="address-text">
											<li><b>FATHER NAME </b></li>
											<li>&nbsp;&nbsp;: <?php echo $fn;?></a></li>
										</ul>
									</li>
									<li>
										<ul class="address-text">
											<li><b>MOTHER NAME </b></li>
											<li>&nbsp;&nbsp;: <?php echo $mn;?></a></li>
										</ul>
									</li>
									<li>
										<ul class="address-text">
											<li><b>RELIGION  </b></li>
											<li>&nbsp;&nbsp;: <?php echo $reli;?></a></li>
										</ul>
									</li>
									<li>
										<ul class="address-text">
											<li><b>PREVIOUS INSTITUATION  </b></li>
											<li>&nbsp;&nbsp;&nbsp;&nbsp;: <?php echo $pi	;?></a></li>
										</ul>
									</li>
								</ul>
								<div class="w3_agileits_submit">
										<br>
		<br><b><input type="submit"  style="color=black" value="Edit Profile" name="add" style="background-color:white">&nbsp;&nbsp;	&nbsp;&nbsp;<input type="submit" style="color:black" value="Change Password" name="change" style="background-color:white"></b>
										
									</div>
							</div>
							
								<div class="clear"></div>
						</div>
					</fieldset>
					<!--<fieldset class="step wthree">
						<legend>Work</legend>
						<div class="work-w3agile">
							<div class="work-w3agile-top">
								<div class="agileits_w3layouts_work_grid1 w3layouts_work_grid1 hover14 column">
									<div class="w3_agile_work_effect">
										<ul>
											<li>
												<a href="images/c1.jpg" class="sb" title="Quis Nostrud Exercitation Ullamco Laboris Quis Autem Vel Eum Iure Reprehenderit">
													<figure>
														<img src="images/c1.jpg" alt=" " class="img-responsive" />
													</figure>
												</a>
											</li>
											<li>
												<a href="images/c2.jpg" class="sb" title="Quis Nostrud Exercitation Ullamco Laboris Quis Autem Vel Eum Iure Reprehenderit">
													<figure>
														<img src="images/c2.jpg" alt=" " class="img-responsive" />
													</figure>
												</a>
											</li>
											<li>
												<a href="images/c3.jpg" class="sb" title="Quis Nostrud Exercitation Ullamco Laboris Quis Autem Vel Eum Iure Reprehenderit">
													<figure>
														<img src="images/c3.jpg" alt=" " class="img-responsive" />
													</figure>
												</a>
											</li>
											<li>
												<a href="images/c4.jpg" class="sb" title="Quis Nostrud Exercitation Ullamco Laboris Quis Autem Vel Eum Iure Reprehenderit">
													<figure>
														<img src="images/c4.jpg" alt=" " class="img-responsive" />
													</figure>
												</a>
											</li>
											<li>
												<a href="images/c5.jpg" class="sb" title="Quis Nostrud Exercitation Ullamco Laboris Quis Autem Vel Eum Iure Reprehenderit">
													<figure>
														<img src="images/c5.jpg" alt=" " class="img-responsive" />
													</figure>
												</a>
											</li>
											<li>
												<a href="images/c6.jpg" class="sb" title="Quis Nostrud Exercitation Ullamco Laboris Quis Autem Vel Eum Iure Reprehenderit">
													<figure>
														<img src="images/c6.jpg" alt=" " class="img-responsive" />
													</figure>
												</a>
											</li>
												<div class="clear"></div>
										</ul> 
									</div>
								</div>
							</div>
						</div>
					</fieldset>-->
					<!--<fieldset class="step w3_agileits">
						<legend>Contact</legend>
							<div class="agilecontactw3ls-grid">
								<div class="agile-con-left">
									<form action="#" method="post">
										<input type="text" name="First Name" placeholder="FIRST NAME" required="">
										<input type="email" name="Email" placeholder="EMAIL" required="">
										<textarea name="Message" placeholder="MESSAGE" required=""></textarea>
										<div class="send-button">
											<input type="submit" value="SEND">
										</div>
									</form>
								</div>
								<div class="agile-con-right">
									<h6>Address :-</h6>
									<p><span><i class="fa fa-map-marker" aria-hidden="true"></i></span>22 Russell Street, Victoria ,Melbourne AUSTRALIA </p>
									<p><span><i class="fa fa-envelope" aria-hidden="true"></i></span><a href="#">E: info [at] domain.com</a> </p>
									<p><span><i class="fa fa-mobile" aria-hidden="true"></i></span>P: +254 2564584 / +542 8245658 </p>
									<p><span><i class="fa fa-globe" aria-hidden="true"></i></span><a href="#">W: www.w3layouts.com</a></p>
								</div>
								<div class="clear"></div>
							</div>
					</fieldset>-->
				</form>
			</div>
		</div>
		
	</div>
	<?php
include('studentfooter.php');
?>
