<?php
include('studentheader.php');
?>

<div class="agile-about w3ls-section text-center" id="about">
		<div class="container">
		<h3 class="heading-agileinfo">Welcome To Computer Application Department</h3>
			<div class="agileits-about-grid" style="text-align:justify">
				<p>Computer Application is one of the  areas in Science and technology. We providing BCA & Msc.Computer Science courses."
					The academic atmosphere at the Institute is a rare blend of modern day technical skills and the traditional emphasis on imparting knowledge. The faculty as well as the students who have qualified from the Institute have always done the country proud through their outstanding achievements and leadership qualities.

 The Department of Computer Application, the oldest and proven department among the selffinancing courses, started in June 2001 with a UG course B.Sc. Computer Science. In 2004, the department has been upgraded as PG department with M.Sc. Computer Science.
					Regarding the infrastructure, the most sophisticated department in the college, having two air conditioned labs, one for UG and the other for PG. Added one more UG course -BCA in 2002.. So far we've achieved 99% graduation in every year.
					Specific training programs are being schemed to enhance the capabilities of the students to meet the expectations of the industry. Placement activities are being re-aligned to meet the current challenges and the emerging market scenarios.
												Major companies like Infosys , Wipro  etc.. recruit from our department every year.</p>
			</div>
		</div>
	</div>
	
	<div class="stats">
		<div class="container">
		<h3 class="heading-agileinfo" >Our Department</h3>
			<div class="col-md-3 w3layouts_stats_left w3_counter_grid">
				<!--<span class="fa fa-graduation-cap" aria-hidden="true"></span>-->
				<h3>Faculties</h3>
				<p class="counter">8</p>
				
			</div>
			<div class="col-md-3 w3layouts_stats_left w3_counter_grid1">
				<!--<span class="fa fa-user" aria-hidden="true"></span>-->
				<h3>Approved Courses</h3>
				<p class="counter">2</p>
				
			</div>
			<div class="col-md-3 w3layouts_stats_left w3_counter_grid2">
				<!--<span class="fa fa-users" aria-hidden="true"></span>-->
				<h3>Happy Students</h3>
				<p class="counter">150</p>
				
			</div>
			<div class="col-md-3 w3layouts_stats_left w3_counter_grid3">
				<!--<span class="fa fa-trophy" aria-hidden="true"></span>-->
				<h3>Certified Teachers</h3>
				<p class="counter">8</p>
				
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>


<?php
include('studentfooter.php');

?>
