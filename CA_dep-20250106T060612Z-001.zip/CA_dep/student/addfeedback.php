<?php

include('studentheader.php');


if(isset($_POST['view'])=='Feedback')
{
	header('Location:viewfeedback.php');
}

include('../connection.php');
$f=0;

if(isset($_POST['add']))
	{
     
	  
	  $fd=$_POST['Fdesc'];

	  if(empty($fd))
	  {
		  $f=1;
		  $fd_err="Fill  Description";
	  }
	 

	  $date=date ('y-m-d');
		
	 
	  	
	  
	 
	   
	if($f==0)
		{			


   $sql="INSERT INTO `db_fdbck`( `f_desc`, `s_re`) values('$fd','$st')";
//var_dump($sql);
	 if (mysqli_query($conn, $sql)) {
		  
  echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Succesfully Added')
   window.location.href='addfeedback.php';
    </SCRIPT>");

	 }
		}
		else {
   echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Insertion Failed!..')
   window.location.href='addfeedback.php';
    </SCRIPT>");
}
	}	  
?>


	<!-- //short-->
	<html>
<head>

<link href="../css/form.css" rel="stylesheet" type="text/css" media="all" />


<link href="//fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
</head>
<body>
			<div class="main">
	
		
		<div class="w3_agile_main_grids">
			<section class="slider">
				<div class="flexslider">
					<ul class="slides">
						<li>
							<div class="agileits_w3layouts_main_grid">
																								<span style="color:red;font-size:285%;margin-left:85px">F</span><span style="color:black;font-size:285%">eedback</span><span style="color:red;font-size:285%;margin-left:5px">F</span><span style="color:black;font-size:285%">orm</span>
<br>
<br>
								<form action="#" method="POST">
									
									<span>
										<label style="width: 25%;
    font-size: .85em;
    color: red;
    background: #e9e9e9;
    display: inline-block;
    padding: 13px;
    text-transform: uppercase;
    float: left;
    letter-spacing: 2px;
    text-align: center;
    border: 1px solid #e9e9e9;
	height:62px">Feedback</label>
										<textarea name="Fdesc" style="padding: 13px 15px;
    color: black;
    outline: none;
    width: 67.4%;
    font-size: .85em;
    background: none;
    border: 1px solid #e9e9e9;
}
form.css:41
h1, h2, h3, h4, h5, h6, input, p, a, select, button, textarea {
    font-family: 'Montserrat', sans-serif;
    margin: 0;"  ></textarea>
							    <span style="color:red"><?php echo (isset($fd_err))?$fd_err:""?></span>
									</span>
									<span>
										
								
									</span>
									<!--<span>
										<label>Mobile</label>
										<input name="Mobile" type="text" placeholder="Mobile Number" required="">
									</span>
									<span>
										<label>Fax</label>
										<input name="Fax" type="text" placeholder="Fax Number" required="">
									</span>
									<span>
										<label>Country</label>
										<select onchange="change_country(this.value)" required="">
											<option value="">Australia</option>
											<option value="">Africa</option>         
											<option value="">Belgium</option>
											<option value="">Brazil</option>
											<option value="">China</option>
											<option value="">More</option>
										</select>
									</span>
									<span>
										<label>Address</label>
										<input name="Address" type="text" placeholder="Your Address" required="">
									</span>
									<span>
										<label>Enquiry</label>
										<input name="Enquiry" type="text" placeholder="Sales Enquiry" required="">
									</span>
									<span>
										<label>ZIP / Pin</label>
										<input name="ZIP / Pin" type="text" placeholder="ZIP / Pin Code" required="">
									</span>-->
									<div class="w3_agileits_submit">
										<input type="submit" value="Submit" name="add">		<input type="submit" value="Feedback" name="view" id="eve">	 
							
										<!--<input type="reset" value="reset">-->
									</div>
								</form>
							</div>
						</li>
						
						
					</ul>
				</div>
			</section>
		</div>
		
	</div>







<?php
include('studentfooter.php');

?>