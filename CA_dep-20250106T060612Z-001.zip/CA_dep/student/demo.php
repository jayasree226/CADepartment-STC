<input type="checkbox" name="check1" onclick="dynInput(this);" />
<input type="checkbox" name="check2" onclick="dynInput(this);" />
<input type="submit" id="insertinputs"></p>
<script>
function dynInput(cbox) {
      if (cbox.checked) {
        var input = document.createElement("input");
        input.type = "text";
        var div = document.createElement("div");
        div.id = cbox.name;
        div.innerHTML = "Text to display for " + cbox.name;
        div.appendChild(input);
        document.getElementById("insertinputs").appendChild(div);
      } else {
        document.getElementById(cbox.name).remove();
      }
    }
</script>