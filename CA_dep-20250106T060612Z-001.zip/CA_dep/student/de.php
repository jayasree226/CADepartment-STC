
<select name="type_post" required id="type_post" onchange="get_data(this.value)" >
     <option value="Select Post Type" selected>Select Post Type</option>
     <option value="Airmail" >Airmail</option>
     <option value="Airmail AD">Airmail AD</option>
     <option value="Airmail Speed Post">Airmail Speed Post</option>
     <option value="Speed Post">Speed Post</option>
     <option value="Book Post">Book Post</option>
     <option value="Ordinary Post">Ordinary Post</option>
     <option value="Registered Post">Registered Post</option>

     <option value="Registered Parcel">Registered Parcel</option>
     <option value="Parcel">Parcel
	 
	 
	 </option>
     <option v+alue="Courier">Courier</option>
 </select>
 <script>
 function get_dat
 
 a(value){
    $.ajax({
        url: "nameof ajax file .php",
        type: "POST",
        dataType: "HTML",
        async: false,
        data: {value: value}
        success: function(data) {
           //here we can populate the required fields based on value from database                
        }
     });
 }
 </script>