<?php
include('studentheader.php');
?>

<div class="services">
		<span style="color:red;font-size:285%;margin-left:585px">E</span><span style="color:black;font-size:285%">vents</span>
				
	<table  border="1" style="margin-left:350px">
<form method="GET"  action="event_search.php">

 <input type="text" name="search" placeholder="Event year"   style="width:180px;height:55px;margin-left:210px;border-top:none;border-left:none;border-right:none;border-color:red" />

&nbsp;&nbsp;
	<input type="submit"   value="SEARCH" style=" background-color: red; /* Green */; border: none;
    color: white;
   
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
height:56px">

<tr>

<br>
<br>
<br>
<br>
<tr>
<tr>
 
<?php
	  include('../connection.php');
		$i=0;
		$query = "SELECT * FROM db_event"; //You don't need a ; like you do in SQL
    $result = $conn->query($query);
	 echo "<table><tr>";
    while($row =$result->fetch_assoc())
	{
		$eid=$row['e_id'];
		$name=$row['title'];
		$ed=$row['desc'];
		$year=$row['year'];
		
		  $date=date ('Y-m-d');
		
	$y = substr($date,0,4);
	
	if($year==$y)
	{		
		
			
		if($i%3==0)
	{
	echo "</tr><tr>";

	}
	
	
		?>
		

		<div class="container">
		<div class="services-top-grids">
			<div class="col-md-4">
				<div class="grid1">
	<div id="my">
					<h4><a href="display_events.php?event_id=<?php echo $eid;?>"><?php echo $name;?></a></h4>
		</div>
		
				</div>
			</div>

			
				
			
		

 

<?php
	 $i++;
	} 
	}echo "</table>";
	
	?>

			</div>
</div>
</div>		
				</form>
					
						</tr>
						</table>
						<br>
						<br>
						
						




					






<?php
include('studentfooter.php');

?>