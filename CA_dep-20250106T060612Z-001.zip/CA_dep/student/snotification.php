<?php
include('../connection.php');
include('studentheader.php');

$up="update db_not set st_active='1' ";
  
	$result = $conn->query($up);
	
		if($result==True)
		{
	//header('Location:notification.php');
		}
		else
		{
			
	//header('Location:notification.php');
		}
    	

?>

<h3 class="tittle">
							<span style="color:red;font-size:185%;margin-left:585px">N</span><span style="color:black;font-size:185%">otification</span>

					<!--<span>F</span>orm-->
				</h3>
				
				<br>
				<br>
				
				
				
				
				
				
	<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.alert {
    padding: 20px;
    background-color: gray;
    color: white;
	width:550px;
	margin-left:455px;
}

.closebtn {
    margin-left: 15px;
    color: white;
    font-weight: bold;
    float: right;
    font-size: 22px;
    line-height: 20px;
    cursor: pointer;
    transition: 0.3s;
}

.closebtn:hover {
    color: black;
}
</style>
</head>
<body>


<?php


	  include('../connection.php');
		$query = "SELECT * FROM db_stud where s_re='$st'"; //You don't need a ; like you do in SQL
    $result = $conn->query($query);
	
    while($row =$result->fetch_assoc())
	{
		$n=$row['course'];
		//$date=$row['n_date'];
		$d=$row['batch'];
		$st=$row['status'];
		if($st=='Passout')
		{
		$query = "SELECT * FROM db_not where course='All'"; //You don't need a ; like you do in SQL
    $result = $conn->query($query);
	
    while($row =$result->fetch_assoc())
	{
		$l=$row['n_id'];
		//$date=$row['n_date'];
		$g=$row['n_desc'];
	}
	?>
	<div class="alert">
   
&nbsp;&nbsp;&nbsp; <?php echo $g;?>
</div>
<?php
	
		}
if($st=='Ongoing')
{	
		$query = "SELECT * FROM db_not where course='$n' and batch='$d'  or course='All'"; //You don't need a ; like you do in SQL
    $result = $conn->query($query);
	
    while($row =$result->fetch_assoc())
	{
		$nid=$row['n_id'];
		//$date=$row['n_date'];
		$nd=$row['n_desc'];
		
			
		
	

	
	
		?>

<div class="alert" style="background:wheat;">
   
  &nbsp;&nbsp;&nbsp; <span  style="color:black;"> <b> <?php echo $nd;?></b>
</div>

<?php
	}
	}
	}
	?>
<?php
include('studentfooter.php');
?>					