<?php
include('studentheader.php');
include('../connection.php');
$f=0;
if(isset($_POST['add']))
	{
     
	   $cid=$_POST['Cid'];
	
	  //var_dump($id);
	  if(empty($cid))
	  {
		  $f=1;
		  $cid_err="Fill Complaint id";
	  }
	  $cd=$_POST['Cdesc'];

	  if(empty($cd))
	  {
		  $f=1;
		  $cd_err="Fill  Description";
	  }
	  $id=$_POST['Rno'];
	
	  if(empty($id))
	  {
		  $f=1;
		  $id_err="Fill Student id";
	  }

	  $date=date ('y-m-d');
		
	 
	  	
	  
	 
	   
	if($f==0)
		{			


   $sql="INSERT INTO `db_com`(`c_id`, `c_desc`, `c_dat`, `s_re`) values('$cid','$cd','$date','$id')";
//var_dump($sql);
	 if (mysqli_query($conn, $sql)) {
		  
  echo ("<SCRIPT LANGUAGE='JavaScript'>
    //window.alert('Succesfully Added')
   //window.location.href='student.php';
    </SCRIPT>");

	 }
		}
		else {
   echo ("<SCRIPT LANGUAGE='JavaScript'>
    //window.alert('Insertion Failed!..')
  // window.location.href='addcomplaint.php';
    </SCRIPT>");
}
	}	  
?>

	<!-- //short-->
	
			<div class="main">
	
		
		<div class="w3_agile_main_grids">
			<section class="slider">
				<div class="flexslider">
					<ul class="slides">
						<li>
							<div class="agileits_w3layouts_main_grid">
								<h3>Complaints Form</h3>
								<form action="#" method="POST">
									<span>
										<label>User Name</label>
									<input type="text" placeholder="Complaint id" name="Cid" >
							<span style="color:red;margin-left:180px"><?php echo (isset($cid_err))?$cid_err:""?></span>
										<br>
										<br>
										
										
									</span>
									<span>
										<label>Complaint Description</label>
										<textarea name="Cdesc" placeholder="Complaint Description" style="font-size: 16px;
    color: #5a5656;
    padding: 12px;
    border: 0;
    width: 100%;
    border-bottom: 1px solid rgba(0, 0, 0, 0.45);
    background: none;
    outline: none;
    margin-bottom: 18px;" ></textarea>
	<span style="color:red;margin-left:180px"><?php echo (isset($cd_err))?$cd_err:""?></span>
									</span>
									<span>
										<label>Student Registration</label>
									<input type="text" placeholder="Student Registration" name="Rno" >
							<span style="color:red"><?php echo (isset($id_err))?$id_err:""?></span>
										<br>
										<br>
										
										
									</span>
									<!--<span>
										<label>Mobile</label>
										<input name="Mobile" type="text" placeholder="Mobile Number" required="">
									</span>
									<span>
										<label>Fax</label>
										<input name="Fax" type="text" placeholder="Fax Number" required="">
									</span>
									<span>
										<label>Country</label>
										<select onchange="change_country(this.value)" required="">
											<option value="">Australia</option>
											<option value="">Africa</option>         
											<option value="">Belgium</option>
											<option value="">Brazil</option>
											<option value="">China</option>
											<option value="">More</option>
										</select>
									</span>
									<span>
										<label>Address</label>
										<input name="Address" type="text" placeholder="Your Address" required="">
									</span>
									<span>
										<label>Enquiry</label>
										<input name="Enquiry" type="text" placeholder="Sales Enquiry" required="">
									</span>
									<span>
										<label>ZIP / Pin</label>
										<input name="ZIP / Pin" type="text" placeholder="ZIP / Pin Code" required="">
									</span>-->
									<div class="w3_agileits_submit">
										<input type="submit" value="Submit" name="add">  <input type="submit" value="Complaints" name="view">
										<!--<input type="reset" value="reset">-->
									</div>
								</form>
							</div>
						</li>
						
						
					</ul>
				</div>
			</section>
		</div>
		
	</div>
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
	

<?php
include('studentfooter.php');

?>