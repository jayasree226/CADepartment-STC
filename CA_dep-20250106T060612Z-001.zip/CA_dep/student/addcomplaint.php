<?php

include('studentheader.php');
include('../connection.php');

if(isset($_POST['view'])=='COMPLAINT')
{
	header('Location:viewcomplaints.php');
}
$f=0;
if(isset($_POST['add']))
	{
     
	  
	
	  //var_dump($id);
	  
	  $cd=$_POST['cdesc'];

	  if(empty($cd))
	  {
		  $f=1;
		  $cd_err="Fill  Description";
	  }
	 

	  $date=date ('y-m-d');
		
	 
	  
	  
	 
	   
	if($f==0)
		{			


   $sql="INSERT INTO `db_com`(`c_desc`, `c_dat`, `s_re`) values('$cd','$date','$st')";
//var_dump($sql);
	 if (mysqli_query($conn, $sql)) {
		  
  echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Succesfully Added')
   //window.location.href='student.php';
    </SCRIPT>");

	 }
		}
		else {
   echo ("<SCRIPT LANGUAGE='JavaScript'>
   window.alert('Insertion Failed!..Please enter complaint in to the box')
  //window.location.href='addcomplaint.php';
    </SCRIPT>");
}
	}	  
?>

	

	<!-- //short-->
	<html>
<head>

<link href="../css/form.css" rel="stylesheet" type="text/css" media="all" />


<link href="//fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
</head>
<body>
			<div class="main">
	
		
		<div class="w3_agile_main_grids">
			<section class="slider">
				<div class="flexslider">
					<ul class="slides">
						<li>
							<div class="agileits_w3layouts_main_grid">
																								<span style="color:red;font-size:285%;margin-left:85px">C</span><span style="color:black;font-size:285%">omplaint</span><span style="color:red;font-size:285%;margin-left:5px">F</span><span style="color:black;font-size:285%">orm</span>
<br>
<br>
								<form action="#" method="POST">
									
									<span>
										<label style="width: 25%;
    font-size: .85em;
    color: red;
    background: #e9e9e9;
    display: inline-block;
    padding: 13px;
    text-transform: uppercase;
    float: left;
    letter-spacing: 2px;
    text-align: center;
    border: 1px solid #e9e9e9;
	height:62px">Complaint</label>
										<textarea name="cdesc" style="padding: 13px 15px;
    color: black;
    outline: none;
    width: 67.4%;
    font-size: .85em;
    background: none;
    border: 1px solid #e9e9e9;
}
form.css:41
h1, h2, h3, h4, h5, h6, input, p, a, select, button, textarea {
    font-family: 'Montserrat', sans-serif;
    margin: 0;" ></textarea>
							    <span style="color:red"><?php echo (isset($fd_err))?$fd_err:""?></span>
									</span>
									<span>
										
								
									</span>
									
									<div class="w3_agileits_submit">
										<input type="submit" value="Submit" name="add">
<?php										
  include('../connection.php');

		$query = "SELECT * FROM db_com where  s_re='$st'"; //You don't need a ; like you do in SQL
   $eqr=mysqli_query($conn, $query);
 $r=$eqr->fetch_assoc();
$c= $eqr->num_rows;
//var_dump($r);
if($c>=1)
{
	?>
	
		
			
		
										<input type="submit" value="COMPLAINT" name="view" id="eve">
<?php
}
else
{
}
?>
									
							
										<!--<input type="reset" value="reset">-->
									</div>
								</form>
							</div>
						</li>
						
						
					</ul>
				</div>
			</section>
		</div>
		
	</div>		
	

<?php
include('studentfooter.php');

?>