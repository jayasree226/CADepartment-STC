<?php


include('studentheader.php');
include('../connection.php');
$f=0;
if(isset($_POST['add']))
	{
      
      $img=(isset($_FILES['img']['name']))?$_FILES['img']['name']:"";
	// var_dump($img);
	  if(empty($img))
	  {
		  
		  $img_err="Choose student image";
	  }
	  
	  $name=(isset($_POST['Name']))?$_POST['Name']:"";
//var_dump($name);
	  if(empty($name))
	  {
		  $f=1;
		  $name_err="Fill student name";
	  }
	  $addr=(isset($_POST['Address']))?$_POST['Address']:"";
	//var_dump($addr);
	  if(empty($addr))
	  {
		  $f=1;
		  $addr_err="Fill student address";
	  }
	   $dob=(isset($_POST['dob']))?$_POST['dob']:"";
		//	var_dump($dob);
	   if(empty($dob))
	  {
		  $f=1;
		  $dob_err="Choose Date of birth";
	  }
	  $gen=(isset($_POST['gen']))?$_POST['gen']:"";
	//var_dump($gen);
	   if(empty($gen))
	  {
		  $f=1;
		  $gen_err="Choose student Gender";
	  }
	   
	  $ph=(isset($_POST['Phone']))?$_POST['Phone']:"";
	//var_dump($ph);
		if(empty($ph))
	  {
		  $f=1;
		  $ph_err="Fill student Phone number";
	  }  
	  $email=(isset($_POST['Email']))?$_POST['Email']:"";
	 // var_dump($email);
	  if(empty($email))
	  {
		  $f=1;
		  $email_err="Fill student Email";
	  }  
	
	  $sl=(isset($_POST['SLang']))?$_POST['SLang']:"";
	 //  var_dump($sl);
	  
	   if(empty($sl))
	  {
		  $f=1;
		  $sl_err="Fill Second Language";
	  }  
	   $fn=(isset($_POST['Fname']))?$_POST['Fname']:"";
	   // var_dump($fn);
	   if(empty($fn))
	  {
		  $f=1;
		  $fn_err="Fill Father name";
	  } 
	  
      $mn=(isset($_POST['Mname']))?$_POST['Mname']:"";
	   //var_dump($mn);
      if(empty($mn))
	  {
		  $f=1;
		  $mn_err="Fill Mother name ";  
	  }
  
	  $reli=(isset($_POST['Religion']))?$_POST['Religion']:"";
	   //var_dump($reli);
	  if(empty($reli))
	  {
		  $f=1;
		  $reli_err="Fill Religion ";  
	  }
	 	  $pi=(isset($_POST['PreInst']))?$_POST['PreInst']:"";
		  // var_dump($pi);
	  if(empty($pi))
	  {
		  $f=1;
		  $pi_err="Fill Previous Institution ";  
	  }
	
	
	 	  $blood=(isset($_POST['Bgroup']))?$_POST['Bgroup']:"";
		   // var_dump($tid);
	  if(empty($blood))
	  {
		  $f=1;
		  $blood_err="Fill Blood  Group";  
	  }
	  // var_dump($f);
	if($f==0)
		{	
if($img==NULL)
{
   $up="UPDATE `db_stud` SET `s_name`='$name',`s_add`='$addr',`s_dob`='$dob',`s_gender`='$gen',`s_ph`='$ph',`s_email`='$email',`s_blood`='$blood',`s_sl`='$sl',`s_fa`='$fn',`s_ma`='$mn',`s_reli`='$reli',`s_pre_in`='$pi' WHERE s_re='$st' ";

	        $result = $conn->query($up);
		        if($result==True)
		        {
		         echo ("<SCRIPT LANGUAGE='JavaScript'>
                    window.alert(' Sucessfully Changed!..')
                      window.location.href='studentprofile.php';
                     </SCRIPT>");
	            }
	
}
				else
				{
					 $u="UPDATE `db_stud` SET `s_photo`='$img',`s_name`='$name',`s_add`='$addr',`s_dob`='$dob',`s_gender`='$gen',`s_ph`='$ph',`s_email`='$email',`s_blood`='$blood',`s_sl`='$sl',`s_fa`='$fn',`s_ma`='$mn',`s_reli`='$reli',`s_pre_in`='$pi' WHERE s_re='$st' ";
					 var_dump($u);
	        $resul = $conn->query($u);
		        if($resul==True)
		        {
					echo ("<SCRIPT LANGUAGE='JavaScript'>
                    window.alert(' Sucessfully Changed!..')
                      window.location.href='studentprofile.php';
                     </SCRIPT>");
				}
				
				else
				{
					echo ("<SCRIPT LANGUAGE='JavaScript'>
                    window.alert('Changing Failed!..')
                      window.location.href='edit_profile.php';
                     </SCRIPT>");
				}
				}
	}
	}
	?>

<!--//banner -->
	<!-- short-->
	
<!-- //short-->
<html>
<head>

<link href="../css/form.css" rel="stylesheet" type="text/css" media="all" />


<link href="//fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
</head>
<body>
	<div class="main">
	
		
		<div class="w3_agile_main_grids">
			<section class="slider">
				<div class="flexslider">
					<ul class="slides">
						<li>
							<div class="agileits_w3layouts_main_grid">
								<span style="color:red;font-size:285%;margin-left:85px">C</span><span style="color:black;font-size:285%">HANGE</span>		<span style="color:red;font-size:285%;margin-left:5px">P</span><span style="color:black;font-size:285%">ROFILE</span>
								<br>
								<br>
								<form action="#" method="POST" enctype="multipart/form-data">
								<?php
								include('../connection.php');

		$query = "SELECT * FROM db_stud where  s_re='$st'"; //You don't need a ; like you do in SQL
    $result = $conn->query($query);
	
    while($row =$result->fetch_assoc())
	{
		$id=$row['s_re'];
		//$date=$row['n_date'];
		$photo=$row['s_photo'];
		$name=$row['s_name'];
		$add=$row['s_add'];
		$dob=$row['s_dob'];
		$gen=$row['s_gender'];
		$ph=$row['s_ph'];
		$re=$row['s_reli'];
		$bl=$row['s_blood'];
		$em=$row['s_email'];
		$fa=$row['s_fa'];
        $ma=$row['s_ma'];
        $pr=$row['s_pre_in'];
        $sl=$row['s_sl'];
		$co=$row['course'];
        $batch=$row['batch'];
        $st=$row['status'];		
	}		
	?>		
	<span>
									<label>Image</label>
									<Br>
									<br>
									<br>
									<img src="../images/<?php echo $photo;?>">
										<input type="FILE"  name="img" >
							 <span style="color:red"><?php echo (isset($img_err))?$img_err:""?></span>  <br><br>
										<label style="height:49px">Reg. Number</label>
										<input type="text"name="Rno" value="<?php echo $st;?>" readonly style="height:50px;color:black" >
							<span style="color:red;margin-left:150px"><?php echo (isset($id_err))?$id_err:""?></span>
										
									</span><br>
									<span>
										<label>Name</label>
										<input type="text" name="Name"  value="<?php echo $name;?>" style="color:black">
							<span style="color:red;margin-left:150px"><?php echo (isset($name_err))?$name_err:""?></span> 
									</span><br>
									<span>
										<label style="width: 23%;
    font-size: .85em;
    color: #212121;
    background: #e9e9e9;
    display: inline-block;
    padding: 13px;
    text-transform: uppercase;
    float: left;
    letter-spacing: 2px;
    text-align: center;
    border: 1px solid #e9e9e9;
	height:62px">Address</label>
										<textarea name="Address"  style="padding: 13px 15px;
    color: black;
    outline: none;
    width: 67.0%;
    font-size: .85em;
    background: none;
    border: 1px solid #e9e9e9;
	
}
form.css:41
h1, h2, h3, h4, h5, h6, input, p, a, select, button, textarea {
    font-family: 'Montserrat', sans-serif;
    margin: 0;"><?php echo $add;?>

</textarea>
	<span style="color:red;margin-left:150px"><?php echo (isset($addr_err))?$addr_err:""?></span> 
									</span><br>
									<span>
										<label>DOB</label>
										<input   type="date" name="dob" type="date"  value="<?php echo $dob;?>"  style="padding: 13px 15px;
    color: black;
    outline: none;
    width: 67.4%;
    font-size: .85em;
    background: none;
    border: 1px solid #e9e9e9;
	height:44px;
form.css:41
h1, h2, h3, h4, h5, h6, input, p, a, select, button, textarea {
    font-family: 'Montserrat', sans-serif;
    margin: 0;">
	<span style="color:red;margin-left:150px"><?php echo (isset($dob_err))?$dob_err:""?></span> 
									</span><br>
									
									<span>
										<label>Gender</label>
										<select  style="width: 67% !important;
    padding: 12px 15px !important;color:black"  name="gen" >
	
			
								<option value="<?php echo $gen;?>"><?php echo $gen;?></option>
								<option value="Female" style="color:red">Female</option>
								<option value="Male" style="color:red">Male</option>
								<option value="Other" style="color:red">Other</option>
							</select>
							
							<span style="color:red;margin-left:150px"><?php echo (isset($gen_err))?$gen_err:""?></span>
									</span><br>
										<span>
										<label style="height:45px">Religion</label>
									<select  style="width: 67% !important;
    padding: 12px 15px !important;color:black"  name="Religion">
		<option value="<?php echo $re;?>"><?php echo $re;?></option>
								<option value="Christian" style="color:red">Christian</option>
								<option value="Hindhu" style="color:red">Hindhu</option>
								<option value="Muslim" style="color:red">Muslim</option>
								
							</select>
							<span style="color:red;margin-left:150px"><?php echo (isset($reli_err))?$reli_err:""?></span> 
									</span><br>
									<span>
										<label style="height:45px">Blood Group</label>
										<input type="text"  name="Bgroup"  value="<?php echo $bl;?>" placeholder="Blood Group" style="color:black" >
							<span style="color:red"><?php echo (isset($blood_err))?$blood_err:""?></span> 
									</span><BR>
									<span>
										<label>Ph.Number</label>
										<input type="text"  name="Phone" value="<?php echo $ph;?>" style="color:black">
							<span style="color:red;margin-left:150px"><?php echo (isset($ph_err))?$ph_err:""?></span> 
						
									</span><br>
									<span>
										<label>Email</label>
										<input type="email"  name="Email"  value="<?php echo $em;?>" style="color:black">
							<span style="color:red;margin-left:150px"><?php echo (isset($email_err))?$email_err:""?></span>
									</span><br>
										<span>
										<label style="height:50px">Father Name</label>
										<input type="text" name="Fname" value="<?php echo $fa;?>" style="color:black;height:50px">
							<span style="color:red;margin-left:150px"><?php echo (isset($fn_err))?$fn_err:""?></span> 
									</span><br>
									<span>
										<label style="height:48px">Mother Name</label>
										<input type="text" name="Mname" value="<?php echo $ma;?>" style="color:black;" >
							<span style="color:red;margin-left:150px"><?php echo (isset($mn_err))?$mn_err:""?></span> 
									</span><br>
									
								<span>
										<label style="height:50px;width:120px">Previous Institution</label>
										<input type="text" name="PreInst" value="<?php echo $pr;?>" style="color:black">
							<span style="color:red;margin-left:150px"><?php echo (isset($pi_err))?$pi_err:""?></span>
									</span><br>
									
	<span>
										<label style="width: 22%;
    font-size: .85em;
    color:  #212121;;
    background: #e9e9e9;
    display: inline-block;
    padding: 13px;
    text-transform: uppercase;
    float: left;
    letter-spacing: 2px;
    text-align: center;
    border: 1px solid #e9e9e9;
	height:43px">Second Language</label>
	<select  style="width: 67% !important;
    padding: 12px 15px !important;" style="color:black"   name="SLang">
		<option value="<?php echo $sl;?>" style="color:white" ><?php echo $sl;?></option>
								<option value="Malayalam" style="color:red">Malayalam</option>
								<option value="Hindi" style="color:red">Hindi</option>
								
								
							</select>
									
							<span style="color:red;margin-left:150px"><?php echo (isset($sl_err))?$sl_err:""?></span> 
									</span><br>

									
									<span>
										<label>Course</label>
										<input type="text" name="course" value="<?php echo $co;?>" style="color:black" readonly>
							<span style="color:red;margin-left:150px"><?php echo (isset($crs_err))?$crs_err:""?></span> 
									</span><br>
									</span>
									
									<span>
										<label> Batch</label>
											<input type="text"  name="Batch" value="<?php echo $batch;?>" READONLY  style="color:black">
							<span style="color:red;margin-left:150px"><?php echo (isset($btch_err))?$btch_err:""?></span>
									</span><br>
									<span>
										<label style="height:50px">Status</label>
										
										<input type="text" name="Status" style="height:50px;color:black" placeholder="Status" value="<?php echo $st;?>" readonly >
							<span style="color:red;margin-left:150px"><?php echo (isset($stat_err))?$stat_err:""?></span>
									</span><br>
									<span>
										
										
							<span style="color:red"><?php echo (isset($tid_err))?$tid_err:""?></span>
									</span>
									<span>
									
									<!--<span>
										<label>Address</label>
										<input name="Address" type="text" placeholder="Your Address" required="">
									</span>
									<span>
										<label>Address</label>
										<input name="Address" type="text" placeholder="Your Address" required="">
									</span>-->
									<div class="w3_agileits_submit">
										<input type="Submit" value="CHANGE" name="add">	
										<!--<input type="reset" value="reset">-->
									</div>
								</form>
							</div>
						</li>
						
						
					</ul>
				</div>
			</section>
		</div>
		
	</div>
<!-- password -->



 
<?php
include('studentfooter.php');
?>