<?php
include('../connection.php');
include('studentheader.php');


    	

?>

<h4 class="tittle">
				
<span style="color:red;font-size:285%;margin-left:485px">F</span><span style="color:black;font-size:285%">eedback</span><span style="color:red;font-size:285%;margin-left:5px">F</span><span style="color:black;font-size:285%">orm</span>
					<!--<span>F</span>orm-->
				</h4>
				
				<br>
				<br>
				<br>
				
				
				
				
				
				
	<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.alert {
    padding: 20px;
    background-color: gray;
    color: white;
	width:550px;
	margin-left:455px;
}

.closebtn {
    margin-left: 15px;
    color: white;
    font-weight: bold;
    float: right;
    font-size: 22px;
    line-height: 20px;
    cursor: pointer;
    transition: 0.3s;
}

.closebtn:hover {
    color: black;
}
</style>
</head>
<body>
<script type="text/javascript">
    function ShowHideDiv(chkPassport) {
        var dvPassport = document.getElementById("dvPassport");
        dvPassport.style.display = chkPassport.checked ? "block" : "none";
    }
</script>

<form method="GET"  action="feedback_delete.php">
<div id="dvPassport" style="display: none">
<input type="submit" id="txtPassportNumber"  value="DELETE" style="margin-left:1100px; background-color: red; /* Green */; border: none;
    color: white;
    padding: 16px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;">
	</div>
<?php

	  include('../connection.php');

		$query = "SELECT * FROM db_fdbck where  s_re='$st'"; //You don't need a ; like you do in SQL
    $result = $conn->query($query);
	
    while($row =$result->fetch_assoc())
	{
		$nid=$row['f_id'];
		//$date=$row['n_date'];
		$nd=$row['f_desc'];
		
			
		
	

	
	
		?>

<div class="alert" style="background:wheat;">
   <label for="chkPassport">
  <strong><input type="checkbox"  name="check[]" id="chkPassport" onclick="ShowHideDiv(this)" value="<?php echo $nid;?>" style="margin-left:2px"></strong>&nbsp;&nbsp;&nbsp; <span style="color:black;">  <?php echo $nd;?>
</label>
  <br>
  <!--<a href="editfedbck.php?f_id=<?php echo $nid;?>" style="color:red;float:right;font-size:large"> Reset Feedback</a>-->
  </div>

<?php
	}
	?>
	
	</form>
<?php
include('studentfooter.php');
?>					