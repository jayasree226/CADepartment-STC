<?php
session_start();
$st=$_SESSION['s_re'];
include('../connection.php');

if(!isset($_SESSION['s_re']))
{
	header('Location:../login.php');
}
?>

<!DOCTYPE html>
<html>

<head>
	<title>CA DEPARTMENT STC</title>
	<!--/tags -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Instruction Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!--//tags -->
	<link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link href="../css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link href="../css/font-awesome.css" rel="stylesheet">
	<!-- //for bootstrap working -->
	<link href="//fonts.googleapis.com/css?family=Work+Sans:200,300,400,500,600,700" rel="stylesheet">
	
	<style>
#circle {
	width: 100px;
	height: 100px;
	background: red;
	-moz-border-radius: 50px;
	-webkit-border-radius: 50px;
	border-radius: 50px;
}
</style>	
</head>

<body>
	<!-- header -->
	<div class="header-1">
	<div class="agileits_top_menu">
		<div class="w3l_header_left">
				<ul>
					<li><i ></i> </li>
					<li><i ></i> </li>
				</ul>
			</div>
		<div class="w3l_header_right">
				<div class="w3ls-social-icons text-left">
					<!--<a class="facebook" href="#"><i class="fa fa-facebook"></i></a>
					<a class="twitter" href="#"><i class="fa fa-twitter"></i></a>
					<a class="pinterest" href="#"><i class="fa fa-pinterest-p"></i></a>-->
					<a  href="studentprofile.php"><i class="">Profile</i></a>
					<a  href="../logout.php"><i class="">Logout</i></a>
				</div>
			</div>
			<div class="clearfix"> </div>
		</div>
		<div class="content white agile-info">
			<nav class="navbar navbar-default" role="navigation">
				<div class="container">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
						<a class="navbar-brand" href="student.php">
									<a class="navbar-brand" href="admin.php">
									<h1 style="font-size: 36px;
"><span class="fa fa-book" aria-hidden="true"></span> CA <label style="color: #ff4f81;
    display: block;
    font-size: 0.3em;
    text-align: center;
    letter-spacing: 3px;
	line-spacing:8px">
	DEPARTMENT_STC</label></h1>
						</a>
					</div>
					<!--/.navbar-header-->
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<nav class="link-effect-2" id="link-effect-2">
							<ul class="nav navbar-nav">
								<li><a href="student.php" class="effect-3">Home</a></li>
								<li><a href="studentabout.php" class="effect-3">About Us</a></li>
							
								<li><a href="studentevent.php" class="effect-3">Events</a></li>
								<li><a href="addcomplaint.php" class="effect-3">Complaint</a></li>
								<li><a href="addfeedback.php"class="effect-3">Feedback</a></li>
							<?php
	  include('../connection.php');
	
		$query = "SELECT * FROM db_not where st_active='0'"; //You don't need a ; like you do in SQL
   $eqr=mysqli_query($conn, $query);
$c= $eqr->num_rows;

	if($c==0)
	{

    while($row =$eqr->fetch_assoc())
	{
		$active=$row['st_active'];
	}
		
	?>
		
								<li><a href="snotification.php" class="effect-3">Notification</a></li>
											<?php
		}
	
	
								else 
		{
			
			?>
			<li><a href="snotification.php" class="effect-3">Notifications<span id="circle" style="color:white;"><?php echo $c;?></span></a></li>
		<?php
		}
?>								
		
								<!--<li><a href="addcomplaint.php" class="effect-3">Complaint</a></li>
								<li class="dropdown">
									<a href="#" class="dropdown-toggle effect-3" data-toggle="dropdown">Student<b class="caret"></b></a>
									<ul class="dropdown-menu">
										<li><a href="studreg.php">Registration</a></li>
										<li><a href="viewstudent.php">View Students</a></li>
									</ul>
								</li>-->
								
								
							</ul>
						</nav>
					</div>
					<!--/.nav
					<!--/.navbar-collapse-->
					<!--/.navbar-->
				</div>
			</nav>
		</div>
	</div>
								
						