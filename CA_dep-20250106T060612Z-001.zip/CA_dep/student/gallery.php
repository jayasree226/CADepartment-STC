<?php
include('studentheader.php');
?>


<body>
<div id="lab" class="w3ls-section gallery">
		<div class="container">
			<h3 class="heading-agileinfo">Gallery<span></span></h3>
			<table  border="1" style="margin-left:350px">
			<tr>
<?php
	  include('../connection.php');
$event=$_GET['event_id'];
$i=0;
		$query = "SELECT * FROM db_gal where e_id='$event'"; //You don't need a ; like you do in 
    $result = $conn->query($query);
	 echo "<table><tr>";
    while($row =$result->fetch_assoc())
	{
		$eid=$row['e_id'];
		$nam=$row['g_photo'];
		
	if($i%3==0)
	{
	echo "</tr><tr>";

	}
	
		
	
			
		
		?>

<!-- gallery -->

			<div class="gallery-grids">
				<div class="col-sm-4 col-xs-6 gallery-grid">
					<div class="grid effect-apollo"> 
						
							<a href="change_gallery.php"><img src="../images/<?php echo $nam;?>" alt="" height="150px"/></a>
							<div class="figcaption">
								
							</div>	
						</a> 
					</div>
				</div>
			<?php
	 $i++;
	} 
	echo "</table>";
	
	?>

</div>


</body>
</html>
		<?php
include('studentfooter.php');
?>