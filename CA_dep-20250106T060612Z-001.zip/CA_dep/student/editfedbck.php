<?php

include('studentheader.php');
 $fid=$_GET['f_id'];
include('../connection.php');

if(isset($_POST['view'])=='View Students')
{
	header('Location:addfeedback.php');
}

$f=0;


if(isset($_POST['add']))
	{
			  $fd=$_POST['Fdesc'];

	  if(empty($fd))
	  {
		  $f=1;
		  $fd_err="Fill  Description";
	  }
		
if($f==0)
		{			


   $sql="UPDATE db_fdbck SET f_desc='$fd' WHERE f_id='$fid'"; 
//var_dump($sql);
	 if (mysqli_query($conn, $sql)) {
		  
  echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Succesfully Updated')
   window.location.href='viewfeedback.php';
    </SCRIPT>");

	 }
		}
		else {
   echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Changing Failed!..')
   window.location.href='editfedbck.php';
    </SCRIPT>");
}


	}
?>

<html>
<head>

<link href="../css/form.css" rel="stylesheet" type="text/css" media="all" />


<link href="//fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
</head>
<body>
<div class="w3_agile_main_grids">
			<section class="slider">
				<div class="flexslider">
					<ul class="slides">
						<li><div class="agileits_w3layouts_main_grid">
								<span style="color:red;font-size:285%;margin-left:85px">D</span><span style="color:black;font-size:285%">esciption</span>		<span style="color:red;font-size:285%;margin-left:5px">F</span><span style="color:black;font-size:285%">orm</span>
					<br>
								<br>
								<form action="#" method="POST">
<?php


	  include('../connection.php');
	
		$query = "SELECT * FROM db_fdbck where  f_id='$fid'"; //You don't need a ; like you do in SQL
    $result = $conn->query($query);
	
    while($row =$result->fetch_assoc())
	{
		$nid=$row['f_id'];
		//$date=$row['n_date'];
		$nd=$row['f_desc'];
	}
	?>
		
<span>
										<label style="width: 25%;
    font-size: .85em;
    color: red;
    background: #e9e9e9;
    display: inline-block;
    padding: 13px;
    text-transform: uppercase;
    float: left;
    letter-spacing: 2px;
    text-align: center;
    border: 1px solid #e9e9e9;
	height:62px">Description</label>
										<textarea name="Fdesc" style="padding: 13px 15px;
    color: black;
    outline: none;
    width: 67.4%;
    font-size: .85em;
    background: none;
    border: 1px solid #e9e9e9;
}
form.css:41
h1, h2, h3, h4, h5, h6, input, p, a, select, button, textarea {
    font-family: 'Montserrat', sans-serif;
    margin: 0;" ><?php echo $nd;?></textarea>
							    <span style="color:red"><?php echo (isset($fd_err))?$fd_err:""?></span>
									</span><br>
								
								<div class="w3_agileits_submit">
										<input type="Submit" value="UPDATE" name="add">	
										<!--<input type="reset" value="reset">-->
									</div>
								</form>
							</div>
						</li>
						
						
					</ul>
				</div>
			</section>
		</div>
		
	</div>
<!-- password -->











						
<?php
include('studentfooter.php');
?>	