<?php
include('adminheader.php');
?>
<br>
		<br>
		<br>
<span style="color:red;font-size:285%;margin-left:485px">Student</span><span style="color:black;font-size:285%">Details</span>		
<br>
				
	<table  border="1" style="margin-left:350px">

<tr>
<br> 
<br>
<br>
 <?php
	  include('../connection.php');
	  $id=$_GET['sem'];
	  $co=$_GET['course'];
	 
		$i=0;
		 echo "<table><tr>";
		$query = "SELECT * FROM db_stud WHERE batch='$id' and course='$co'"; //You don't need a ; like you do in SQL
    $result = $conn->query($query);
	
    while($row =$result->fetch_assoc())
	{
		$i=$row['s_re'];
		$logo=$row['s_photo'];
		$name=$row['s_name'];
		$course=$row['course'];
		
			
		if($i%8==0)
	{
	echo "</tr><tr>";

	}
	
		?>
		

		<div class="container" >
		<div class="services-top-grids">
			<div class="col-md-4">
				<div class="grid1" style="margin-left:40px;width:280px">
				  <h5>ADMISSION NUMBER :<?php echo $i;?></h5>
				  <br>
				  <br>
					<i><a href="view_studprofile.php?admission_no=<?php echo $i;?>"><img src="../images/<?php echo $logo;?>" width="150px" height="150px"></a></i>
					<h4><b><?php echo $name;?></b></h4>
				   <h5><?php echo $course;?></h5>
				</div>
			</div>

			
				
			
		

 

<?php
	 $i++;
	} echo "</table>";
	
	?>
						<br>
						</tr>
						</table>
						<br>
						<br>
<?php
include('adminfooter.php');

?>