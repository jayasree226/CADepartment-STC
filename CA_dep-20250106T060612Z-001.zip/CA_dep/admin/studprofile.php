
<?php
include('adminheader.php');
?>



				
	<table  border="1" style="margin-left:350px">

<tr>
<div class="services">
		<span style="color:red;font-size:285%;margin-left:585px">C</span><span style="color:black;font-size:285%">ourse</span>
<br>
<br>
<tr>
<tr>
<?php
	  include('../connection.php');
		$i=0;
	$query = "SELECT * FROM db_stud  group by course";
    $result = $conn->query($query);
	 echo "<table><tr>";
    while($row =$result->fetch_assoc())
	{
		$id=$row['s_re'];
		$logo=$row['s_photo'];
		$name=$row['s_name'];
		$add=$row['s_add'];
		$dob=$row['s_dob'];
		$gen=$row['s_gender'];
		$ph=$row['s_ph'];
		$email=$row['s_email'];
		$bg=$row['s_blood'];
		$sl=$row['s_sl'];
		$fn=$row['s_fa'];
		$mn=$row['s_ma'];
		$reli=$row['s_reli'];
		$pi=$row['s_pre_in'];
		$crs=$row['course'];
		$stat=$row['status'];
		$btch=$row['batch'];
		$tid=$row['t_id'];
		
		
			
		if($i%3==0)
	{
	echo "</tr><tr>";

	}
	
		?>
		

		<div class="container" style="margin-left:250px">
		<div class="services-top-grids">
			<div class="col-md-4">
				<div class="grid1" s>
					<i class="fa fa-graduation-cap" aria-hidden="true"></i>
					<h4><a href="course.php?course_name=<?php echo $crs;?> & batch=<?php echo $btch;?>"><?php echo $crs;?></a></h4>
		
				</div>
			</div>

			
				
			
		

 

<?php
	 $i++;
	} echo "</table>";
	
	?>

			</div>
</div>
</div>		
				
					
						</tr>
						</table>
						<br>
						<br>
						
						



<?php
include('adminfooter.php');
?>