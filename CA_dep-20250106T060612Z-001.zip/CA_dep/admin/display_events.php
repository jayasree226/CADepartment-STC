
<?php
include('adminheader.php');
?>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<?php
	  include('../connection.php');
$event=$_GET['event_id'];
		$query = "SELECT * FROM db_event where e_id='$event'"; //You don't need a ; like you do in 
    $result = $conn->query($query);
	
    while($row =$result->fetch_assoc())
	{
		$eid=$row['e_id'];
		$name=$row['title'];
		$ed=$row['desc'];
	
		
	}
			
		
		?>
		<div class="container" >
		<div class="services-top-grids">
			<div class="col-md-4">
				<div class="grid1" style="height:350px;width:1050px">
	<div id="my">
	<h3 class="heading-agileinfo" style="margin-left:10
	
	
	
	
	
	0px"><?php echo $name;?></h3>
		<p style="float:left;width:350px;color:red; line-height: 2.5;"><?php echo $ed;?></p>
					<!--<h4><a href="display_events.php?event_id=<?php echo $eid;?>"><?php echo $name;?></a></h4>-->

	</div>
	<div style="background-color:;margin-left:580px;width:400px;height:80px">
		<a href="gallery.php?event_id=<?php echo $eid;?>" STYLE="color:red;font-size:large">GALLREY
		<BR>
		<button style="font-size:24px"> <i class="material-icons">collections</a></i></button>
		</div>
				</div>
			</div>

		
			<?php
	  include('../connection.php');
$event=$_GET['event_id'];
		$query = "SELECT * FROM db_gal where e_id='$event'"; //You don't need a ; like you do in 
    $result = $conn->query($query);
	
    while($row =$result->fetch_assoc())
	{
	$p=$row['g_photo'];
	
		
	
			
		
		?>
	
			<?php
	}
	?>
	
		</div>
	</div>
		<?php
include('adminfooter.php');
?>