<?php
include('../connection.php');
include('adminheader.php');

$up="update db_not set active='1' ";
  
	$result = $conn->query($up);
	
		if($result==True)
		{
	//header('Location:notification.php');
		}
		else
		{
			
	//header('Location:notification.php');
		}
    	

?>



				
				
				
				
				
				
				
				
	<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.alert {
    padding: 20px;
    background-color: gray;
    color: white;
	width:550px;
	margin-left:455px;
}

.closebtn {
    margin-left: 15px;
    color: white;
    font-weight: bold;
    float: right;
    font-size: 22px;
    line-height: 20px;
    cursor: pointer;
    transition: 0.3s;
}

.closebtn:hover {
    color: black;
}
</style>
</head>
<body>
<span style="color:red;font-size:285%;margin-left:585px">N</span><span style="color:black;font-size:285%">otification</span>
<br>
<br>
<?php
	  include('../connection.php');
	
		$query = "SELECT * FROM db_not"; //You don't need a ; like you do in SQL
    $result = $conn->query($query);
	
    while($row =$result->fetch_assoc())
	{
		$nid=$row['n_id'];
		//$date=$row['n_date'];
		$nd=$row['n_desc'];
		$t=$row['t_id'];
		
			
		
	

	
	
		?>

<div class="alert" style="background:wheat;"> <span style="color:black;">
   
&nbsp;&nbsp;&nbsp; <?php echo $nd;?>
<br>
&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp;  <span style="color:black;"> TEACHER ID&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;:<span style="color:red"> <?php echo $t;?></span>
</div>

<?php
	}
	?>
<?php
include('adminfooter.php');
?>					