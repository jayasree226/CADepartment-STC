<?php
include('adminheader.php');
?>

<h3 class="tittle">
					<span>S</span>tudent
					<span>D</span>etails
				</h3>
				
				
				
				
				
			<br>	
				
		<form method="GET">	

		
		 <?php
	  include('../connection.php');
	
		$query = "SELECT * FROM db_stud"; //You don't need a ; like you do in SQL
    $result = $conn->query($query);
		$i=0;
	 echo "<table><tr>";
    while($row =$result->fetch_assoc())
	{
		$id=$row['s_re'];
		$logo=$row['s_photo'];
		$name=$row['s_name'];
		if($i%3==0)
	{
	echo "</tr><tr>";

	}
	
		
		?>
		<td style="padding-left:10px;padding-right:20px;">
		<div style="background-color:#333;width:350px;height:200px;margin-left:55px">
		   <span style="color:white"> Admission Number:</span><span style=" color:red"><?php echo $id;?></span></span>
		   <img src="../images/<?php echo $logo;?>" width="150x" height ="130px" Style="float:right">
		   <br>
		  
<br>

		   		 <span style="color:white"> Name:</span><span style=" color:red"><?php echo $name;?></span></span>
				 <br>
				 <br>
				 <br>
		   		<div style="background-color:white;width:90px"><a href="studprofile.php?id=<?php echo $id;?>" style="text-decoration:none;" class="effect-3"><u>View Profile</u></a>
		</div>
		</div>
				<BR>
<BR>				
							  
		  

<?php
	 $i++;
	}echo "</table>";
	
	?>
        
    

						<br>
						<br>
<?php
include('adminfooter.php');
?>					