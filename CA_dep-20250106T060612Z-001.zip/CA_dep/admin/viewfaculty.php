<?php
include('adminheader.php');

?>


				
				
	<form method="GET"  action="delete_faculty.php">

	<input type="submit"  value="DELETE" name="add" style="margin-left:1100px; background-color: red; /* Green */; border: none;
    color: white;
    padding: 16px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;">			
				
			<span style="color:red;font-size:285%;margin-left:505px">F</span><span style="color:black;font-size:285%">aculty</span>		<span style="color:red;font-size:285%;margin-left:5px">D</span><span style="color:black;font-size:285%">etails</span>
								<br>
								<br>
				
				<br>
				<br>	
<table  border="1" style="margin-left:350px">

<tr>

<!--<th>Admission Number</th>-->
<tr>
<tr>
<?php
	  include('../connection.php');
		$i=0;
		$query = "SELECT * FROM db_fac"; //You don't need a ; like you do in SQL
    $result = $conn->query($query);
	 echo "<table><tr>";
    while($row =$result->fetch_assoc())
	{
		$id=$row['t_id'];
		$logo=$row['img'];
		$name=$row['name'];
		$add=$row['add'];
		$dob=$row['dob'];
		$gender=$row['gender'];
		$ph_no=$row['ph_no'];
		$email=$row['email'];
		$qualif=$row['qualif'];
		$exprnc=$row['exprnc'];
		$position=$row['position'];
			
		if($i%2==0)
	{
	echo "</tr><tr>";

	}
	
		?>
		
		<td style="padding-left:10px;padding-right:20px;">
		<div style="background-color:Wheat;border: 1px solid black;width:650px;height:500px;margin-left:px">
	<input type="checkbox"  name="check[]" id="check[]"  class="cagree" value="<?php echo $id;?>">
		   <span style="color:white"> Teacher Id:</span><span style=" color:red"><?php echo $id;?></span></span>
		   <img src="../images/<?php echo $logo;?>" width="150x" height ="130px" Style="float:right">
		   <br>
		  
<br>

		   		 <span style="color:black"> Name:</span><span style=" color:red"><?php echo $name;?></span></span>
				 <br>
				

		   		 <span style="color:black"> Address</span><span style=" color:red"><?php echo $add;?></span></span>
				 <br>
				
				
<br>

		   		 <span style="color:black"> DOB :</span><span style=" color:red"><?php echo $dob;?></span></span>
				 <br>
				
		  
<br>

		   		 <span style="color:black"> Gender</span><span style=" color:red"><?php echo $gender;?></span></span>
				
				 <br>
		  
<br>

		   		 <span style="color:black"> Phone Number</span><span style=" color:red"><?php echo $ph_no;?></span></span>
				 <br>
				
<br>

		   		 <span style="color:black"> Email:</span><span style=" color:red"><?php echo $email;?></span></span>
				 <br>
				 
		  
<br>

		   		 <span style="color:black"> Qualification:</span><span style=" color:red"><?php echo $qualif;?></span></span>
				 <br>
				 
		  
<br>

		   		 <span style="color:black">Experience:</span><span style=" color:red"><?php echo $exprnc;?></span></span>
				 <br>
				 
		  
<br>

		   		 <span style="color:black"> Position:</span><span style=" color:red"><?php echo $position;?></span></span>
				 <br>
				 <br>
				 
		   		<!--<div style="background-color:white;width:90px"><a href="studprofile.php?id" style="text-decoration:none;" class="effect-3"><u>View Profile</u></a>
		</div>-->
		</div>
	
		
		
		<br>
		

<?php
	 $i++;
	} echo "</table>";
	
	?>

					
				
					
						</tr>
						</table>
						</form>
						<br>
						<br>
<?php
include('adminfooter.php');
?>					