<?php
include('adminheader.php');
 $sre=$_GET['admission_no'];

?>
<br>
<br>
<form method="POST">


<?php
include('../connection.php');

	 
	 
		$i=1;
		$query = "SELECT * FROM db_stud WHERE s_re=$sre";



 //You don't need a ; like you do in SQL
    $result = $conn->query($query);
	echo "<table><tr>";
    while($row =$result->fetch_assoc())
	{
		$i=$row['s_re'];
		$img=$row['s_photo'];
		$name=$row['s_name'];
		$addr=$row['s_add'];
		$dob=$row['s_dob'];
		$gen=$row['s_gender'];
		$ph=$row['s_ph'];
		$email=$row['s_email'];
		$blood=$row['s_blood'];
		$sl=$row['s_sl'];
		$fn=$row['s_fa'];
		$mn=$row['s_ma'];
		$reli=$row['s_reli'];
		$pi=$row['s_pre_in'];
		$crs=$row['course'];
		$stat=$row['status'];
		$btch=$row['batch'];
		$tid=$row['t_id'];
	
		
		if($i%2==0)
	{
	echo "</tr><tr>";

	}
	
		?>
	
	


<br>
		<br>
		<br>
<span style="color:red;font-size:285%;margin-left:485px"> PROFILE</span>		
<br>
				
	<table  border="1" style="margin-left:1550px">

<tr>
<br> 
<br>
<br>

		<div class="container" >
		<div class="services-top-grids">
			<div class="col-md-4">
			<br>
				<div class="grid1" style="margin-left:280px;width:580px">
				  <span style="color:red;margin-right:280px">ADMISSION NUMBER :<?php echo $i;?></span> <span style="float:right">Batch:<?php echo $btch;?></span>
				  <br>
				  <br>
				  	<img src="../images/<?php echo $img;?>" width="150px" height="100px" style="margin-right:350px">
				<br>
				<br>
				   <span style="color:red;float:left">Name  :<?php echo $name;?></span><br>
			
			<br>
		
				   <span style="float:left">Address :<?php echo $addr;?></span>

				  <span style="float:left">&nbsp;&nbsp;DOB:<?php echo $dob;?></span>
				  <br>
				  <br>
 <span style="float:left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gender :<?php echo $gen;?></span>
				  <br>
				  <br>
				  <span style="float:left">&nbsp;&nbsp;Phone Number :<?php echo $ph;?></span>  <h5>Email :<?php echo $email;?></h5>
				<br>
			
				  <span style="float:left">&nbsp;&nbsp;Blood Group  :<?php echo $blood;?></span>   <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Second Language  :<?php echo $sl;?></span>
<br>
<br>
  <span style="float:left">&nbsp;&nbsp;Father Name  :<?php echo $fn;?></span> <h5>Mother Name :<?php echo $mn;?></h5>
				 <br>
				 
				 <span style="float:left">&nbsp;&nbsp;Religion :<?php echo $reli;?></span><h5>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Previous Institution:<?php echo $pi;?></h5>
			<br>
<span style="float:left">&nbsp;&nbsp;Course:<?php echo $crs;?></span> <h5>&nbsp;&nbsp;&nbsp;&nbsp;Status :<?php echo $stat;?></h5>
				  <br>
				 
				 
				  
				
					
				</div>
			</div>

			
<?php
	 $i++;
	} echo "</table>";
	
	?>			
			
		</form>

 


						<br>
						</tr>
						</table>
						<br>
						<br>
<?php
include('adminfooter.php');

?>