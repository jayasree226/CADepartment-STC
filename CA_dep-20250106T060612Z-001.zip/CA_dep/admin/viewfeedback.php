<?php
include('adminheader.php');
?>


				
				
				
				
				
				
				
				
	<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.alert {
    padding: 20px;
    background-color: gray;
    color: white;
	width:550px;
	margin-left:455px;
}

.closebtn {
    margin-left: 15px;
    color: white;
    font-weight: bold;
    float: right;
    font-size: 22px;
    line-height: 20px;
    cursor: pointer;
    transition: 0.3s;
}

.closebtn:hover {
    color: black;
}
</style>
</head>
<body>
<span style="color:red;font-size:285%;margin-left:585px">F</span><span style="color:black;font-size:285%">eedback</span>
<br>
<br>

<?php
	
	
		
	  include('../connection.php');
		$i=0;
		$query = "SELECT  db_fdbck. f_id, db_fdbck.f_desc,db_fdbck.s_re,db_stud.s_re,db_stud.s_name from db_fdbck inner join db_stud on
		db_stud.s_re=db_fdbck.s_re"; //You don't need a ; like you do in SQL
    $result = $conn->query($query);
	 echo "<table><tr>";
    while($row =$result->fetch_assoc())
	{
		$fid=$row['f_id'];
		$fd=$row['f_desc'];
		$id=$row['s_re'];
		$name=$row['s_name'];
		
	

	
	
		?>

<div class="alert" style="background:wheat;">
    <strong style="color:red;">Admission Number :<span style="color:black;"><?php echo $id;?></strong>&nbsp;&nbsp;&nbsp;
	<strong style="color:red"> Student Name  :</strong><strong style="color:black"><?php echo $name;?></strong>
	<br>
	<br>
  <strong style="color:black"><?php echo $fd;?></strong>&nbsp;&nbsp;&nbsp; 
</div>

<?php
	}
	?>
<?php
include('adminfooter.php');
?>					

		
		
		
			
		