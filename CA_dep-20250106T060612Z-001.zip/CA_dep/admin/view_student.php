<?php
include('adminheader.php');
?>
<br>
<br>
<html>
<head>
<script> 
    function show() { 
        if(document.getElementById('benefits').style.display=='none') { 
            document.getElementById('benefits').style.display='block'; 
        } 
        return false;
    } 
    function hide() { 
        if(document.getElementById('benefits').style.display=='block') { 
            document.getElementById('benefits').style.display='none'; 
        } 
        return false;
    }   
</script> 
<script> 
    function sho() { 
        if(document.getElementById('benefit').style.display=='none') { 
            document.getElementById('benefit').style.display='block'; 
        } 
        return false;
    } 
    function hide() { 
        if(document.getElementById('benefit').style.display=='block') { 
            document.getElementById('benefit').style.display='none'; 
        } 
        return false;
    }   
</script> 
<link href="../css/form.css" rel="stylesheet" type="text/css" media="all" />


<link href="//fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
</head>
<body>
	<div class="main">
	
			<form method="GET">	
		<div class="w3_agile_main_grids">
			<section class="slider">
				<div class="flexslider">
					<ul class="slides">
						<li>
							
								<span style="color:red;font-size:285%;margin-left:185px">Course</span><span style="color:black;font-size:285%">Details</span>		
								<br>
								<br>
								</li>
								</ul>
						
								</section>
								</div>
								<br>
								<br>
				<div class="w3_agileits_submit">
				<div style="background-color:;width:250px;float:right;margin-right:450px">
				<br>
				<br>
				
				 <div id="opener"><input type="Submit" name="1" value="MSC.COMPUTER SCIENCE" onclick="return sho();"  style="width:350px"></div> 
				   				   	<div id="benefit" style="display:none;float:left">
	<br>
	<Br>
	 <?php
	  include('../connection.php');
		
		$query = "SELECT  batch  FROM db_stud where course='MSC' group by batch "; //You don't need a ; like you do in SQL
    $result = $conn->query($query);
    while($row =$result->fetch_assoc())
	{
		
		$name=$row['batch'];
	
		?>
	<a href="sem.php?sem=<?php echo $name;?> &course=MSC"><span style="color:red;margin-left:80px"><?php echo $name;?></a></span>

	<?php
	}
	?>
   
   
    </div>
				   </div>
 	
				   	<div style="background-color:;width:250px;float:left;margin-left:380px">
				<br>
				<br>
				 <div id="opener"><input type="Submit" name="1" value="BCA" onclick="return show();"  style="width:150px"></div> 
				   </div>
<br>
<br>
					 
   			

	<div id="benefits" style="display:none;">
	<br>
	<Br>
	 <?php
	  include('../connection.php');
		
		$query = "SELECT batch  FROM db_stud group by batch"; //You don't need a ; like you do in SQL
    $result = $conn->query($query);
    while($row =$result->fetch_assoc())
	{
		
		$name=$row['batch'];
	
		?>
		<br>
		<br>
	<a href="studsem.php?sem=<?php echo $name;?>&course=BCA"><span style="color:red;margin-left:480px"><?php echo $name;?></a></span>
	<BR>
	<br>
	<?php
	}
	?>
   
   
    </div> 

										
									 	<!--<input type="reset" value="reset">-->
									</div>
									
									
									
									
									
									
									
									
									

									
									
				
	</form>
				
				
				
				
		<br>
<br>
<br>		

			<br>
<br>
<br>		
					
						
<?php
include('adminfooter.php');
?>					