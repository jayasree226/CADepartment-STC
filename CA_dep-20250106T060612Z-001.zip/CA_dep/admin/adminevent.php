<?php
include('adminheader.php');
?>



				
	<table  border="1" style="margin-left:350px">

<tr>
<div class="services">
		<span style="color:red;font-size:285%;margin-left:585px">E</span><span style="color:black;font-size:285%">vents</span>
<br>
<br>
<form method="GET">
<tr>
<tr>
<?php
	  include('../connection.php');
		$i=0;
		$query = "SELECT * FROM db_event"; //You don't need a ; like you do in SQL
    $result = $conn->query($query);
	 echo "<table><tr>";
    while($row =$result->fetch_assoc())
	{
		$eid=$row['e_id'];
		$name=$row['title'];
		$ed=$row['desc'];
		
		
			
		if($i%3==0)
	{
	echo "</tr><tr>";

	}
	
		?>
		

		<div class="container">
		<div class="services-top-grids">
			<div class="col-md-4">
				<div class="grid1">
				<div class="w3_agileits_submit">
									<a href="view_eventgallery.php?event_id=<?php echo $eid;?>"> <img src="../images/gallery.png" width="50px" style="margin-left:20px"></a>
										<!--<input type="reset" value="reset">-->
									</div>
					
					<h4><a href="display_events.php?event_id=<?php echo $eid;?>"><?php echo $name;?></a></h4>
		
				</div>
				
			</div>
</form>
			
				
			
		

 

<?php
	 $i++;
	} echo "</table>";
	
	?>

			</div>
</div>
</div>		
				
					
						</tr>
						</table>
						<br>
						<br>
						
						



<?php
include('adminfooter.php');
?>