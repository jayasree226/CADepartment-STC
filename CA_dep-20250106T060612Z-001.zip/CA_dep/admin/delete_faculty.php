<?php
	include("../connection.php");

$i=0;
  if (count($_GET['check']) > 0 ) {
	    $all = implode(",", $_GET['check']);
		//var_dump($all);
	 $query="DELETE FROM db_fac WHERE t_id IN('$all')";
	var_dump($query);
	
	 $result = $conn->query($query);

		
	
	 if ($result==TRUE) {


	//header("location:viewfaculty.php");
} 
else
{

//header("location:viewfaculty.php");
}  
}
	
	

?>