<?php
include('adminheader.php');
include('../connection.php');
$f=0;
if(isset($_POST['view']))
{
	header('Location:viewfaculty.php');
}
if(isset($_POST['add']))
	{
      
      $img=$_FILES['img']['name'];
	 
	  if(empty($img))
	  {
		  $f=1;
		  $img_err="Choose  image";
	  }
	   $tid=$_POST['TID'];
	
	  //var_dump($id);
	  if(empty($tid))
	  {
		  $f=1;
		  $tid_err="Fill Register id";
	  }
	  $name=$_POST['name'];

	  if(empty($name))
	  {
		  $f=1;
		  $name_err="Fill  name";
	  }
	  $address=$_POST['Address'];
	
	  if(empty($address))
	  {
		  $f=1;
		  $address_err="Fill  address";
	  }

	    $dob=$_POST['dob'];
		
	   if(empty($dob))
	  {
		  $f=1;
		  $dob_err="Choose Date of birth";
	  }
	  	  $gen=$_POST['gen'];
	 
	   if(empty($gen))
	  {
		  $f=1;
		  $gen_err="Choose Gender";
	  }
	  $ph=$_POST['Phone'];
	
		if(empty($ph))
	  {
		  $f=1;
		  $ph_err="Fill  Phone number";
	  }  
	  $email=$_POST['Email'];
	  
	  if(empty($email))
	  {
		  $f=1;
		  $email_err="Fill  Email";
	  }  
	  $quali=$_POST['qua'];
	  //var_dump($quali);
	   if(empty($quali))
	  {
		  $f=1;
		  $quali_err="Fill Qualification";
	  }  
	   $exp=$_POST['Experience'];
	   if(empty($exp))
	  {
		  $f=1;
		  $exp_err="Fill Experience";
	  } 
	  
      $posi=$_POST['pos'];
	  //var_dump($posi);
      if(empty($posi))
	  {
		  $f=1;
		  $posi_err="Fill Position ";  
	  }
  $pswd=$_POST['Password'];
    if(empty($pswd))
	  {
		  $f=1;
		  $pswd_err="Fill Password ";  
	  }
	  
	 $sql=" SELECT  *  FROM `db_fac` WHERE `t_id`='$tid' ";
//var_dump($sql);
$eqr=mysqli_query($conn, $sql);
 $r=$eqr->fetch_assoc();
$c= $eqr->num_rows;
//var_dump($r);
if($c==1)
{
echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Already Registred!..')
  // window.location.href='facultyreg.php';
    </SCRIPT>");
}
	if($f==0)
		{			

   $sql="INSERT INTO `db_fac`(`t_id`, `img`, `name`, `add`, `dob`,`gender`, `ph_no`, `email`, `qualif`, `exprnc`, `position`, `paswd`) values('$tid','$img','$name','$address','$dob','$gen','$ph','$email','$quali','$exp','$posi','$pswd')";
//var_dump($sql);
	 if (mysqli_query($conn, $sql)) {
		  
  echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Succesfully Added')
  // window.location.href='admin.php';
    </SCRIPT>");

	 }
		}
		
		else {
   echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Insertion Failed!..')
  // window.location.href='facultyreg.php';
    </SCRIPT>");
		
		}
		
	}	  
?>
<!--//banner -->
	<!-- short-->
	
<!-- //short-->
	<!-- //short-->
	<html>
<head>

<link href="../css/form.css" rel="stylesheet" type="text/css" media="all" />


<link href="//fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
</head>
<body>
	<div class="main">
	
		
		<div class="w3_agile_main_grids">
			<section class="slider">
				<div class="flexslider">
					<ul class="slides">
						<li>
							<div class="agileits_w3layouts_main_grid">
								<span style="color:red;font-size:285%;margin-left:85px">R</span><span style="color:black;font-size:285%">egistration</span>		<span style="color:red;font-size:285%;margin-left:5px">F</span><span style="color:black;font-size:285%">orm</span>
								<br>
								<br>
								<br>
								<form action="#" method="POST" enctype="multipart/form-data">
																	<span>
										<label>Image</label>
										<input type="FILE"  name="img" >
							 <span style="color:red"><?php echo (isset($img_err))?$img_err:""?></span>  
										
									</span>
								<br><br>
									<span>
										<label>Faculty ID</label>
										<input type="text"  name="TID" maxlength="6">
								
										<br>
										<br>
										  <span style="color:red;margin-left:180px"><?php echo (isset($tid_err))?$tid_err:""?></span> 
										
									</span>
									<span>
										<label>Name</label>
										<input type="text"  name="name" >
										<br>
										<br>
							 <span style="color:red ;margin-left:180px"><?php echo (isset($name_err))?$name_err:""?></span> 
									</span>
									<span>
										<label style="width: 22%;
    font-size: .85em;
    color: #212121;
    background: #e9e9e9;
    display: inline-block;
    padding: 13px;
    text-transform: uppercase;
    float: left;
    letter-spacing: 2px;
    text-align: center;
    border: 1px solid #e9e9e9;
	height:60px">Address</label>
										<textarea name="Address"   style="padding: 13px 15px;
    color: #999;
    outline: none;
    width: 67.4%;
    font-size: .85em;
    background: none;
    border: 1px solid #e9e9e9;
}
form.css:41
h1, h2, h3, h4, h5, h6, input, p, a, select, button, textarea {
    font-family: 'Montserrat', sans-serif;
    margin: 0;">

</textarea>
			 <span style="color:red; margin-left:180px"><?php echo (isset($address_err))?$address_err:""?></span> 
									</span>
									<br>
									<span>
										<label>Date Of Birth</label>
										<input   type="date"  name="dob" type="date"  style="padding: 13px 15px;
    color: #999;
    outline: none;
    width: 67.4%;
    font-size: .85em;
    background: none;
    border: 1px solid #e9e9e9;
	height:55px;
form.css:41
h1, h2, h3, h4, h5, h6, input, p, a, select, button, textarea {
    font-family: 'Montserrat', sans-serif;
    margin: 0;">
	 <span style="color:red;margin-left:180px"><?php echo (isset($dob_err))?$dob_err:""?></span> 
									</span>
									<br>
									<span>
										<label>Gender</label>
										<select   style="width: 68% !important;
    padding: 12px 15px !important;" name="gen">
											<option value="null">Gender</option>
											<option value="female">Female</option>         
											<option value="male">Male</option>
											<option value="other">Other</option>
											<!--<option value="">China</option>
											<option value="">More</option>-->
										</select>
										 <span style="color:red;margin-left:180px"><?php echo (isset($gen_err))?$gen_err:""?></span> 
									</span>
									<br>
									<span>
										<label style="width: 22%;
    font-size: .85em;
    color: #212121;
    background: #e9e9e9;
    display: inline-block;
    padding: 13px;
    text-transform: uppercase;
    float: left;
    letter-spacing: 2px;
    text-align: center;
    border: 1px solid #e9e9e9;
	height:56px">Ph. Number</label>
										<input type="text"  name="Phone" style="padding: 13px 15px;
    color: #999;
    outline: none;
    width: 67.4%;
    font-size: .85em;
    background: none;
    border: 1px solid #e9e9e9;
	height:55px;
form.css:41
h1, h2, h3, h4, h5, h6, input, p, a, select, button, textarea {
    font-family: 'Montserrat', sans-serif;
    margin: 0;" pattern="[0-9]{10}" >
							 <span style="color:red;margin-left:180px"><?php echo (isset($ph_err))?$ph_err:""?></span> 
						
									</span>
									<br>
									<span>
										<label>Email</label>
										<input type="email"  name="Email" >
							 <span style="color:red;margin-left:180px"><?php echo (isset($email_err))?$email_err:""?></span> 
									</span><br>
									<span>
										<label style="width: 25%;
    font-size: .85em;
    color: #212121;
    background: #e9e9e9;
    display: inline-block;
    padding: 13px;
    text-transform: uppercase;
    float: left;
    letter-spacing: 2px;
    text-align: center;
    border: 1px solid #e9e9e9;
	height:45px">Qualification</label>
										<select    name="qua" style="width: 64% !important;
    padding: 12px 15px !important;" >
											<option value="null">Qualification</option>
											<option value="MCA">MCA</option>         
											<option value="Msc.Computer Science">Msc.Computer Science</option>
											<option value="PGDCA">PGDCA</option>
											<!--<option value="">China</option>
											<option value="">More</option>-->
										</select>
							 <span style="color:red;margin-left:180px"><?php echo (isset($quali_err))?$quali_err:""?></span> 
									</span><br>
									<span>
										<label>Experiance</label>
										<input type="text"  name="Experience" >
							 <span style="color:red;margin-left:180px"><?php echo (isset($exp_err))?$exp_err:""?></span> 
									</span><br>
									<span>
										<label>Position</label>
										<select name="pos"  style="width: 64% !important;
    padding: 12px 15px !important;">
											<option value="null">Positions</option>
											<option value="HOD">HOD</option>         
											<option value="Assistant Professor">Assistant Professor</option>
											<option value="Lab Assistant">Lab Assistant</option>
											<!--<option value="">China</option>
											<option value="">More</option>-->
										</select>
							 <span style="color:red;margin-left:180px"><?php echo (isset($posi_err))?$posi_err:""?></span> 
									</span><br>
									<span>
										<label>Password</label>
										<input type="password"  name="Password" maxlength="8" style="padding: 13px 15px;
    color: #999;
    outline: none;
    width: 67.4%;
    font-size: .85em;
    background: none;
    border: 1px solid #e9e9e9;
	height:42px;
form.css:41
h1, h2, h3, h4, h5, h6, input, p, a, select, button, textarea {
    font-family: 'Montserrat', sans-serif;
    margin: 0;" >
	 <span style="color:red;margin-left:180px"><?php echo (isset($pswd_err))?$pswd_err:""?></span> 
									</span>
									<!--<span>
										<label>Address</label>
										<input name="Address" type="text" placeholder="Your Address" required="">
									</span>
									<span>
										<label>Address</label>
										<input name="Address" type="text" placeholder="Your Address" required="">
									</span>-->
									<div class="w3_agileits_submit">
										<input type="submit" value="REGISTER" name="add"> <input type="submit" value="VIEW" name="view">
										<!--<input type="reset" value="reset">-->
									</div>
								</form>
							</div>
						</li>
						
						
					</ul>
				</div>
			</section>
		</div>
		
	</div>
<!-- password -->
<?php
include('adminfooter.php');
?>