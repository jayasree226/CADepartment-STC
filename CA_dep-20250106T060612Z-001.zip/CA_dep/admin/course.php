<?php
include('adminheader.php');
?>
<!DOCTYPE html>
<html>
<head>

<meta content="noindex, nofollow" name="robots">
<link href="style.css" rel="stylesheet" type="text/css">
<style>
@import "http://fonts.googleapis.com/css?family=Droid+Serif";
/* Above line is to import google font style */
.maindiv {
margin:0 auto;
width:980px;
height:500px;
background:#fff;
padding-top:20px;
font-size:14px;
font-family:'Droid Serif',serif
}
.title {
width:100%;
height:70px;
text-shadow:2px 2px 2px #cfcfcf;
font-size:16px;
text-align:center;
font-family:'Droid Serif',serif
}
.divA {
width:70%;
float:left;
margin-top:30px
}
.form {
width:400px;
float:left;
background-color:#fff;
font-family:'Droid Serif',serif;
padding-left:30px
}
.divB {
width:100%;
height:100%;
background-color:#fff;
border:dashed 1px #999
}
.divD {
width:200px;
height:480px;
padding:0 20px;
float:left;
background-color:#f0f8ff;
border-right:dashed 1px #999
}
p {
text-align:center;
font-weight:700;
color:#5678C0;
font-size:18px;
text-shadow:2px 2px 2px #cfcfcf
}
.form h2 {
text-align:center;
text-shadow:2px 2px 2px #cfcfcf
}

.clear {
clear:both
}
span {
font-weight:700
}
</style>
</head>
<body>
<div >
		<span style="color:red;font-size:285%;margin-left:565px">S</span><span style="color:black;font-size:285%">earch</span><span style="color:red;font-size:285%">S</span><span style="color:black;font-size:285%">tudent</span>
		</div>
<div class="maindiv" >
<div class="divA" >
<div class="title">

</div>
<div class="divB" style="margin-left:180px" >
<div class="divD" style="height:180px">
<span style="color:red">Sem Details</span>

<br>
<br>

<?php
include('../connection.php');
$course=$_GET['course_name'];
$batch=$_GET['batch'];
$query = "SELECT * FROM db_stud  where course='$course' group by batch";
 $result = $conn->query($query);
    while($row =$result->fetch_assoc())
	{
		
echo "<b><a href=\"course.php?course_name={$row['course']} & batch={$row['batch']}\">{$row['batch']}</a></b>";
echo "<br />";
}
?>
</div>

<div class="form" >

<form method="GET" id="my_form"  name="my_form" action="filter_student.php" >
<br>
<br>

<span style="color:red;margin-left:80px">ENTER ADMISSION NUMBER</span>
<br>
<br>
<input type="hidden" name="course"  value="<?php echo $course;?>">
<input type="hidden" name="batch"  value="<?php echo $batch;?>">
<select name="search"   class="select-field" style="width:340px;height:35px;background-color:rgba(255, 255, 255, 0.4); " >
			<option value=""> Choose Registration number</option>
			<?php	include("../connection.php");
             // $b=$_POST['id'];

            $sql = "SELECT  DISTINCT s_re,course,batch FROM db_stud where course='$course' and batch='$batch' ";
            $result = $conn->query($sql);
       
	while($row =$result->fetch_assoc())
{
	


 echo "<option value='".$row['s_re']."'>".$row['s_re']."</option>";
}

?>
	</select>
	<br>
	<br>
	<BR>
<input type="submit"   value="SEARCH">

</div>
</form>

<div class="clear"></div>
</div>
<div class="clear"></div>
</div>
</div>

<?php
include('adminfooter.php');
?>