<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
include('header.php');
?>
	<!-- //header -->
	<!-- about -->
	<div class="welcome">
		<div class="container">
		<h3 class="heading-agileinfo">About Us</h3>
			<div class="w3ls_news_grids"> 
				<div class="col-md-6 w3_agile_about_grid_left"color="black" style="text-align:justify">
					<p style="color:black">Computer Application is one of the  areas in Science and technology. We providing BCA & Msc.Computer Science courses."
					The academic atmosphere at the Institute is a rare blend of modern day technical skills and the traditional emphasis on imparting knowledge. The faculty as well as the students who have qualified from the Institute have always done the country proud through their outstanding achievements and leadership qualities.

 The Department of Computer Application, the oldest and proven department among the selffinancing courses, started in June 2001 with a UG course B.Sc. Computer Science. In 2004, the department has been upgraded as PG department with M.Sc. Computer Science.
					Regarding the infrastructure, the most sophisticated department in the college, having two air conditioned labs, one for UG and the other for PG. Added one more UG course -BCA in 2002.. So far we've achieved 99% graduation in every year.
					Specific training programs are being schemed to enhance the capabilities of the students to meet the expectations of the industry. Placement activities are being re-aligned to meet the current challenges and the emerging market scenarios.
												Major companies like Infosys , Wipro  etc.. recruit from our department every year.</p>
				</div>
				
				
		</div>
	</div>
<!-- //about -->

	
<!-- team -->
	<div class="team">
		<div class="container">
		<h3 class="heading-agileinfo">Meet Our Staff</h3>
			<div class="w3_agile_team_grids">
				<div class="col-md-3 w3_agile_team_grid">
					<div class="hover14 column">
						<figure><img src="images/bindya.jpg" alt=" " class="img-responsive" /></figure>
					</div>
					<h3>Mrs.Bindhya  </h3>
					<p>HOD</p>
					<!--<ul class="agileits_social_list">
						<li><a href="#" class="w3_agile_facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li><a href="#" class="agile_twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						<li><a href="#" class="w3_agile_dribble"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
						<li><a href="#" class="w3_agile_vimeo"><i class="fa fa-vimeo" aria-hidden="true"></i></a></li>
					</ul>-->
				</div>
				<div class="col-md-3 w3_agile_team_grid">
					<div class="hover14 column">
						<figure><img src="images/jeswin.jpg" alt=" " class="img-responsive" /></figure>
					</div>
					<h3>Mr.Jeswin Saju</h3>
					<p>Assistant Professor</p>
					<!--<ul class="agileits_social_list">
						<li><a href="#" class="w3_agile_facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li><a href="#" class="agile_twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						<li><a href="#" class="w3_agile_dribble"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
						<li><a href="#" class="w3_agile_vimeo"><i class="fa fa-vimeo" aria-hidden="true"></i></a></li>
					</ul>-->
				</div>
				<div class="col-md-3 w3_agile_team_grid">
					<div class="hover14 column">
						<figure><img src="images/prinson.jpg" alt=" " class="img-responsive" /></figure>
					</div>
					<h3>Mr.Prinson P.T</h3>
					<p>Assistant Professor</p>
					<!--<ul class="agileits_social_list">
						<li><a href="#" class="w3_agile_facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li><a href="#" class="agile_twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						<li><a href="#" class="w3_agile_dribble"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
						<li><a href="#" class="w3_agile_vimeo"><i class="fa fa-vimeo" aria-hidden="true"></i></a></li>
					</ul>-->
				</div>
				<div class="col-md-3 w3_agile_team_grid">
					<div class="hover14 column">
						<figure><img src="images/teena.jpg" alt=" " class="img-responsive" /></figure>
					</div>
					<h3>Mrs.Teena</h3>
					<p>Assistant Professor</p>
					<!--<ul class="agileits_social_list">
						<li><a href="#" class="w3_agile_facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li><a href="#" class="agile_twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						<li><a href="#" class="w3_agile_dribble"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
						<li><a href="#" class="w3_agile_vimeo"><i class="fa fa-vimeo" aria-hidden="true"></i></a></li>
					</ul>-->
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- team -->

	<!-- footer -->
	<div class="footer_top_agileits">
		<div class="container">
			<div class="col-md-4 footer_grid">
			<div class="mail-agileits-w3layouts">
			<i class="fa fa-map-marker" aria-hidden="true"></i>
				<h3>Location</h3>
				<div class="contact-right">
								<span><p>St.Thomas' College (Autonomous),
							<br>Thrissur, Kerala - 680001</p></span>
							</div>
			</div><div class="clearfix"> </div>
			</div>
			<div class="col-md-4 footer_grid">
				
				<div class="mail-agileits-w3layouts">
							<i class="fa fa-envelope-o" aria-hidden="true"></i>
							<div class="contact-right">
								<h3>Mail Us:</h3><a href="mailto:info@example.com">stcthrissur@gmail.com</a>
							</div>
							<div class="clearfix"> </div>
						</div>
			</div>
			<div class="col-md-4 footer_grid">
			<div class="mail-agileits-w3layouts">
							<i class="fa fa-volume-control-phone" aria-hidden="true"></i>
							<div class="contact-right">
								<h3>Phone</h3><span>9249449977</span>
							</div>
							<div class="clearfix"> </div>
						</div>
				<ul class="address">
					
				</ul>
			</div>
			<!--<div class="clearfix"> </div>
			<div class="footer_grids">
				<div class="col-md-4 footer_grid_left">
					<h3>Sign up for our Newsletter</h3>
				</div>
				<div class="col-md-8 footer_grid_right">

					<form action="#" method="post">
						<input type="email" name="Email" placeholder="Enter Email Address..." required="">
						<input type="submit" value="Submit">
					</form>
				</div>
				<div class="clearfix"> </div>
			</div>-->
		</div>
	</div>
	<div class="footer_w3ls">
		<div class="container">
					<div class="footer_bottom1">
						<p>2018 CA DEPARTMENT Stc. All rights reserved 
					</div>
		</div>
	</div>
	<!-- //footer -->
<!-- modal -->
	<div class="modal about-modal fade" id="myModal" tabindex="-1" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header"> 
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
					<h4 class="modal-title">Instruction</h4>
				</div> 
				<div class="modal-body">
					<div class="agileits-w3layouts-info">
						<img src="images/g12.jpg" class="img-responsive" alt="" />
						<p>Duis venenatis, turpis eu bibendum porttitor, sapien quam ultricies tellus, ac rhoncus risus odio eget nunc. Pellentesque ac fermentum diam. Integer eu facilisis nunc, a iaculis felis. Pellentesque pellentesque tempor enim, in dapibus turpis porttitor quis. Suspendisse ultrices hendrerit massa. Nam id metus id tellus ultrices ullamcorper.  Cras tempor massa luctus, varius lacus sit amet, blandit lorem. Duis auctor in tortor sed tristique. Proin sed finibus sem</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- //modal -->

	<a href="#home" class="scroll" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
	<!-- js -->
	<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>